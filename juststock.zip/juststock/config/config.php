<?php   
  $sitedoc = $_SERVER['DOCUMENT_ROOT']."/juststock";
  $site = "http://localhost/juststock";   
    
  if(!isset($_SESSION['user_id'])){ header("location: ../index.php");}
  
  
  
?>
