<?php session_start(); 
include_once '../database/db.php'; 
$dbOperation = new DB(); 
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Place Order </title>
    <link rel="icon" type="image/jpg" href="../home/images/steph_logo.png" /> 
    <?php include_once 'include/basic_css.php';?>    
    
  </head>

  <body class="nav-md">
    <div class="container body">
      <div class="main_container">
          <!-- side bar -->
       <?php include_once 'include/sidebar.php';?>

        <!-- top navigation -->
        <?php include_once 'include/top_navigation.php';?>
       

        <!-- page content -->
        <div class="right_col" role="main">
         

          <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
              <div class="dashboard_graph">

                <div class="row x_title">
                  <div class="col-md-12">
                    <h3>PLACE ORDER ON JUST STEPH </h3>
                  </div>
                  
                </div>        
               
        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-default">
                    <div class="panel-heading">  </div>
                    <div class="panel-body">
                        <div class="row" id="product_show">
                            <!-- BEGIN PRODUCTS -->                                             
                            <div class="col-md-12 col-sm-12">
         <span class="loading-overlay" style="display: none;"><img src="../build/images/btn-ajax-loader.gif"/></span>
      <table class="table table-hover" >            
         <thead>
                    <tr>
                        <th>S/N</th>
                        <th>Name</th>
                        <th>Quantity</th>
                        <th>Unit Price(₦)</th>	   
                        <th>Total(₦)</th>                        
                    </tr>
                </thead>    
                
  <?php
// Get the results as JSON string
$product_list = filter_input(INPUT_POST, 'cart_list');

// Convert JSON to array
$product_list_array = json_decode($product_list);

$_SESSION['cart_item'] = $product_list_array;
//$prod = json_encode($product_list_array);
//setcookie('order_data',$prod, time()+3600);
$name = ''; $quantity = 0; $price = 0; $product_id = '';
$subtotal = 0; $total = 0; $count = 0;
$error = $esign = "";
if($product_list_array) {
    foreach($product_list_array as $p){
        $count++;
        foreach($p as $key=>$value) {
            
            //$result_html .= $key.": ".$value."<br />";
            switch($key){
                case "product_id": 
                    $product_id = $value;
                    break;
                case "product_name": 
                    $name = $value;
                    break;
                case "product_quantity":
                   $quantity = $value;
                      break;                 
                case "product_price":
                   $price = $value;   
                      break;               
            }
           $subtotal =  bcmul($quantity, $price, 2);
           $f_subtotal = number_format($subtotal, 2);
            
        }
        
        $queryConfig = array('table' => "items",'where' => " WHERE item_id = '$product_id' ",'return_type' => "single"); 
        $data = $dbOperation->getdata($queryConfig);    
        $qty1 = $data['quantity'];  
        if($quantity > $qty1){
            $error .= "Ordered quantity(<font color='red'>".$quantity."</font>) on ".$name." is more than ".$qty1." in stock <br>";
            $esign= "<font color='red'>*</font>";
        }
        else{
           $esign = ""; 
        }
       echo "<tr><td>$count.$esign</td><td>$name</td><td>$quantity</td><td>$price</td><td>$f_subtotal</td></tr>";
       $total = $total + $subtotal; 
    }
     $f_total = number_format($total,2);
     echo "<tr><td><strong>Total:</strong></td><td></td><td></td><td></td><td><h4><strong>$f_total</strong></h4></td></tr>";

?>               
            <tr><td></td>
              <td>Customer: <br>
                  <input class="form-control" type="text" name="buyer" id="buyer" placeholder="Customer Name" />
              </td>
              <td>Payment Type:<br>
                  <select id="p_type" class="form-control">
                <option value="N">None</option>      
                <option value="C">Cash</option>
                <option value="P">POS</option>
                <option value="T">Online Transfer</option>               
              </select>
              </td>
              <td>Transaction Type:<br>
              <select id="t_type" class="form-control">
                <option value="P">Paid</option>
                <option value="C">Credit</option>                              
              </select>
              </td>
              
              <td>
                  <textarea class="form-control" rows="1" placeholder="Comment(optional)" name="comment" id="comment"></textarea> 
                    </td></tr>

               <?php if(!empty($error)){?>
                 <tr><td colspan="3"><?php echo $error; ?></td>
                 <td> <a href="javascript:void(0);" class="btn btn-danger disabled">Submit Order</a>
                    <a href="book_order.php" class="btn btn-warning" id="clear_btn" onclick="clear()">Clear</a>
                 </td><td> </td>
                 </tr>                   
               <?php } 
               else{ ?>     
                <tr><td></td><td></td><td></td>
                    <td> <a href="javascript:void(0);" class="btn btn-success" id="order_btn" onclick="placeOrder()">Submit Order</a>
                    <a href="book_order.php" class="btn btn-warning" id="clear_btn" onclick="clear()">Clear</a>
                    </td>
                    <td> </td></tr>    
               <?php } 
               
         } else {	
	echo "<tr><td colspan='5'><center><strong style='color:red'>Cart is Empty</strong></center></td></tr>";
}      
               
               ?>
                
                
          </table>                        
                              
                            </div>   
                            <!-- END PRODUCTS -->
                        </div>
                    </div>
                </div>
                
            </div>            
            
        </div>
              
<div class="row">                
             <div id="dataModal" class="modal fade">
 <div class="modal-dialog modal-sm">
  <div class="modal-content">
   <div class="modal-header">
    <button type="button" class="close" data-dismiss="modal">&times;</button>
    <h4 class="modal-title"></h4>
   </div>
   <div class="modal-body" id="sales_detail">
       <h4><strong>Just Steph Venture</strong></h4> 
       <hr>
       Customer: <strong><span id="cust"></span></strong>
       <hr>
       <table class="table" style=" font-size: 8px">            
         <thead><tr><th></th><th>Product</th><th>QTY</th><th>Price</th><th>Total(₦)</th></tr></thead>    
    <?php 
     if($product_list_array) { $count1 = $total1 = $f_total1 = 0;
    foreach($product_list_array as $p){
        $count1++;
        foreach($p as $key=>$value) {
            
            //$result_html .= $key.": ".$value."<br />";
            switch($key){
                case "product_id": 
                    $product_id = $value;
                    break;
                case "product_name": 
                    $name = $value;
                    break;
                case "product_quantity":
                   $quantity = $value;
                      break;                 
                case "product_price":
                   $price = $value;   
                      break;               
            }
			$f_price =  number_format($price, 2);
           $subtotal =  bcmul($quantity, $price, 2);
           $f_subtotal = number_format($subtotal, 2);
            
        }                
       echo "<tr><td>$count1</td><td>$name</td><td>$quantity</td><td>$f_price</td><td>$f_subtotal</td></tr>";
       $total1 = $total1 + $subtotal; 
    }
     $f_total1 = number_format($total1,2);
     
     echo "<tr><td></td><td><strong>Total:</strong></td><td></td><td></td><td><h4><strong>$f_total1</strong></h4></td></tr>";
}
    
    ?>
	<tr><td colspan="5"><hr></td></tr>
        <tr><td colspan="5"><hr></td></tr> 
		<tr><td colspan="5"><hr></td></tr> 
       </table>     
   </div>
   <div class="modal-footer">
       <button type="button" class="btn btn-success" onclick="printReceipt()">Print Receipt</button>   
    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
   </div>
  </div>
 </div>
</div>                   
            </div>
                <div class="clearfix"></div>
              </div>
            </div>

          </div>
          <br />

         


         
        </div>
        <!-- /page content -->

        <!-- footer content -->
        <?php include_once 'include/footer.php';?>
        <!-- /footer content -->
      </div>
    </div>

   <?php include_once 'include/basic_js.php';?>   
       <script>
function placeOrder() { 
 if (confirm("Do you want to process this transaction?. Click OK to process or Cancel to ignore") === true) {     
    var comment = $("#comment").val();
    var p_type = $("#p_type").val();
    var t_type = $("#t_type").val();
    var buyer = $("#buyer").val();
    $('#cust').html(buyer);
   // alert(comment);
    $.ajax({
        type: 'POST',
        url: '../database/create_order.php',
        data:'action_type=add&comment='+comment+'&p_type='+p_type+'&t_type='+t_type+'&buyer='+buyer,
        beforeSend: function () {
            $('#order_btn').hide();
            $('#clear_btn').hide();
            $('.loading-overlay').show();
        },
        success: function (html) {
        if($.trim(html) === "ok"){ 
            $('.loading-overlay').fadeOut("slow");
            alert("Transaction Completed successfully"); 
            
            $('#dataModal').modal({backdrop: false});
            
            //setTimeout(' window.location.href = "sales_record.php"; ',400);
        }
        else {alert(html);}
        }
    });
    } else{}
}
function clear(){
   setTimeout(' window.location.href = "book_order.php"; ',400);
}
function printReceipt(){  
            var divContents = $("#sales_detail").html();
            var printWindow = window.open('', '', 'width=400');
            //printWindow.document.write('<html><head><title>Sales</title>');
            //printWindow.document.write('</head><body >');
            printWindow.document.write(divContents);
           // printWindow.document.write('</body></html>');
            printWindow.document.close();
            printWindow.print();  
            
            setTimeout(' window.location.href = "sales_record.php"; ',4000);
 
}
</script>    
    </body>
</html>
