<?php session_start();
include_once '../config/config.php';
include_once '../database/db.php'; 
$dbOperation = new DB();
       
?> 
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Just Steph Venture</title>
    <link rel="icon" type="image/jpg" href="../home/images/steph_logo.png" /> 
    <?php include_once 'include/basic_css.php';?>
     <link href="../vendors/nprogress/nprogress.css" rel="stylesheet">
     <link href="css/pagination.css" rel="stylesheet">
      
     <style>
        #ui-datepicker-div {
    z-index:2 !important;
    background: #002;
        }
        .ui-state-default{
            color: #F4FF77;
            
        }
     </style>
  </head>

  <body class="nav-md">
    <div class="container body">
      <div class="main_container">
          <!-- side bar -->
       <?php include_once 'include/sidebar.php';?>

        <!-- top navigation -->
        <?php include_once 'include/top_navigation.php';?>
       

        <!-- page content -->
        <div class="right_col" role="main">
         <div class="">
            <div class="page-title">
              <div class="title_left">
                <h3>CREDIT REGISTER</h3>
              </div>

              <div class="title_right">
                <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
                  <div class="input-group">
                    <input id="keywords" name="keywords" type="text" class="form-control" placeholder="Search for..." onkeyup="searchFilter()">
                    <span class="input-group-btn">
                              <button class="btn btn-default" type="button" onclick="searchFilter()">Go!</button>
                          </span>
                  </div>
                </div>
              </div>
            </div>            
            <div class="row">                
             <div id="dataModal" class="modal fade">
 <div class="modal-dialog modal-lg">
  <div class="modal-content">
   <div class="modal-header">
    <button type="button" class="close" data-dismiss="modal">&times;</button>
    <h4 class="modal-title"></h4>
   </div>
   <div class="modal-body" id="employee_detail">
    
   </div>
   <div class="modal-footer">
    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
   </div>
  </div>
 </div>
</div>                   
            </div>
            
            
            <div class="row" style="margin: 10px 20px 10px 10px; width: 98%; font-size: 14px;">
     <div class="panel panel-default users-content">
      <div class="panel-heading">
          <div class="post-search-panel">   
    <select id="sortBy" onchange="searchFilter()">
        <option value="">Sort By Date</option>
        <option value="asc">Ascending</option>
        <option value="desc">Descending</option>
    </select>
    <select id="showLimit" onchange="searchFilter()">
        <option value="10">10</option>
        <option value="20">20</option>
        <option value="30">30</option>
        <option value="40">40</option>
        <option value="50">50</option>
    </select>     
           <span class="loading-overlay"><img src="../build/images/loading2.gif"/></span>
   
          </div>
          </div>      
     <div class="panel-body none formData" id="editForm">
                <h2 id="actionLabel">Transaction Details</h2>
                <div id="stock_details"></div><hr>
               <form class="form" id="userForm"> 
                   <input type="hidden" name="idEdit" id="idEdit"/>
                   <input type="hidden" name="amtEdit" id="amtEdit"/>
                   <input type="hidden" name="cust" id="cust"/>
                                     
                    <div class="col-md-12 col-sm-12 col-xs-12"> 
                     <div class="form-group col-md-3 col-sm-6 col-xs-12">
                         <span><strong>Amount Owed: </strong></span>&nbsp; <span id="costdis"></span> &nbsp;&nbsp;
                        <a href="javascript:void(0);" title="Balance Amount Owed" class="glyphicon glyphicon-minus-sign" onclick="displayDiv('cpdiv')"></a>
                    </div> 
                     <div class="col-md-9 col-sm-12 col-xs-12" id="cpdiv" style="display:none">      
                    <div class="form-group col-md-4 col-sm-12 col-xs-12"> Enter amount to be deducted:<br>                      
                        <div class="input-group">
                            <div class="input-group-addon">₦</div>                            
                            <input type="text" class="form-control" name="amt_owed" id="amt_owed" placeholder="e.g 12,300"/>                           
                        </div>                        
                    </div> 
                    <div class="form-group col-md-2 col-sm-4 col-xs-12">   <br>                          
                        <a href="javascript:void(0);" class="btn btn-default" onclick="userAction()">Update</a>
                    </div> 
                     </div>   
                    </div>                   
                    <hr>    
                   <div class="form-group col-md-6 col-sm-6 col-xs-12"><br>                
                    <a href="javascript:void(0);" class="btn btn-warning" onclick="$('#editForm').slideUp();">Cancel</a>
                    </div>
                </form>
            </div>    
   <div id="posts_content" class="table-responsive">  
       <?php
    
      include_once 'misc/Pagination.php';     
 
    $limit = 10;
    $p_type = array('N' => 'None','C' => 'Cash','P' => 'POS','T' => 'Online Transfer');
    $t_type = array('P' => 'Paid','C' => 'Credit');
    //get number of rows
    $sql = "SELECT count(sales_id) as code FROM sales WHERE t_type = 'C' ";
    $data1 = $dbOperation->getPages($sql);
    $rowCount = $data1['code'];    
    
    //initialize pagination class
    $pagConfig = array(
        'totalRows' => $rowCount,
        'perPage' => $limit,
        'link_func' => 'searchFilter'
    );
    $pagination =  new Pagination($pagConfig);
   $where = " WHERE t_type = 'C'";
   $tableName = "sales"; 
   $orderSQL = " ORDER BY sale_date DESC ";
 $queryConfig = array(
        'table' => $tableName,
        'limit' => $limit, 
        'where' => $where,
        'order_by' => $orderSQL
    );
 
   $data = $dbOperation->getdata($queryConfig);    
   $dbOperation->close();  
   if($data){ ?>
             <table class="table table-hover table-striped table-bordered">
                 <thead>
                    <tr>
                        <th></th> 
                        <th>SALES ID</th>
                        <th>CUSTOMER</th> 
                        <th>AMOUNT(₦)</th> 
                        <th>AMOUNT OWED(₦)</th>                        
                        <th>DATE OF SALES</th> 
                        <th>DATE UPDATED</th>  
                        <th>ACTION</th>
                    </tr>
                </thead>
    <?php $count = 0;
   foreach ($data as $value) {
       $count++;
       $sales_id = $value['sales_id']; 
       $p1 = $p_type[trim($value['p_type'])]; $t1 = $t_type[trim($value['t_type'])];
       $date_created =  date_format(date_create($value['sale_date']), 'F, j Y');  
       
       $date_updated =  date_format(date_create($value['date_updated']), 'F, j Y');   
          if($date_updated == "November, 30 -0001") {$date_updated="";}  
       ?>
       <tr>     
                     <td> <?php echo $count ?></td>                    
                     <td> <?php echo $sales_id; ?>  </td> 
                     <td> <?php echo $value['buyer']; ?>  </td>                                  
                     <td> <?php echo number_format($value['amount'],2); ?>  </td>  
                     <td> <?php echo number_format($value['amt_owed'],2); ?>  </td>  
                     <td> <?php echo $date_created; ?>  </td>  
                     <td> <?php echo $date_updated; ?>  </td>  
                      <td>                           
                          <a target="_blank" href="sales_detail.php?id=<?= $sales_id;?>" title="View Sales Detail" class="glyphicon glyphicon-eye-open"></a>
                          <a href="javascript:void(0);" title="Update Sales" class="glyphicon glyphicon-pencil" onclick="loadContent('<?php echo $sales_id; ?>')"></a>
                      </td>
                      
       </tr>   
       
  <?php }   
        
        ?>
             </table>          
   <?php echo $pagination->createLinks(); } 
   else {echo "<br><br><center><font color='red'><h2>Record Not Available</h2></font></center><br><br>";}
       
       ?>    
                   
          
    </div> 
    </div>
    </div>   

            
                       
         </div>          
        </div>
        <!-- /page content -->

        <!-- footer content -->
        <?php include_once 'include/footer.php';?>
        <!-- /footer content -->
      </div>
    </div>

   <?php include_once 'include/basic_js.php';?>
   
    <!-- Chart.js -->
    <!-- FastClick -->
    <script src="../vendors/fastclick/lib/fastclick.js"></script>
    <!-- NProgress -->
    <script src="../vendors/nprogress/nprogress.js"></script>    
      <script src="js/jquery-ui.min.js"></script>
  
    <script>            
       document.cookie = "current_page="+0; 
function searchFilter(page_num) { 
    page_num = page_num?page_num:0;
    document.cookie = "current_page=" +page_num; 
    
    var keywords = $('#keywords').val();
    var sortBy = $('#sortBy').val();
    var showLimit = $('#showLimit').val();  
       
    $.ajax({
        type: 'POST',
        url: '../database/sale_record.php',
        data:'page='+page_num+'&keywords='+keywords+'&sortBy='+sortBy+'&limit='+showLimit+'&action_type=viewc',
        beforeSend: function () {
            $('.loading-overlay').show();
        },
        success: function (html) { 
            $('#posts_content').html(html);
            $('.loading-overlay').fadeOut("slow");
        }
    });
}

function userAction(){ 
 if (confirm("Do you want to perform this action?. Click OK to continue or Cancel to ignore") === true) {     
    var idEdit = $('#idEdit').val(); var ncol = ''; var vcol = 0;
    var userData = '';    
        var amtEdit = $('#amtEdit').val();
        var amt_owed = $('#amt_owed').val(); 
        var cust = $('#cust').val();
        userData = 'id='+idEdit+'&amtEdit='+amtEdit+'&amt_owed='+amt_owed+'&cust='+cust+'&action_type=edit'; 
    
    $.ajax({
        type: 'POST',
        url: '../database/sale_record.php',
        data: userData,
        beforeSend: function () {
            $('.loading-overlay').show();
        },
        success:function(msg){           
        if($.trim(msg) === "ok"){
                 alert('Amount Updated successfully.'); 
                 var allcookies = document.cookie;              
                 var cookiearray = allcookies.split(';'); 
                 var value = 0;
                 value = cookiearray[0].split('=')[1]; 
                 
                 value = parseInt(value);                 
                searchFilter(value); 
                
                $('.form')[0].reset();
                $('.formData').slideUp();
            }        
        
        else{
                alert(msg);
            }
        }
    });
    } else{}
}
function displayDiv(name){
 if (name === 'qtydiv'){ $('#qtydiv').show(); $('#cpdiv').hide(); $('#spdiv').hide(); }
 else if (name === 'cpdiv'){ $('#qtydiv').hide(); $('#cpdiv').show(); $('#spdiv').hide(); }
 else if (name === 'spdiv'){ $('#qtydiv').hide(); $('#cpdiv').hide(); $('#spdiv').show(); }
 else { $('#qtydiv').hide(); $('#cpdiv').hide(); $('#spdiv').hide(); }
}
function fdate(dval){   
            var date1 = JSON.stringify(dval);
            var res = date1.split(",");
            var res2 = res[0].replace('{"date":', '');            
            var dateval = JSON.parse(res2);            
            return dateval;    
}
function loadContent(id){ 
    $.ajax({
        type: 'POST',
        dataType:'JSON',
        url: '../database/sale_record.php',
        data: 'action_type=data&id='+id,
        beforeSend: function () {
            $('.loading-overlay').show();
        },
        success:function(data){                      
                var amount = parseInt(data.amount);
                amount = amount.toFixed(2).replace(/(\d)(?=(\d{3})+\.)/g, '$1,');  
            var amt_owed = parseInt(data.amt_owed);
                amt_owed = amt_owed.toFixed(2).replace(/(\d)(?=(\d{3})+\.)/g, '$1,');
                
            var display ="<div class='table-responsive'> ";            
            display +="<table class='table table-hover' border='1'>";
            display += "<thead><tr><th>Sales ID</th><th>Customer</th><th>Amount</th><th>Amount Owed</th><th>Date Sold</th><th>Date Updated</th></tr></thead>"; 	
            display += "<tr><td>"+data.sales_id+"</td><td>"+data.buyer+"</td><td>"+amount+"</td><td>"+amt_owed+"</td><td >"+fdate(data.sale_date)+"</td><td >"+fdate(data.date_updated)+"</td></tr>";  
             $('#idEdit').val(data.sales_id);             
             $('#amtEdit').val(data.amt_owed); 
             $('#cust').val(data.buyer); 
             $('#costdis').html("₦"+amt_owed);
             
            display += "</table></div>";          
             $('#stock_details').html(display);   
                $('#editForm').slideDown();
                $('.loading-overlay').hide();
              
        }
    });
    
}
    </script>
    </body>
</html>
