<?php session_start();
include_once '../config/config.php';
include_once '../database/db.php'; 
$dbOperation = new DB();
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Just Steph Venture</title>
    <link rel="icon" type="image/jpg" href="../home/images/steph_logo.png" /> 
    <?php include_once 'include/basic_css.php';?>
     <link href="../vendors/nprogress/nprogress.css" rel="stylesheet">
     <link href="css/pagination.css" rel="stylesheet">
     
     <style>
        #ui-datepicker-div {
    z-index:2 !important;
    background: #002;
        }
        .ui-state-default{
            color: #F4FF77;
            
        }
     </style>
  </head>

  <body class="nav-md">
    <div class="container body">
      <div class="main_container">
          <!-- side bar -->
       <?php include_once 'include/sidebar.php';?>

        <!-- top navigation -->
        <?php include_once 'include/top_navigation.php';?>
       

        <!-- page content -->
        <div class="right_col" role="main">
         <div class="">
            <div class="page-title">
              <div class="title_left">
                <h3>Manage Product Categories</h3>
              </div>

              <div class="title_right">
                <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
                  <div class="input-group">
                    <input id="keywords" name="keywords" type="text" class="form-control" placeholder="Search for..." onkeyup="searchFilter()">
                    <span class="input-group-btn">
                              <button class="btn btn-default" type="button" onclick="searchFilter()">Go!</button>
                          </span>
                  </div>
                </div>
              </div>
            </div>            
            <div class="row">                
             <div id="dataModal" class="modal fade">
 <div class="modal-dialog modal-lg">
  <div class="modal-content">
   <div class="modal-header">
    <button type="button" class="close" data-dismiss="modal">&times;</button>
    <h4 class="modal-title"></h4>
   </div>
   <div class="modal-body" id="employee_detail">
    
   </div>
   <div class="modal-footer">
    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
   </div>
  </div>
 </div>
</div>                   
            </div>
            
            
            <div class="row" style="margin: 10px 20px 10px 10px; width: 98%; font-size: 14px;">
     <div class="panel panel-default users-content">
      <div class="panel-heading">
          <div class="post-search-panel">   
    <select id="sortBy" onchange="searchFilter()">
        <option value="">Sort By</option>
        <option value="asc">Ascending</option>
        <option value="desc">Descending</option>
    </select>
    <select id="showLimit" onchange="searchFilter()">
        <option value="10">10</option>
        <option value="20">20</option>
        <option value="30">30</option>
    </select>
              <span class="loading-overlay"><img src="../build/images/loading2.gif"/></span>
    <ul class="nav navbar-right panel_toolbox">
    <li><a href="javascript:void(0);" class="glyphicon glyphicon-plus" id="addLink" onclick="javascript:$('#addUser').slideToggle();">Add</a>
        </li>                     
                      
                    </ul>  
          </div>
          </div>
      
           <div class="panel-body none formData" id="addUser">
               <h2 id="actionLabel">Create Product Category</h2><br><br>
                <form class="form" id="addForm">                                      
                    <div class="form-group col-md-8 col-sm-12 col-xs-12">
                        <label>Category Name</label>
                        <input type="text" class="form-control" name="name" id="name"/>
                    </div>   
                    <div class="form-group col-md-6 col-sm-6 col-xs-12">
                    <a href="javascript:void(0);" class="btn btn-warning" onclick="$('#addUser').slideUp();">Cancel</a>
                    <a href="javascript:void(0);" class="btn btn-success" onclick="userAction('add')">Create Category</a>
                    </div>
                </form>
            </div>
         <div class="panel-body none formData" id="editForm">
                <h2 id="actionLabel">Edit Product Category</h2><br><br>
               <form class="form" id="userForm">                    
                    <div class="form-group col-md-10 col-sm-12 col-xs-12">
                        <label>Category Name</label>
                        <input type="hidden" name="idEdit" id="idEdit"/>
                        <input type="text" class="form-control" name="nameEdit" id="nameEdit"/>
                    </div>                             
                    <div class="form-group col-md-6 col-sm-6 col-xs-12">
                    <a href="javascript:void(0);" class="btn btn-warning" onclick="$('#editForm').slideUp();">Cancel</a>
                    <a href="javascript:void(0);" class="btn btn-success" onclick="userAction('edit')">Update Category</a>
                    </div>
                </form>
            </div>
   <div id="posts_content" class="table-responsive">  
       <?php
    
      include_once 'misc/Pagination.php';     

 
    $limit = 10;
    
    //get number of rows
    $sql = "SELECT count(cat_id) as code FROM item_category";
    $data1 = $dbOperation->getPages($sql);
    $rowCount = $data1['code'];    
    
    //initialize pagination class
    $pagConfig = array(
        'totalRows' => $rowCount,
        'perPage' => $limit,
        'link_func' => 'searchFilter'
    );
    $pagination =  new Pagination($pagConfig);
 
   $tableName = "item_category";  
 $queryConfig = array(
        'table' => $tableName,
        'limit' => $limit        
    );
 
   $data = $dbOperation->getdata($queryConfig);    
   $dbOperation->close();  
   if($data){ ?>
             <table class="table table-hover table-striped">
                 <thead>
                    <tr>
                        <th></th>                        
                        <th>Description</th>                        
                        <th>Date Created</th>  
                        <th>Date Updated</th>  
                        <th>Action</th>
                    </tr>
                </thead>
    <?php $count = 0;
   foreach ($data as $value) {
       $count++;
       $code = $value['cat_id'];  
       $date_created =  date_format(date_create($value['date_created']), 'F, j Y');
       $date_updated =  date_format(date_create($value['date_updated']), 'F, j Y');
      
       
       ?>
       <tr>     
                     <td> <?php echo $count ?></td>                    
                     <td> <?php echo $value['cat_name']; ?>  </td>                     
                      <td> <?php echo $date_created; ?>  </td>
                       <td> <?php if($date_updated != "November, 30 -0001") {echo $date_updated;} ?>  </td> 
                      <td>                            
                            <a href="javascript:void(0);" class="glyphicon glyphicon-edit" onclick="loadContent('<?php echo $code; ?>','edit')"></a>
                      </td>
                      
       </tr>   
       
  <?php }   
        
        ?>
             </table>          
   <?php echo $pagination->createLinks(); } 
   else {echo "<br><br><center><font color='red'><h2>Item Category Not Available</h2></font></center><br><br>";}
       
       ?>    
                   
          
    </div> 
    </div>
    </div>   

            
                       
         </div>          
        </div>
        <!-- /page content -->

        <!-- footer content -->
        <?php include_once 'include/footer.php';?>
        <!-- /footer content -->
      </div>
    </div>

   <?php include_once 'include/basic_js.php';?>
   
    <!-- Chart.js -->
    <!-- FastClick -->
    <script src="../vendors/fastclick/lib/fastclick.js"></script>
    <!-- NProgress -->
    <script src="../vendors/nprogress/nprogress.js"></script>    
      <script src="js/jquery-ui.min.js"></script>
  
    <script>            
       document.cookie = "current_page="+0; 
function searchFilter(page_num) { 
    page_num = page_num?page_num:0;
    document.cookie = "current_page=" +page_num; 
    
    var keywords = $('#keywords').val();
    var sortBy = $('#sortBy').val();
    var showLimit = $('#showLimit').val();    
    
    $.ajax({
        type: 'POST',
        url: '../database/category_create.php',
        data:'page='+page_num+'&keywords='+keywords+'&sortBy='+sortBy+'&limit='+showLimit+'&action_type=view',
        beforeSend: function () {
            $('.loading-overlay').show();
        },
        success: function (html) { 
            $('#posts_content').html(html);
            $('.loading-overlay').fadeOut("slow");
        }
    });
}

function userAction(type,id){
 if (confirm("Do you want to "+type+" this category?. Click OK to continue or Cancel to ignore") === true) {       
    id = (typeof id == "undefined")?'':id;
    var statusArr = {add:"added",edit:"updated",delete:"deleted"};
    var userData = '';
    if (type === 'add'){         
        userData = $("#addUser").find('.form').serialize()+'&action_type='+type;        
    }
    else if (type === 'edit'){                       
        userData = $("#editForm").find('.form').serialize()+'&action_type='+type;       
    }else{
        userData = 'action_type='+type+'&id='+id;
    }
    $.ajax({
        type: 'POST',
        url: '../database/category_create.php',
        data: userData,
        beforeSend: function () {
            $('.loading-overlay').show();
        },
        success:function(msg){           
        if($.trim(msg) === "ok"){
                alert('Product category '+statusArr[type]+' successfully.'); 
                 var allcookies = document.cookie;              
                 var cookiearray = allcookies.split(';'); 
                 var value = 0;
                 value = cookiearray[0].split('=')[1]; 
                 
                 value = parseInt(value);                 
                searchFilter(value); 
                
                $('.form')[0].reset();
                $('.formData').slideUp();               
            }        
        
        else{
                alert('Unable to '+type+' item category at this time.'+msg);
            }
        }
    });
    }else{}
}

function loadContent(id, type){   
    $.ajax({
        type: 'POST',
        dataType:'JSON',
        url: '../database/category_create.php',
        data: 'action_type=data&id='+id,
        beforeSend: function () {
            $('.loading-overlay').show();
        },
        success:function(data){  
            if(type === 'edit') {              
                $('#idEdit').val(data.cat_id);                
                $('#nameEdit').val(data.cat_name);
                     
            $('#editForm').slideDown();
             $('.loading-overlay').hide();
                 } 
            else{
                $('.loading-overlay').hide();
                alert("Refresh your browser");
                 
                 }
        }
    });
    
}


    </script>
    </body>
</html>
