<?php session_start();
include_once '../config/config.php';
include_once '../database/db.php'; 
$dbOperation = new DB();
       
?> 
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Just Steph Venture</title>
    <link rel="icon" type="image/jpg" href="../home/images/steph_logo.png" /> 
    <?php include_once 'include/basic_css.php';?>
     <link href="../vendors/nprogress/nprogress.css" rel="stylesheet">
     <link href="css/pagination.css" rel="stylesheet">
      
     <style>
        #ui-datepicker-div {
    z-index:2 !important;
    background: #002;
        }
        .ui-state-default{
            color: #F4FF77;
            
        }
     </style>
  </head>

  <body class="nav-md">
    <div class="container body">
      <div class="main_container">
          <!-- side bar -->
       <?php include_once 'include/sidebar.php';?>

        <!-- top navigation -->
        <?php include_once 'include/top_navigation.php';?>
       

        <!-- page content -->
        <div class="right_col" role="main">
         <div class="">
            <div class="page-title">
              <div class="title_left">
                <h3>ITEM SALES MONTHLY REPORT</h3>
              </div>

              <div class="title_right">
                <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
                  
                </div>
              </div>
            </div>            
            <div class="row">                
             <div id="dataModal" class="modal fade">
 <div class="modal-dialog modal-lg">
  <div class="modal-content">
   <div class="modal-header">
    <button type="button" class="close" data-dismiss="modal">&times;</button>
    <h4 class="modal-title"></h4>
   </div>
   <div class="modal-body" id="employee_detail">
    
   </div>
   <div class="modal-footer">
    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
   </div>
  </div>
 </div>
</div>                   
            </div>
            
            
            <div class="row" style="margin: 10px 20px 10px 10px; width: 98%; font-size: 14px;">
     <div class="panel panel-default users-content">
      <div class="panel-heading">
          <div class="post-search-panel">   
    <select id="sortBy" onchange="searchFilter()">
    <option value="">Sort Quantities</option>
        <option value="asc">Ascending</option>
        <option value="desc">Descending</option>
    </select>
    <select id="showLimit" onchange="searchFilter()">       
        <option value="20">20</option>
        <option value="30">30</option>
        <option value="40">40</option>
        <option value="50">50</option>
        <option value="90">90</option>
    </select>
    <select id="s_mth" onchange="searchFilter()">       
        <option value="1">January</option>
        <option value="2">February</option>
        <option value="3">March</option>
        <option value="4">April</option>
        <option value="5">May</option>
        <option value="6">June</option>
        <option value="7">July</option>
        <option value="8">August</option>
        <option value="9">September</option>
        <option value="10">October</option>
        <option value="11">November</option>
        <option value="12">December</option>       
    </select>          
    <select id="s_yr" onchange="searchFilter()" >  
       <?php for($i=0; $i < 20; $i++){ ?>
        <option value="<?= date("Y") - $i; ?>"><?= date("Y") - $i; ?></option>
          <?php } ?>   
    </select> 
      <span class="loading-overlay"><img src="../build/images/loading2.gif"/></span>
   
          </div>
          </div>      
        
   <div id="posts_content" class="table-responsive">  
       <?php
    
      include_once 'misc/Pagination.php';     
 
    $limit = 20;
       
    $year = (int)date('Y'); $month = (int)date('m'); $day = (int)date('d');
    $whereSQL =  " WHERE year_report = '$year' AND month_report = '$month' " ;
    //2018-03-11 16:31:02
    $sql = "SELECT count(item_id) as code FROM item_sales ".$whereSQL;
    $data1 = $dbOperation->getPages($sql);
    $rowCount = $data1['code'];    
    
    //initialize pagination class
    $pagConfig = array(
        'totalRows' => $rowCount,
        'perPage' => $limit,
        'link_func' => 'searchFilter'
    );
    $pagination =  new Pagination($pagConfig);
 
   $tableName = "item_sales";  
   $orderSQL = " ORDER BY month_total DESC ";
 $queryConfig = array(
        'table' => $tableName,
        'where' => $whereSQL,
        'limit' => $limit,        
        'order_by' => $orderSQL
    );
 
   $data = $dbOperation->getdata($queryConfig);    
   $dbOperation->close();  
   //print_r($data);
   if($data){ ?>
             <table class="table table-hover table-striped table-bordered">
                 <thead>
                    <tr>
                        <th></th> 
                        <th>DESCRIPTION</th>
                        <th>YEAR</th> 
                        <th>MONTH</th>  
                        <th>WEEK 1</th> 
                        <th>WEEK 2</th> 
                        <th>WEEK 3</th>  
                        <th>WEEK 4</th> 
                        <th>MONTH TOTAL</th>                        
                    </tr>
                </thead>
    <?php $count = 0;
   foreach ($data as $value) {
       $count++;
       $item_id = $value['item_id'];     
       ?>
       <tr>     
                     <td> <?php echo $count ?></td>              
                     <td> <?php echo $value['description']; ?>  </td>
                     <td> <?php echo $value['year_report']; ?>  </td> 
                     <td> <?php echo $value['month_word']; ?>  </td> 
                     <td> <?php echo number_format($value['week1'],0); ?>  </td> 
                     <td> <?php echo number_format($value['week2'],0); ?>  </td>
                     <td> <?php echo number_format($value['week3'],0); ?>  </td>
                     <td> <?php echo number_format($value['week4'],0); ?>  </td>
                     <td> <?php echo number_format($value['month_total'],0); ?>  </td>              
       </tr>   
       
  <?php }   
        
        ?>
             </table>          
   <?php echo $pagination->createLinks(); } 
   else {echo "<br><br><center><font color='red'><h2>Record Not Available</h2></font></center><br><br>";}
       
       ?>    
                   
          
    </div> 
    </div>
    </div>   

            
                       
         </div>          
        </div>
        <!-- /page content -->

        <!-- footer content -->
        <?php include_once 'include/footer.php';?>
        <!-- /footer content -->
      </div>
    </div>

   <?php include_once 'include/basic_js.php';?>
   
    <!-- Chart.js -->
    <!-- FastClick -->
    <script src="../vendors/fastclick/lib/fastclick.js"></script>
    <!-- NProgress -->
    <script src="../vendors/nprogress/nprogress.js"></script>    
      <script src="js/jquery-ui.min.js"></script>
  
    <script>            
       document.cookie = "current_page="+0; 
function searchFilter(page_num) { 
    page_num = page_num?page_num:0;
    document.cookie = "current_page=" +page_num; 
        
    var sortBy = $('#sortBy').val();
    var showLimit = $('#showLimit').val();  
    var s_yr = $('#s_yr').val();
    var s_mth = $('#s_mth').val();   
    
    $.ajax({
        type: 'POST',
        url: '../database/sales_report.php',
        data:'page='+page_num+'&sortBy='+sortBy+'&limit='+showLimit+'&s_yr='+s_yr+'&s_mth='+s_mth+'&action_type=item_monthly',
        beforeSend: function () {
            $('.loading-overlay').show();
        },
        success: function (html) { 
            $('#posts_content').html(html);
            $('.loading-overlay').fadeOut("slow");
        }
    });
}
function fdate(dval){   
            var date1 = JSON.stringify(dval);
            var res = date1.split(",");
            var res2 = res[0].replace('{"date":', '');            
            var dateval = JSON.parse(res2);            
            return dateval;    
}
function fNum(num){
    var num2 = parseInt(num);
    num2 = num2.toFixed(0).replace(/(\d)(?=(\d{3})+\.)/g, '$1,');
    return num2;
}

function viewItem(id,yr){   
    $.ajax({
        type: 'POST',
        dataType:'JSON',
        url: '../database/sales_report.php',
        data: 'action_type=data&id='+id+'&yr='+yr,
        beforeSend: function () {
            $('.loading-overlay').show();
        },
        success:function(data){           
                
            var display ="<div class='table-responsive'> ";            
            display +="<table class='table table-hover' border='1'>";
            display += "<thead><tr><th colspan='2'>Description</th><th>Year</th><th>Quantities Sold</th><th colspan='2'>Date Last Updated</th></tr></thead>"; 	
            display += "<tr><td colspan='2'>"+data.description+"</td><td>"+data.year_report+"</td><td>"+fNum(data.quantity)+"</td><td colspan='2'>"+fdate(data.date_updated)+"</td></tr>";  
            display += "<tr><td colspan='6'></td></tr>"; 
              
            display += "<thead><tr><th>January</th><th>February</th><th>March</th><th>April</th><th>May</th><th>June</th></tr></thead>"; 	
            display += "<tr><td>"+fNum(data.month1)+"</td><td>"+fNum(data.month2)+"</td><td>"+fNum(data.month3)+"</td><td>"+fNum(data.month4)+"</td><td>"+fNum(data.month5)+"</td><td>"+fNum(data.month6)+"</td></tr>";  
            display += "<tr><td colspan='6'></td></tr>"; 
            
            display += "<thead><tr><th>July</th><th>August</th><th>September</th><th>October</th><th>November</th><th>December</th></tr></thead>"; 	
            display += "<tr><td>"+fNum(data.month7)+"</td><td>"+fNum(data.month8)+"</td><td>"+fNum(data.month9)+"</td><td>"+fNum(data.month10)+"</td><td>"+fNum(data.month11)+"</td><td>"+fNum(data.month12)+"</td></tr>";  
            display += "<tr><td colspan='6'></td></tr>";           
            
            display += "</table></div>";          
            $('#employee_detail').html(display);
            $('#dataModal').modal({backdrop: false});           
            $('.loading-overlay').fadeOut("slow");
        }
    });
    
}

    </script>
    </body>
</html>
