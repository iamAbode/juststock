﻿<?php session_start();
include_once '../config/config.php';
include_once '../database/db.php'; 
$dbOperation = new DB();       
?> 
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Create Sales </title>
     <link rel="icon" type="image/jpg" href="../home/images/steph_logo.png" /> 
    <?php include_once 'include/basic_css.php';?>
     <link href="css/smart_cart.min.css" rel="stylesheet" type="text/css" />
    <style>
    .thumb{
    display: block;
    padding: 4px;
    margin-bottom: 20px;
    line-height: 1.42857143;
    background-color: #fff;
    border: 1px solid #ddd;
    border-radius: 4px;
    -webkit-transition: border .2s ease-in-out;
    -o-transition: border .2s ease-in-out;
    transition: border .2s ease-in-out;            
        }
        
    </style>
  </head>

  <body class="nav-md">
    <div class="container body">
      <div class="main_container">
          <!-- side bar -->
        <?php include_once 'include/sidebar.php';?>

        <!-- top navigation -->
        <?php include_once 'include/top_navigation.php';?>
       

        <!-- page content -->
        <div class="right_col" role="main">         

          <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
              <div class="dashboard_graph">

                <div class="row x_title">
                  <div class="col-md-12">
                      <h3><strong>CREATE SALES</strong> </h3>
                  </div>
                  
                </div>
        <?php        
        
   $tableName = "items";  
 $queryConfig = array(
        'table' => $tableName    
    );
 
   $data = $dbOperation->getdata($queryConfig);   
   $dbOperation->close(); 
   
   $id = $data[0]['item_id'];
   $dname = $data[0]['description']; $sp = $data[0]['selling_price']; $qty = $data[0]['quantity']; 
   $detail =  "<font color='green'>Category</font>- ".$data[0]['category']." / <font color='green'>Make-</font> ".$data[0]['brand'];
      
        ?>
               
        <div class="row">
            <div class="col-md-6">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <input list="ice-cream-flavors" onfocusout="addDiv()" id="product_cat" name="product_cat" class="form-control" placeholder="Enter product name, make or id and click outside this input field" onchange="addDiv()" /> 
                        
                        <datalist id="ice-cream-flavors">
                            <?php 
                                   foreach ($data as $value) {                                  
    $sp2 = $value['selling_price']; $qty2 = $value['quantity']." in stock"; 
   $detail2 =  "<font color='green'>Category</font>-".$value['category']."/ <font color='green'>Make</font>- ".$value['brand'];
    //$detail2="details is not available";       
                                       
                                       ?>
                               <option value="<?php echo $value['description']." [".$value['brand']."] : ".$value['item_id']; ?>" />
                                
                                                        <?php }  
                            ?>         
                        </datalist>
                        
                        
                                          
                    </div>
                    <div class="panel-body">
                        <div class="row" id="product_show">
                            <!-- BEGIN PRODUCTS -->                                             
                            <div class="col-md-12 col-sm-12">
                                <div class="sc-product-item thumb">
                                     <div class="caption">
                                        <h4 data-name="product_name" id="product_name"><?php echo $dname; ?></h4>
                                        <p data-name="product_desc" id="product_desc" ><?php echo $detail; ?></p>
                                        <hr class="line">
                                        
                                        <div>                                      
                                            <div class="form-group2">
                                                <input class="sc-cart-item-qty" name="product_quantity" min="1" value="1" type="number">
                              &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <small id="bonus_percent"><?php echo $qty;?> in stock</small>
                                            </div> <br />
                                            <strong class="price pull-left" id="price">₦<?php echo number_format($sp,2); ?></strong>
                                             
                                            <input name="product_price" id="product_price" value="<?php echo $sp; ?>" type="hidden" />
                                            <input name="product_id" id="product_id" value="<?php echo $id; ?>" type="hidden" />
                                            
                                            <button class="sc-add-to-cart btn btn-success btn-sm pull-right">Add to cart</button>
                                        </div>                                       
                                        <div class="clearfix"></div>                                         
                                    </div>                                    
                                </div>
                                <a class="btn btn-warning btn-sm pull-center" id="edit_price" onclick="edit_price()">Edit Price</a>
                                <div id="npdiv" style="display:none">
                                    <label>Enter new item price for this sale</label><br>
                                <input id="nprice" name="nprice" type="text" placeholder="e.g 13,800">                                
                                <a class="btn btn-success btn-sm pull-center" onclick="adjust_price()">Adjust Price</a>                                
                                </div>
                                
                            </div>   
                            <!-- END PRODUCTS -->
                        </div>
                    </div>
                </div>
                
            </div>
            <div class="col-md-1"></div>
            <aside class="col-md-5">
                
                <!-- Cart submit form -->
                <form action="process_order.php" method="POST"> 
                    <!-- SmartCart element -->
                    <div id="smartcart"></div>
                </form>
                
            </aside>
        </div>
              

                <div class="clearfix"></div>
              </div>
            </div>

          </div>
          <br />
          <div style="display: none">
       
                            <?php 
                                   foreach ($data as $value) {                                  
    $sp2 = $value['selling_price']; $qty2 = $value['quantity']." in stock"; 
   $detail2 =  "<font color='green'>Category</font>-".$value['category']."/ <font color='green'>Make</font>- ".$value['brand'];
    //$detail2="details is not available";       
                                       
                                       ?>
          <input id="<?php echo $value['item_id']; ?>" value="<?php 
        echo $value['item_id'].":".$value['description'].":".$detail2.":".$sp2.":".$qty2;
                               
                               ?>" />
                                
                                                        <?php }  
                            ?>                         
                        
        
        
       </div>
         


         
        </div>
        <!-- /page content -->

        <!-- footer content -->
        <?php include_once 'include/footer.php';?>
        <!-- /footer content -->
      </div>
    </div>

   <?php include_once 'include/basic_js.php';?>
   
    <script src="js/jquery.smartCart.min.js" type="text/javascript"></script>
    <!-- Initialize -->
    <script type="text/javascript">        
        $(document).ready(function(){
            // Initialize Smart Cart    	
            $('#smartcart').smartCart();            
           
		});
         
         
         
         
         
        function edit_price(){
            $("#nprice").val("");
            $("#npdiv").show();
            $("#edit_price").hide();
        }  
        function adjust_price(){
            var price = $("#nprice").val(); 
            if(price){
            price = parseInt(price.replace(/[^\d]/g, ''));
            $("#product_price").val(price);           
             var nprice = price.toFixed(2).replace(/(\d)(?=(\d{3})+\.)/g, '$1,');
                $("#price").html("₦"+nprice);                
                $("#npdiv").hide();
                $("#edit_price").show();
            }
            else{
                alert("Empty price");
                $("#npdiv").hide();
                $("#edit_price").show();
            }
                
        }   
        function addDiv(){             
                var item = $('#product_cat').val();
                var itemArr = item.split(":");                
                var item_id = itemArr[1].trim();                   
             var  sel = $('#'+item_id).val();
            
             var content = sel.split(":");            
             $("#product_id").val(content[0]);
              $("#product_price").val(content[3]);
               $("#product_name").html(content[1]);
               var price = parseInt(content[3]);
                price = price.toFixed(2).replace(/(\d)(?=(\d{3})+\.)/g, '$1,');
                $("#price").html("₦"+price); 
                 $("#product_desc").html(content[2]); 
                 $("#bonus_percent").html(content[4]);               
                 $("#edit_price").show();
                 $("#npdiv").hide();
                 
                         } 
    </script>  
      
    </body>
</html>
