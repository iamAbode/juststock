<?php session_start();
include_once '../config/config.php';
include_once '../database/db.php'; 
$dbOperation = new DB();
         
?> 
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Just Steph Venture</title>
    <link rel="icon" type="image/jpg" href="../home/images/steph_logo.png" /> 
    <?php include_once 'include/basic_css.php';?>
     <link href="../vendors/nprogress/nprogress.css" rel="stylesheet">
     <link href="css/pagination.css" rel="stylesheet">
      
     <style>
        #ui-datepicker-div {
    z-index:2 !important;
    background: #002;
        }
        .ui-state-default{
            color: #F4FF77;
            
        }
        @media print {
            body{
                display: table;
                table-layout: fixed;
                
            }
        }
       
     </style>
  </head>

  <body class="nav-md">
    <div class="container body">
      <div class="main_container">
          <!-- side bar -->
       <?php include_once 'include/sidebar.php';?>

        <!-- top navigation -->
        <?php include_once 'include/top_navigation.php';?>
       

        <!-- page content -->
        <div class="right_col" role="main">
         <div class="">
            <div class="page-title">
              <div class="title_left">
                <h3>Sales Detail </h3>
              </div>

              
            </div>            
            <div class="row">                
             <div id="dataModal1" class="modal fade">
 <div class="modal-dialog modal-lg">
  <div class="modal-content">
   <div class="modal-header">
    <button type="button" class="close" data-dismiss="modal">&times;</button>
    <h4 class="modal-title"></h4>
   </div>
   <div class="modal-body" id="employee_detail">
    
   </div>
   <div class="modal-footer">
    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
   </div>
  </div>
 </div>
</div>                   
            </div>
            
            
            <div class="row" style="margin: 10px 20px 10px 10px; width: 98%; font-size: 14px;">
     <div class="panel panel-default users-content">
      <div class="panel-heading">
          
          </div>      
         
         <div class="panel-body none formData" id="editForm">
           <h2 id="actionLabel">Sales Detail</h2><br>
              
            </div>
         <div id="posts_content" class="table-responsive"> <br> 
       <?php
    
      $sales_id = $dbOperation->bite_string($_GET['id']);
   $p_type = array('N' => 'None','C' => 'Cash','P' => 'POS','T' => 'Online Transfer');
   $t_type = array('P' => 'Paid','C' => 'Credit');   
    
 $queryConfig = array('table' => "sales", 'where' => " WHERE sales_id = '$sales_id' ", 'return_type' => "single");
 $queryConfig2 = array('table' => "sales_detail", 'where' => " WHERE sales_id = '$sales_id' ");
 
   $data = $dbOperation->getdata($queryConfig); 
   $data2 = $dbOperation->getdata($queryConfig2);       
   $dbOperation->close();  
   if($data){ ?>
       <div class="col-md-3">
       <table class="table table-bordered">
                 <tr>                              
                     <td> <strong>Sales ID:</strong><br><?php echo $data['sales_id']; ?>  </td>
                     <td><strong>Prepared By:</strong><br> <?php echo $data['sale_by']; ?>  </td> 
                 </tr>
                 <tr>
                     <td><strong>Customer:</strong><br> <?php echo $data['buyer']; ?>  </td>
                     <td><strong>Payment Type:</strong><br> <?php echo $p_type[trim($data['p_type'])]; ?>  </td>
                 </tr>
                 <tr>
                      <td><strong>No. of Product:</strong><br> <?php echo $data['no_of_item']; ?>  </td>
                     <td><strong>Transaction Type:</strong><br> <?php echo $t_type[trim($data['t_type'])]; ?>  </td>  
                 </tr>                 
                 <tr>
                      <td><strong>Date Sold:</strong><br> <?php echo date_format(date_create($data['sale_date']), 'd/m/Y'); ?>  </td>
                     <td><strong>Date Updated:</strong><br> <?php 
                                $dt = date_format(date_create($data['date_updated']), 'd/m/Y');
                           if($dt != "30/11/-0001") echo $dt;
                       ?>  
                     </td>                       
                 </tr>  
                <tr>
                    <td colspan="2"><strong>Comment on sales:</strong><br> <?php echo $data['comment']; ?>  </td> 
                </tr>
       </table>         
       </div>
       <div class="col-md-1"></div>
       <div class="col-md-8" style="border:1px solid gray;">
             <table class="table table-hover">
                 <thead>
                    <tr>
                        <th>S/N</th>                         
                        <th>DESCRIPTION</th> 
                        <th>QTY</th> 
                        <th>UNIT PRICE</th>                        
                        <th>TOTAL(₦)</th>                      
                    </tr>
                </thead>
    <?php $count = 0;
   foreach ($data2 as $value) {
       $count++;     
       ?>
       <tr>     
                     <td> <?php echo $count ?></td>               
                     <td> <?php echo $value['description']; ?>  </td>
                     <td> <?php echo $value['quantity']; ?>  </td>                                        
                     <td> <?php echo number_format($value['price'],2); ?>  </td>                     
                     <td> <?php echo number_format($value['total'],2); ?>  </td>                       
       </tr>   
       
  <?php } ?>
       <tr><td> </td> <td> <strong>TOTAL</strong> </td> <td>  </td> <td>  </td>                     
           <td><strong> <?php echo number_format($data['amount'],2); ?> </strong> </td>                 
       </tr> 
             </table> 
           <button type="button" class="btn btn-default" onclick="viewReceipt()">Preview Receipt</button> 
           &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
           <button type="button" class="btn btn-success" onclick="printReceipt()">Print Receipt</button> 
       </div>     
   <?php  } 
   else {echo "<br><br><center><font color='red'><h2> Sales record not available</h2></font></center><br><br>";}
       
       ?>    
                   
          
    </div> 
      
         
    </div>
    </div>   
 <div class="row">                
             <div id="dataModal" class="modal fade">
 <div class="modal-dialog modal-sm">
  <div class="modal-content">
   <div class="modal-header">
    <button type="button" class="close" data-dismiss="modal">&times;</button>
    <h4 class="modal-title">Just Steph Venture</h4>
   </div>
      <div class="modal-body">
          <div id="sales_detail">
       <h4><strong>Just Steph Venture</strong></h4> 
       <hr>
       <span style="font-size: 12px">Customer: <strong style=" font-size: 12px"><?php echo $data['buyer']; ?></strong></span>
       <hr>
       <table style=" font-size: 8px">            
         <thead><tr><th></th><th>Product</th><th>QTY</th><th>Price</th><th>Total(₦)</th></tr></thead>    
    <?php $count = 0;
   foreach ($data2 as $value) {
       $count++;     
       ?>
       <tr>     
                     <td> <?php echo $count ?></td>               
                     <td> <?php echo $value['description']; ?>  </td>
                     <td> <?php echo $value['quantity']; ?>  </td>                                        
                     <td> <?php echo number_format($value['price'],2); ?>  </td>                     
                     <td> <?php echo number_format($value['total'],2); ?>  </td>                       
       </tr>   
       
  <?php } ?>
       <tr><td> </td> <td> <strong>TOTAL</strong> </td> <td>  </td> <td>  </td>                     
           <td><strong> <?php echo number_format($data['amount'],2); ?> </strong> </td>                 
       </tr>
       <tr><td colspan="5"><hr></td></tr>
        <tr><td colspan="5"><hr></td></tr> 
		<tr><td colspan="5"><hr></td></tr>   
       </table>    
   </div>
      </div>    
   <div class="modal-footer">
       <button type="button" class="btn btn-success" onclick="printReceipt()">Print Receipt</button>   
    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
   </div>
  </div>
 </div>
</div>                   
            </div>  
            
                       
         </div>          
        </div>
        <!-- /page content -->

        <!-- footer content -->
        <?php include_once 'include/footer.php';?>
        <!-- /footer content -->
      </div>
    </div>

   <?php include_once 'include/basic_js.php';?>
   
    <!-- Chart.js -->
    <!-- FastClick -->
    <script src="../vendors/fastclick/lib/fastclick.js"></script>
    <!-- NProgress -->
    <script src="../vendors/nprogress/nprogress.js"></script>    
      <script src="js/jquery-ui.min.js"></script>
  
    <script>            
       document.cookie = "current_page="+0; 
function searchFilter(page_num) { 
    page_num = page_num?page_num:0;
    document.cookie = "current_page=" +page_num; 
    
    var keywords = $('#keywords').val();
    var sortBy = $('#sortBy').val();
    var showLimit = $('#showLimit').val();  
    var cat = $('#cat').val();
    var brd = $('#brd').val(); 
    
    $.ajax({
        type: 'POST',
        url: '../database/item_capture.php',
        data:'page='+page_num+'&keywords='+keywords+'&sortBy='+sortBy+'&limit='+showLimit+'&cat='+cat+'&brd='+brd+'&action_type=view',
        beforeSend: function () {
            $('.loading-overlay').show();
        },
        success: function (html) { 
            $('#posts_content').html(html);
            $('.loading-overlay').fadeOut("slow");
        }
    });
}
function printReceipt(){  
            var divContents = $("#sales_detail").html();
            var printWindow = window.open('', '', 'width=400');
            //printWindow.document.write('<html><head><title>Sales</title>');
            //printWindow.document.write('</head><body >');
            printWindow.document.write(divContents);
           // printWindow.document.write('</body></html>');
            printWindow.document.close();
            printWindow.print();  
            
            //setTimeout(' window.location.href = "sales_record.php"; ',4000);
 
}
 function viewReceipt(){
     $('#dataModal').modal({backdrop: false});
 }
    </script>
    </body>
</html>
