<footer>
          <div class="pull-left">
            <center>&copy; <?php echo date('Y'); ?></center>
          </div>
          <div class="pull-right">
            Powered by Rapidbite Technologies
          </div>
          <div class="clearfix"></div>
</footer>