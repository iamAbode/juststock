<div class="top_nav">
          <div class="nav_menu">
            <nav>
              <div class="nav toggle">
                <a id="menu_toggle"><i class="fa fa-bars"></i></a>
              </div>

              <ul class="nav navbar-nav navbar-right">
                <li class="">
                  <a href="javascript:;" class="user-profile dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
                      <img src="../home/images/rapidbite.png" alt=""><?= $_SESSION['username'] ?>
                    <span class=" fa fa-angle-down"></span>
                  </a>
                  <ul class="dropdown-menu dropdown-usermenu pull-right">
                    <li><a href="javascript:;">Help</a></li>
                    <li><a href="../logout.php"><i class="fa fa-sign-out pull-right"></i> Log Out</a></li>
                  </ul>
                </li>
                  <?php 
                     $user_id = $_SESSION['user_id'];
                        $tablealert = "items";                                       
                        $wherealert = " WHERE quantity < restock ";
                        $queryalert = array('table' => $tablealert, 'where' => $wherealert);
                        $alert = $dbOperation->getdata($queryalert);                                                  
                    
                     ?>
                
                 <li role="presentation" class="dropdown">
                     <?php if (!empty($alert)){
                               $a = count($alert);
                           ?>
                  <a href="javascript:;" class="dropdown-toggle info-number" data-toggle="dropdown" aria-expanded="false">
                    <i class="fa fa-calendar-minus-o"></i>
                    <span class="badge bg-red"><?= $a ?></span>
                  </a>
                  <ul id="menu1" class="dropdown-menu list-unstyled msg_list" role="menu">
                      <?php foreach ($alert as $value) { ?> 
                    <li>
                      <a href="#">
                        <span class="image"><i class="fa fa-calendar-minus-o"></i></span>
                        <span>
                          <span> <?= "<font color='darkblue'>".$value['description']."</font>"; ?></span>
                          <span class="time"></span>
                        </span>
                        <span class="message">
                          <?= "Stock level: <font color='red'>".$value['quantity']."</font> is low"; ?> 
                        </span>
                      </a>
                    </li> 
                    <?php }?>    
                    <li>
                      <div class="text-center">
                        
                      </div>
                    </li>
                  </ul>
                     <?php } ?>
                </li>         
              </ul>
            </nav>
          </div>
        </div>