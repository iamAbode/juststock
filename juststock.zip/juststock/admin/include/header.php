<nav class="navbar navbar-default navbar-fixed-top" role="navigation">
        <div class="container-fluid">				
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="divider"></div>            
			<div class="">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                      <span class="sr-only">Toggle navigation</span>
                      
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
               <img class="sm-margin" width="50" height="50" src="home/images/steph_logo.png" style="border-radius:5px" />
		                 
            </div>			
            
        </div>
        <!-- /.container -->
    </nav>	
	<br><br>
 