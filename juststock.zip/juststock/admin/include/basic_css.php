<?php
 echo "
    <!-- Bootstrap -->
    <link href='../vendors/bootstrap/dist/css/bootstrap.min.css' rel='stylesheet'>
    <!-- Font Awesome -->
    <link href='../vendors/font-awesome/css/font-awesome.min.css' rel='stylesheet'>      
   
    <!-- Custom Theme Style -->
    <link href='../build/css/custom.min.css' rel='stylesheet'> ";

?>