 <div class="col-md-3 left_col">
          <div class="left_col scroll-view">
            <div class="navbar nav_title" style="border: 0;">
                <a href="index.php" class="site_title"><i class="fa fa-paw"></i> <span>Back Office</span></a>
            </div>

            <div class="clearfix"></div>

            <!-- menu profile quick info -->
            <div class="profile clearfix">
              <div class="profile_pic">
                  <img src="../home/images/rapidbite.png" alt="..."  height="50" class="img-circle profile_img">
              </div>
              <div class="profile_info">               
                <h6><?= date("l, M d, Y"); ?></h6>
              </div>
            </div>
            <!-- /menu profile quick info -->
                
            <br />

            <!-- sidebar menu -->
            <div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
              <div class="menu_section">
                <h3>Menu</h3>
                <ul class="nav side-menu">
                    <li><a><i class="fa fa-industry"></i>ITEM MANAGEMENT<span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a href="capture_item.php">Capture Item</a></li>  
                      <?php if(trim($_SESSION['role']) == "AU"){ ?>
                      <li><a href="update_stock.php">Update Stock</a></li> 
                      <?php } ?>
                      <li><a href="create_category.php">Create Category</a></li>
                      <li><a href="create_brand.php">Create Brand</a></li>
                      <li><a href="create_unit.php">Unit of Measurement</a></li>                      
                    </ul>
                  </li>                  
                    <li><a><i class="fa fa-money"></i>TRANSACTION <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a href="book_order.php">Create Sales</a></li>  
                      <li><a href="sales_record.php">Sales Record</a></li>
                      <li><a href="credit_register.php">Credit Register</a></li> 
                      <li><a href="return_stock.php">Return Stock</a></li>  
                    </ul>
                  </li>
                   <?php if(trim($_SESSION['role']) == "AU"){ ?>
                  <li><a><i class="fa fa-compress"></i> GOODS TRANSFER <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a href="transfer_goods.php">Transfer Goods</a></li>
                      <li><a href="trans_record.php">Transfer Record</a></li>                      
                    </ul>
                  </li> 
                 
                  <li><a><i class="fa fa-bar-chart"></i> MIS & REPORTS<span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a href="stock_register.php">Stock Register</a></li> 
                      <li><a href="item_transfer.php">Transfer Register</a></li>
                      <li><a href="sales_daily.php">Daily Sales</a></li>
                      <li><a href="item_sales.php">Daily Item Sales</a></li>
                      <li><a href="sales_yearly.php">Sales Report</a></li>    
                      <li><a href="returned_stock.php">Stock Returned</a></li> 
                      <li><a href="item_sales_yearly.php">Item Yearly Sales</a></li>
                      <li><a href="item_sales_monthly.php">Item Monthly Sales</a></li> 
                      <li><a href="income_report.php">Income Report</a></li>
                    </ul>
                  </li>                 
                  <li><a><i class="fa fa-user-md"></i>SYS ADMIN<span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a href="users.php">Manage Users</a></li>
                                       
                    </ul>
                  </li> 
                   <?php } ?>
                </ul>
              </div>
              
            </div>
            <!-- /sidebar menu -->

            <!-- /menu footer buttons -->
            <div class="sidebar-footer hidden-small">
              <a data-toggle="tooltip" data-placement="top" title="Settings">
                <span class="glyphicon glyphicon-cog" aria-hidden="true"></span>
              </a>
              <a data-toggle="tooltip" data-placement="top" title="FullScreen">
                <span class="glyphicon glyphicon-fullscreen" aria-hidden="true"></span>
              </a>
              <a data-toggle="tooltip" data-placement="top" title="Lock">
                <span class="glyphicon glyphicon-eye-close" aria-hidden="true"></span>
              </a>
              <a data-toggle="tooltip" data-placement="top" title="Logout" href="../logout.php">
                <span class="glyphicon glyphicon-off" aria-hidden="true"></span>
              </a>
            </div>
            <!-- /menu footer buttons -->
          </div>
        </div>