<div class="row tile_count">
            <div class="col-md-3 col-sm-4 col-xs-6 tile_stats_count">
              <span class="count_top"><i class="fa fa-user"></i> Today's Sales</span>
              <div class="count"><?= number_format($data2['stoday'],2); ?></div>
              <?php $info1 = "<i class='red'><i class='fa fa-sort-desc'></i> </i>";
                     if($data2['stoday'] > $data3['sytd']) {$info1 = "<i class='green'><i class='fa fa-sort-asc'></i> </i>";}  
              ?>
              <span class="count_bottom"><?= $info1; ?> From From Yesterday</span>
            </div>
            <div class="col-md-3 col-sm-4 col-xs-6 tile_stats_count">
              <span class="count_top"><i class="fa fa-clock-o"></i> Yesterday's Sales</span>
              <div class="count"><?= number_format($data3['sytd'],2); ?></div>
              <span class="count_bottom">From last Week</span>
            </div>
            <div class="col-md-2 col-sm-4 col-xs-6 tile_stats_count">
              <span class="count_top"><i class="fa fa-user"></i> Total Stock</span>
              <div class="count green"><?= number_format($data['tqty'],0); ?></div>
              <span class="count_bottom"> In Store</span>
            </div>
            <div class="col-md-3 col-sm-4 col-xs-6 tile_stats_count">
              <span class="count_top"><i class="fa fa-user"></i> Total Sales</span>
              <div class="count"><?= number_format($data4['slst'],0); ?></div>
              <span class="count_bottom"> Last Seven Days</span>
            </div>            
          </div>