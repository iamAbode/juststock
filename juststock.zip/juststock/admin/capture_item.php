<?php session_start();
include_once '../config/config.php';
include_once '../database/db.php'; 
$dbOperation = new DB();
        $querycat = array('table' => 'item_category'); 
        $datacat = $dbOperation->getdata($querycat);   
        $querybrd = array('table' => 'brand_category'); 
        $databrd = $dbOperation->getdata($querybrd); 
        $querymst= array('table' => 'unit_measure'); 
        $datamst = $dbOperation->getdata($querymst); 
?> 
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Just Steph Venture</title>
    <link rel="icon" type="image/jpg" href="../home/images/steph_logo.png" /> 
    <?php include_once 'include/basic_css.php';?>
     <link href="../vendors/nprogress/nprogress.css" rel="stylesheet">
     <link href="css/pagination.css" rel="stylesheet">
      
     <style>
        #ui-datepicker-div {
    z-index:2 !important;
    background: #002;
        }
        .ui-state-default{
            color: #F4FF77;
            
        }
     </style>
  </head>

  <body class="nav-md">
    <div class="container body">
      <div class="main_container">
          <!-- side bar -->
       <?php include_once 'include/sidebar.php';?>

        <!-- top navigation -->
        <?php include_once 'include/top_navigation.php';?>
       

        <!-- page content -->
        <div class="right_col" role="main">
         <div class="">
            <div class="page-title">
              <div class="title_left">
                <h3>Manage Item </h3>
              </div>

              <div class="title_right">
                <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
                  <div class="input-group">
                    <input id="keywords" name="keywords" type="text" class="form-control" placeholder="Search for..." onkeyup="searchFilter()">
                    <span class="input-group-btn">
                              <button class="btn btn-default" type="button" onclick="searchFilter()">Go!</button>
                          </span>
                  </div>
                </div>
              </div>
            </div>            
            <div class="row">                
             <div id="dataModal" class="modal fade">
 <div class="modal-dialog modal-lg">
  <div class="modal-content">
   <div class="modal-header">
    <button type="button" class="close" data-dismiss="modal">&times;</button>
    <h4 class="modal-title"></h4>
   </div>
   <div class="modal-body" id="employee_detail">
    
   </div>
   <div class="modal-footer">
    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
   </div>
  </div>
 </div>
</div>                   
            </div>
            
            
            <div class="row" style="margin: 10px 20px 10px 10px; width: 98%; font-size: 14px;">
     <div class="panel panel-default users-content">
      <div class="panel-heading">
          <div class="post-search-panel">   
    <select id="sortBy" onchange="searchFilter()">
        <option value="">Sort By Date</option>
        <option value="asc">Ascending</option>
        <option value="desc">Descending</option>
    </select>
    <select id="showLimit" onchange="searchFilter()">
        <option value="10">10</option>
        <option value="20">20</option>
        <option value="30">30</option>
        <option value="40">40</option>
        <option value="50">50</option>
    </select>
    <select id="cat" onchange="searchFilter()" >   
        <option value="">Select Category</option>
        <?php foreach ($datacat as $d){?>
        <option value="<?= $d['cat_name']?>"><?=$d['cat_name']?></option>
        <?php } ?>
    </select> 
      <select id="brd" onchange="searchFilter()"> 
        <option value="">Select Make</option>
        <?php foreach ($databrd as $f){?>
        <option value="<?= $f['brand_name']?>"><?=$f['brand_name']?></option>
        <?php } ?>
     </select>        
              <span class="loading-overlay"><img src="../build/images/loading2.gif"/></span>
    <ul class="nav navbar-right panel_toolbox">
    <li><a href="javascript:void(0);" class="glyphicon glyphicon-plus" id="addLink" onclick="javascript:$('#addUser').slideToggle();">Add</a>
        </li>                     
                      
                    </ul>  
          </div>
          </div>      
           <div class="panel-body none formData" id="addUser">
               <h2 id="actionLabel">Capture Item</h2><br>
                <form class="form" id="addForm">  
                     <div class="form-group col-md-4 col-sm-4 col-xs-12">
                        <label>Bar Code</label>
                        <input type="text" class="form-control" name="code" id="code"/>
                    </div>
                    <div class="form-group col-md-8 col-sm-8 col-xs-12">
                        <label>Description</label>
                        <input type="text" class="form-control" name="name" id="name"/>
                    </div>
                    <div class="form-group col-md-6 col-sm-12 col-xs-12">
                       <label>Category</label>                         
                       <select class="form-control" name="category" id="category">                            
                            <?php foreach ($datacat as $d){?>
                            <option value="<?= $d['cat_name']?>"><?=$d['cat_name']?></option>
                            <?php } ?>
                         </select>
                    </div>  
                    <div class="form-group col-md-6 col-sm-12 col-xs-12">
                       <label>Make</label>                         
                       <select class="form-control" name="brand" id="brand">                           
                            <?php foreach ($databrd as $f){?>
                            <option value="<?= $f['brand_name']?>"><?=$f['brand_name']?></option>
                            <?php } ?>
                         </select>
                    </div>                    
                    <div class="form-group col-md-6 col-sm-12 col-xs-12">
                       <label>Unit</label>                        
                        <select class="form-control" name="unit" id="unit">
                           <option value="">None</option> 
                            <?php foreach ($datamst as $e){?>
                           <option value="<?= $e['unit_name']?>"><?=$e['unit_name']?></option>
                            <?php } ?>
                         </select>
                    </div>  
                    <div class="form-group col-md-6 col-sm-12 col-xs-12">
                        <label>Cost Price</label>
                        <div class="input-group">
                            <div class="input-group-addon">₦</div>
                            <input type="text" class="form-control" name="amount" id="amount" placeholder="e.g 12,300"/>                           
                        </div>                        
                    </div>
                    <div class="form-group col-md-6 col-sm-6 col-xs-12">
                    <a href="javascript:void(0);" class="btn btn-warning" onclick="$('#addUser').slideUp();">Cancel</a>
                    <a href="javascript:void(0);" class="btn btn-success" onclick="userAction('add')">Capture Item</a>
                    </div>
                </form>
            </div>
         <div class="panel-body none formData" id="editForm">
                <h2 id="actionLabel">Edit Item</h2><br>
               <form class="form" id="userForm">                    
                    <div class="form-group col-md-4 col-sm-4 col-xs-12">
                        <label>Bar Code</label>
                        <input type="hidden" name="idEdit" id="idEdit"/>
                        <input type="text" class="form-control" name="codeEdit" id="codeEdit"/>
                    </div>
                    <div class="form-group col-md-8 col-sm-8 col-xs-12">
                        <label>Description</label>
                        <input type="text" class="form-control" name="nameEdit" id="nameEdit"/>
                    </div>
                    <div class="form-group col-md-6 col-sm-12 col-xs-12">
                       <label>Category</label>                         
                       <select class="form-control" name="categoryEdit" id="categoryEdit">                            
                            
                         </select>
                    </div>  
                    <div class="form-group col-md-6 col-sm-12 col-xs-12">
                       <label>Make</label>                         
                       <select class="form-control" name="brandEdit" id="brandEdit">                           
                           
                       </select>
                    </div>                    
                    <div class="form-group col-md-6 col-sm-12 col-xs-12">
                       <label>Unit</label>                        
                        <select class="form-control" name="unitEdit" id="unitEdit">                            
                            
                        </select>
                    </div>  
                    <div class="form-group col-md-6 col-sm-12 col-xs-12">
                        <label>Cost Price</label>
                        <div class="input-group">
                            <div class="input-group-addon">₦</div>
                            <input type="text" class="form-control" name="amountEdit" id="amountEdit" placeholder="e.g 12,300"/>                           
                        </div>                        
                    </div>                             
                    <div class="form-group col-md-6 col-sm-6 col-xs-12">
                    <a href="javascript:void(0);" class="btn btn-warning" onclick="$('#editForm').slideUp();">Cancel</a>
                    <a href="javascript:void(0);" class="btn btn-success" onclick="userAction('edit')">Update Item</a>
                    </div>
                </form>
            </div>
   <div id="posts_content" class="table-responsive">  
       <?php
    
      include_once 'misc/Pagination.php';     

 
    $limit = 10;
    
    //get number of rows
    $sql = "SELECT count(item_id) as code FROM items";
    $data1 = $dbOperation->getPages($sql);
    $rowCount = $data1['code'];    
    
    //initialize pagination class
    $pagConfig = array(
        'totalRows' => $rowCount,
        'perPage' => $limit,
        'link_func' => 'searchFilter'
    );
    $pagination =  new Pagination($pagConfig);
 
   $tableName = "items";  
 $queryConfig = array(
        'table' => $tableName,
        'limit' => $limit        
    );
 
   $data = $dbOperation->getdata($queryConfig);    
   $dbOperation->close();  
   if($data){ ?>
             <table class="table table-hover table-striped table-bordered">
                 <thead>
                    <tr>
                        <th></th> 
                        <th>BAR CODE</th>
                        <th>DESCRIPTION</th> 
                        <th>CATEGORY</th> 
                        <th>MAKE</th>                        
                        <th>COST PRICE(₦)</th> 
                        <th>DATE</th>                          
                        <th>ACTION</th>
                    </tr>
                </thead>
    <?php $count = 0;
   foreach ($data as $value) {
       $count++;
       $item_id = $value['item_id'];       
       $date_created =  date_format(date_create($value['date_created']), 'F, j Y');       
      
       
       ?>
       <tr>     
                     <td> <?php echo $count ?></td>                    
                     <td> <?php echo $value['bar_code']; ?>  </td> 
                     <td> <?php echo $value['description']; ?>  </td>
                     <td> <?php echo $value['category']; ?>  </td>
                     <td> <?php echo $value['brand']; ?>  </td>                    
                     <td> <?php echo number_format($value['cost_price'],2); ?>  </td>                     
                      <td> <?php echo $date_created; ?>  </td>                       
                      <td>                           
                            <a href="javascript:void(0);" class="glyphicon glyphicon-eye-open" onclick="viewItem('<?php echo $item_id; ?>')"></a>
                            <a href="javascript:void(0);" class="glyphicon glyphicon-edit" onclick="loadContent('<?php echo $item_id; ?>')"></a>
                      </td>
                      
       </tr>   
       
  <?php }   
        
        ?>
             </table>          
   <?php echo $pagination->createLinks(); } 
   else {echo "<br><br><center><font color='red'><h2> Item Not Available</h2></font></center><br><br>";}
       
       ?>    
                   
          
    </div> 
    </div>
    </div>   

            
                       
         </div>          
        </div>
        <!-- /page content -->

        <!-- footer content -->
        <?php include_once 'include/footer.php';?>
        <!-- /footer content -->
      </div>
    </div>

   <?php include_once 'include/basic_js.php';?>
   
    <!-- Chart.js -->
    <!-- FastClick -->
    <script src="../vendors/fastclick/lib/fastclick.js"></script>
    <!-- NProgress -->
    <script src="../vendors/nprogress/nprogress.js"></script>    
      <script src="js/jquery-ui.min.js"></script>
  
    <script>            
       document.cookie = "current_page="+0; 
function searchFilter(page_num) { 
    page_num = page_num?page_num:0;
    document.cookie = "current_page=" +page_num; 
    
    var keywords = $('#keywords').val();
    var sortBy = $('#sortBy').val();
    var showLimit = $('#showLimit').val();  
    var cat = $('#cat').val();
    var brd = $('#brd').val(); 
    
    $.ajax({
        type: 'POST',
        url: '../database/item_capture.php',
        data:'page='+page_num+'&keywords='+keywords+'&sortBy='+sortBy+'&limit='+showLimit+'&cat='+cat+'&brd='+brd+'&action_type=view',
        beforeSend: function () {
            $('.loading-overlay').show();
        },
        success: function (html) { 
            $('#posts_content').html(html);
            $('.loading-overlay').fadeOut("slow");
        }
    });
}

function userAction(type,id){
 if (confirm("Do you want to "+type+" this item?. Click OK to continue or Cancel to ignore") === true) {
    id = (typeof id == "undefined")?'':id;
    var statusArr = {add:"added",edit:"updated",delete:"deleted"};
    var userData = '';
    if (type === 'add'){         
        userData = $("#addUser").find('.form').serialize()+'&action_type='+type;        
    }
    else if (type === 'edit'){                       
        userData = $("#editForm").find('.form').serialize()+'&action_type='+type;       
    }else{
        userData = 'action_type='+type+'&id='+id;
    }
    $.ajax({
        type: 'POST',
        url: '../database/item_capture.php',
        data: userData,
        beforeSend: function () {
            $('.loading-overlay').show();
        },
        success:function(msg){           
        if($.trim(msg) === "ok"){
                alert('Item '+statusArr[type]+' successfully.'); 
                 var allcookies = document.cookie;              
                 var cookiearray = allcookies.split(';'); 
                 var value = 0;
                 value = cookiearray[0].split('=')[1]; 
                 
                 value = parseInt(value);                 
                searchFilter(value); 
                
                $('.form')[0].reset();
                $('.formData').slideUp();               
            }        
        
        else{
                alert('Unable to '+type+' item at this time.');
            }
        }
    });
    } else{}
    
}

function fdate(dval){   
            var date1 = JSON.stringify(dval);
            var res = date1.split(",");
            var res2 = res[0].replace('{"date":', '');            
            var dateval = JSON.parse(res2);            
            return dateval;    
}
function loadcat(senv){   
     var rep = senv;
    $.ajax({
        type: 'POST',
        dataType:'JSON',
        url: '../database/item_capture.php',
        data: 'action_type=load&table=item_category',
        success:function(data){ 
            $('#categoryEdit').empty();
         for(var i=0;i<data.length; i++)
       {           
                if(rep === data[i].cat_name){
                  $("#categoryEdit").append("<option selected='selected' value='"+data[i].cat_name+"'>"+ data[i].cat_name +"</option>");
                
                }
                else{
                $("#categoryEdit").append("<option value='"+data[i].cat_name +"'>"+ data[i].cat_name +"</option>");
            }
       } 
        
       }      
        
    });  
}
function loadmake(senv){   
     var rep = senv;
    $.ajax({
        type: 'POST',
        dataType:'JSON',
        url: '../database/item_capture.php',
        data: 'action_type=load&table=brand_category',
        success:function(data){ 
            $('#brandEdit').empty();
         for(var i=0;i<data.length; i++)
       {           
                if(rep === data[i].brand_name){
                  $("#brandEdit").append("<option selected='selected' value='"+data[i].brand_name+"'>"+ data[i].brand_name +"</option>");
                 
                }
                else{
                $("#brandEdit").append("<option value='"+data[i].brand_name +"'>"+ data[i].brand_name +"</option>");
            }
       } 
        
       }      
        
    });  
}
function loadunit(senv){   
     var rep = senv;
    $.ajax({
        type: 'POST',
        dataType:'JSON',
        url: '../database/item_capture.php',
        data: 'action_type=load&table=unit_measure',
        success:function(data){ 
            $('#unitEdit').empty();
            $("#unitEdit").append("<option value=''>None</option> ");
         for(var i=0;i<data.length; i++)
       {           
                if(rep === data[i].unit_name){
                  $("#unitEdit").append("<option selected='selected' value='"+data[i].unit_name+"'>"+ data[i].unit_name +"</option>");
                 
                }
                else{
                $("#unitEdit").append("<option value='"+data[i].unit_name +"'>"+ data[i].unit_name +"</option>");
            }
       } 
        
       }      
        
    });  
}
function loadContent(id){ 
    $.ajax({
        type: 'POST',
        dataType:'JSON',
        url: '../database/item_capture.php',
        data: 'action_type=data&id='+id,
        beforeSend: function () {
            $('.loading-overlay').show();
        },
        success:function(data){                      
                $('#idEdit').val(data.item_id); 
                $('#codeEdit').val(data.bar_code);  
                $('#nameEdit').val(data.description);
                $('#amountEdit').val(data.cost_price);                
                loadcat(data.category);                
                loadmake(data.brand);
                loadunit(data.unit_measure);
                
                $('#editForm').slideDown();
                $('.loading-overlay').hide();
                 
        }
    });
    
}

function viewItem(id){   
    $.ajax({
        type: 'POST',
        dataType:'JSON',
        url: '../database/item_capture.php',
        data: 'action_type=data&id='+id,
        beforeSend: function () {
            $('.loading-overlay').show();
        },
        success:function(data){ 
            
            var cost_price = parseInt(data.cost_price);
                cost_price = cost_price.toFixed(2).replace(/(\d)(?=(\d{3})+\.)/g, '$1,');  
            var selling_price = parseInt(data.selling_price);
                selling_price = selling_price.toFixed(2).replace(/(\d)(?=(\d{3})+\.)/g, '$1,');
                
            var display ="<div class='table-responsive'> ";            
            display +="<table class='table table-hover' border='1'>";
            display += "<thead><tr><th>Bar Code</th><th colspan='2'>Description</th></tr></thead>"; 	
            display += "<tr><td>"+data.code+"</td><td colspan='2'>"+data.description+"</td></tr>";  
            display += "<tr><td colspan='3'></td></tr><tr><td colspan='3'></td></tr>"; 
            
            display += "<thead><tr><th>Category</th><th>Make</th><th>Unit</th></tr></thead>"; 	
            display += "<tr><td>"+data.category+"</td><td>"+data.brand+"</td><td>"+data.unit_measure+"</td></tr>";  
            display += "<tr><td colspan='3'></td></tr><tr><td colspan='3'></td></tr>"; 
            
            display += "<thead><tr><th>Quantities</th><th>Cost Price</th><th>Selling Price</th></tr></thead>"; 	
            display += "<tr><td>"+data.quantity+"</td><td>"+cost_price+"</td><td>"+selling_price+"</td></tr>";  
            display += "<tr><td colspan='3'></td></tr><tr><td colspan='3'></td></tr>"; 
                                    
            display += "<thead><tr><th>Date Created</th><th colspan='2'>Date Updated</th></tr></thead>"; 	
            display += "<tr><td>"+fdate(data.date_created)+"</td><td colspan='2'>"+fdate(data.date_updated)+"</td></tr>";  
            display += "<tr><td colspan='3'></td></tr><tr><td colspan='3'></td></tr>"; 
            
            display += "</table></div>";          
            $('#employee_detail').html(display);
            $('#dataModal').modal({backdrop: false});           
            $('.loading-overlay').fadeOut("slow");
        }
    });
    
}


    </script>
    </body>
</html>
