<?php session_start();
include_once '../config/config.php';
include_once '../database/db.php'; 
$dbOperation = new DB();
        $querycat = array('table' => 'item_category'); 
        $datacat = $dbOperation->getdata($querycat);   
        $querybrd = array('table' => 'brand_category'); 
        $databrd = $dbOperation->getdata($querybrd); 
?> 
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Just Steph Venture</title>
    <link rel="icon" type="image/jpg" href="../home/images/steph_logo.png" /> 
    <?php include_once 'include/basic_css.php';?>
     <link href="../vendors/nprogress/nprogress.css" rel="stylesheet">
     <link href="css/pagination.css" rel="stylesheet">
      
     <style>
        #ui-datepicker-div {
    z-index:2 !important;
    background: #002;
        }
        .ui-state-default{
            color: #F4FF77;
            
        }
     </style>
  </head>

  <body class="nav-md">
    <div class="container body">
      <div class="main_container">
          <!-- side bar -->
       <?php include_once 'include/sidebar.php';?>

        <!-- top navigation -->
        <?php include_once 'include/top_navigation.php';
            $year = (int)date('Y'); $month = (int)date('m'); $day = (int)date('d'); $mth_word = date("F");
        ?>
       

        <!-- page content -->
        <div class="right_col" role="main">
         <div class="">
            <div class="page-title">
              <div class="title_left">
                <h3>TRANSFER REGISTER</h3>
              </div>

              <div class="title_right">
                <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
                  
                </div>
              </div>
            </div>            
            <div class="row">                
             <div id="dataModal" class="modal fade">
 <div class="modal-dialog modal-lg">
  <div class="modal-content">
   <div class="modal-header">
    <button type="button" class="close" data-dismiss="modal">&times;</button>
    <h4 class="modal-title"></h4>
   </div>
   <div class="modal-body" id="employee_detail">
    
   </div>
   <div class="modal-footer">
    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
   </div>
  </div>
 </div>
</div>                   
            </div>
            
            
            <div class="row" style="margin: 10px 20px 10px 10px; width: 98%; font-size: 14px;">
     <div class="panel panel-default users-content">
      <div class="panel-heading">
          <div class="post-search-panel">  
              <form action="../PHPExcel/Examples/item_transfer.php" method="post"> 
    <select id="sortBy" name="sortBy" onchange="searchFilter()">
        <option value="">Sort By Date</option>
        <option value="asc">Ascending</option>
        <option value="desc">Descending</option>
    </select>
    <select id="showLimit" name="showLimit" onchange="searchFilter()">       
        <option value="20">20</option>
        <option value="30">30</option>
        <option value="40">40</option>
        <option value="50">50</option>
    </select>
    <select id="cat" name="cat" onchange="searchFilter()" >   
        <option value="">Select Category</option>
        <?php foreach ($datacat as $d){?>
        <option value="<?= $d['cat_name']?>"><?=$d['cat_name']?></option>
        <?php } ?>
    </select> 
      <select id="brd" name="brd" onchange="searchFilter()"> 
        <option value="">Select Make</option>
        <?php foreach ($databrd as $f){?>
        <option value="<?= $f['brand_name']?>"><?=$f['brand_name']?></option>
        <?php } ?>
     </select>  
     <select id="s_dy" name="s_dy" onchange="searchFilter()">       
        <option value="">Day</option>
        <?php for($i=1; $i < 32; $i++){ ?>
        <option value="<?= $i; ?>"><?= $i; ?></option>
          <?php } ?>  
    </select>         
     <select id="s_mth" name="s_mth" onchange="searchFilter()"> 
         <option value="">Month</option> 
         <option value="1">January</option>
        <option value="2">February</option>
        <option value="3">March</option>
        <option value="4">April</option>
        <option value="5">May</option>
        <option value="6">June</option>
        <option value="7">July</option>
        <option value="8">August</option>
        <option value="9">September</option>
        <option value="10">October</option>
        <option value="11">November</option>
        <option value="12">December</option>    
    </select>           
     <select id="s_yr" name="s_yr" onchange="searchFilter()" > 
         <option value="">Year</option>  
       <?php for($i=0; $i < 10; $i++){ ?>
        <option value="<?= date("Y") - $i; ?>"><?= date("Y") - $i; ?></option>
          <?php } ?>   
    </select>         
              <span class="loading-overlay"><img src="../build/images/loading2.gif"/></span>
          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
         <input type="submit" class="btn btn-primary" name="submit" id="submit" value="Generate Report (Excel)">
         </form>       
          </div>
          </div>      
        
   <div id="posts_content" class="table-responsive">  
       <?php
    
      include_once 'misc/Pagination.php';     
 
    $limit = 20;    
    
    $year = (int)date('Y'); $month = (int)date('m'); $day = (int)date('d');
    $whereSQL =  " WHERE YEAR(tran_date) =  $year " ;
    //2018-03-11 16:31:02
    $sql = "SELECT count(item_id) as code FROM trans_detail ".$whereSQL;
    $data1 = $dbOperation->getPages($sql);
    $rowCount = $data1['code'];    
    
    //initialize pagination class
    $pagConfig = array(
        'totalRows' => $rowCount,
        'perPage' => $limit,
        'link_func' => 'searchFilter'
    );
    $pagination =  new Pagination($pagConfig);
 
   $tableName = "trans_detail";  
   $orderSQL = " ORDER BY tran_date DESC ";
 $queryConfig = array(
        'table' => $tableName,
        'where' => $whereSQL,
        'limit' => $limit,        
        'order_by' => $orderSQL
    );
   //$total_amount = 0;
   $data = $dbOperation->getdata($queryConfig);    
   $dbOperation->close();  
   //print_r($data);
   if($data){ ?>
             <table class="table table-hover table-striped table-bordered">
                 <thead>
                    <tr>
                        <th></th> 
                        <th>TRANSFER ID</th> 
                        <th>DESCRIPTION</th>
                        <th>CATEGORY</th> 
                        <th>BRAND</th> 
                        <th>STORE</th>
                        <th>QTY</th>                        
                        <th>PRICE(₦)</th>                                       
                        <th>TOTAL (₦)</th>                        
                        <th>DATE OF SALES</th>                     
                    </tr>
                </thead>
    <?php $count = 0;
   foreach ($data as $value) {
       $count++; 
       $item_id = $value['item_id']; 
       
       $date_created =  date_format(date_create($value['tran_date']), 'F, j Y');       
             
       ?>
       <tr>     
                     <td> <?php echo $count ?></td>  
                     <td> <?php echo $value['trans_id']; ?>  </td>
                     <td> <?php echo $value['description']; ?>  </td>
                     <td> <?php echo $value['category']; ?>  </td>
                     <td> <?php echo $value['brand']; ?>  </td>
                     <td> <?php echo $value['store']; ?>  </td>
                     <td> <?php echo $value['quantity']; ?>  </td>
                     <td> <?php echo number_format($value['price'],2); ?>  </td>
                     <td> <?php echo number_format($value['total'],2); ?>  </td>                     
                      <td> <?php echo $date_created; ?>  </td>             
                      
       </tr>   
       
  <?php }   
        
        ?>
       </table>          
   <?php echo $pagination->createLinks(); } 
   else {echo "<br><br><center><font color='red'><h2>Record Not Available</h2></font></center><br><br>";}
       
       ?>    
                   
          
    </div> 
    </div>
    </div>   

            
                       
         </div>          
        </div>
        <!-- /page content -->

        <!-- footer content -->
        <?php include_once 'include/footer.php';?>
        <!-- /footer content -->
      </div>
    </div>

   <?php include_once 'include/basic_js.php';?>
   
    <!-- Chart.js -->
    <!-- FastClick -->
    <script src="../vendors/fastclick/lib/fastclick.js"></script>
    <!-- NProgress -->
    <script src="../vendors/nprogress/nprogress.js"></script>    
      <script src="js/jquery-ui.min.js"></script>
  
    <script>            
       document.cookie = "current_page="+0; 
function searchFilter(page_num) { 
    page_num = page_num?page_num:0;
    document.cookie = "current_page=" +page_num; 
        
    var sortBy = $('#sortBy').val();
    var showLimit = $('#showLimit').val();  
    var cat = $('#cat').val();
    var brd = $('#brd').val(); 
    var s_dy = $('#s_dy').val();
    var s_mth = $('#s_mth').val();
    var s_yr = $('#s_yr').val();
      
    $.ajax({
        type: 'POST',
        url: '../database/sales_report.php',
        data:'page='+page_num+'&sortBy='+sortBy+'&limit='+showLimit+'&cat='+cat+'&brd='+brd+'&s_dy='+s_dy+'&s_mth='+s_mth+'&s_yr='+s_yr+'&action_type=tran',
        beforeSend: function () {
            $('.loading-overlay').show();
        },
        success: function (html) { 
            $('#posts_content').html(html);
            $('.loading-overlay').fadeOut("slow");
        }
    });
}

    </script>
    </body>
</html>
