<?php
require('../fpdf.php');

class PDF_MC_Table extends FPDF
{
var $widths;
var $aligns;

// Page footer
function Footer()
{
    // Position at 1.5 cm from bottom
    $this->SetY(-15);
    // Arial italic 8
    $this->SetFont('Arial','I',8);
    // Page number
    $this->Cell(0,10,'Page '.$this->PageNo().'/{nb}',0,0,'C');
}
function SetWidths($w)
{
    //Set the array of column widths
    $this->widths=$w;
}

function SetAligns($a)
{
    //Set the array of column alignments
    $this->aligns=$a;
}

function Row($data)
{
    //Calculate the height of the row
    $nb=0;
    for($i=0;$i<count($data);$i++)
        $nb=max($nb,$this->NbLines($this->widths[$i],$data[$i]));
    $h=5*$nb;
    //Issue a page break first if needed
    $this->CheckPageBreak($h);
    //Draw the cells of the row
    for($i=0;$i<count($data);$i++)
    {
        $w=$this->widths[$i];
        $a=isset($this->aligns[$i]) ? $this->aligns[$i] : 'L';
        //Save the current position
        $x=$this->GetX();
        $y=$this->GetY();
        //Draw the border
        $this->Rect($x,$y,$w,$h);
        //Print the text
        $this->MultiCell($w,5,$data[$i],0,$a);
        //Put the position to the right of the cell
        $this->SetXY($x+$w,$y);
    }
    //Go to the next line
    $this->Ln($h);
}

function CheckPageBreak($h)
{
    //If the height h would cause an overflow, add a new page immediately
    if($this->GetY()+$h>$this->PageBreakTrigger)
        $this->AddPage($this->CurOrientation);
}

function NbLines($w,$txt)
{
    //Computes the number of lines a MultiCell of width w will take
    $cw=&$this->CurrentFont['cw'];
    if($w==0)
        $w=$this->w-$this->rMargin-$this->x;
    $wmax=($w-2*$this->cMargin)*1000/$this->FontSize;
    $s=str_replace("\r",'',$txt);
    $nb=strlen($s);
    if($nb>0 and $s[$nb-1]=="\n")
        $nb--;
    $sep=-1;
    $i=0;
    $j=0;
    $l=0;
    $nl=1;
    while($i<$nb)
    {
        $c=$s[$i];
        if($c=="\n")
        {
            $i++;
            $sep=-1;
            $j=$i;
            $l=0;
            $nl++;
            continue;
        }
        if($c==' ')
            $sep=$i;
        $l+=$cw[$c];
        if($l>$wmax)
        {
            if($sep==-1)
            {
                if($i==$j)
                    $i++;
            }
            else
                $i=$sep+1;
            $sep=-1;
            $j=$i;
            $l=0;
            $nl++;
        }
        else
            $i++;
    }
    return $nl;
}
}

$pdf=new PDF_MC_Table();
$pdf->AliasNbPages();
$pdf->AddPage();
$header = array('ITEM', 'UNIT', 'PRICES', 'AVG');
$pdf->SetFillColor(255,0,0);
    //$pdf->SetTextColor(255);
    //$pdf->SetDrawColor(128,0,0);
 // Logo
    $pdf->Image('logo.png',10,6,30);
    // Arial bold 15
    $pdf->SetFont('Arial','B',15);
    // Move to the right
    $pdf->Cell(80);
    // Title
    $pdf->Cell(80,10,'Price Intelligence for April','',0,'C');
    // Line break
    $pdf->Ln(20);
    //$pdf->SetLineWidth(.3);
    $pdf->SetFont('Arial','B',12);
    // Header
    $w = array(90, 20, 60, 20);
    $z = array(90,20,15,15,15,15,20);
    $wks = array(" "," ","WK1","WK2","WK3","WK4"," ");
    
    for($i=0;$i<count($header);$i++)
        $pdf->Cell($w[$i],7,$header[$i],1,0,'C');
    $pdf->Ln();
    $pdf->SetFont('Arial','B',8);
     $pdf->Cell($z[0],7,$wks[0],'L',0,'C'); $pdf->Cell($z[1],7,$wks[1],'',0,'C');
     $pdf->Cell($z[2],7,$wks[2],'L',0,'C'); $pdf->Cell($z[3],7,$wks[3],'L',0,'C');
     $pdf->Cell($z[4],7,$wks[4],'L',0,'C'); $pdf->Cell($z[5],7,$wks[5],'LR',0,'C');
      $pdf->Cell($z[6],7,$wks[6],'R',0,'C');
    $pdf->Ln();
    
    // Color and font restoration
    //$pdf->SetFillColor(224,235,255);
    //$pdf->SetTextColor(0);
    //$pdf->SetFont('');
    
$pdf->SetFont('Times','',11);
//Table with 20 rows and 4 columns
$pdf->SetWidths(array(90,20,15,15,15,15,20));
srand(microtime()*1000000);

for($i=0;$i<50;$i++)
    $pdf->Row(array("Austria just got nice with this new look most difficult part of this game","Vienna","83859","8075","8075","8075","8075"));
$pdf->Output();
?>
