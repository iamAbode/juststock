<?php
require('../fpdf.php');

$pdf = new FPDF();
$pdf->AddPage();
$pdf->SetFont('Arial','B',16);
$pdf->Cell(40,10,'Welcome to our World!',1);
$pdf->Cell(120,10,'Powered by FPDF.',1,1,'C');
$pdf->Output();
?>
