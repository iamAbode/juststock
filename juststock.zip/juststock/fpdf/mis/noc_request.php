<?php
require('../fpdf.php');

class PDF_MC_Table extends FPDF
{
var $widths;
var $aligns;

// Page header
function Header()
{
    // Logo
    $this->Image('rivers_logo.png',260,6,15,15);
    // Arial bold 15
    $this->SetFont('Arial','B',15);
    // Move to the right
    //$this->Cell(80);
     
    // Line break
    $this->Ln(10);
}

// Page footer
function Footer()
{
    // Position at 1.5 cm from bottom
     $this->SetY(-15);
    // Arial italic 8
      $this->Image('rsbopp_logo.png',260,190,15,15);
    $this->SetFont('Arial','I',8);
    // Page number
    $this->Cell(0,10,'Page '.$this->PageNo().'/{nb}',0,0,'C');
}
function SetWidths($w)
{
    //Set the array of column widths
    $this->widths=$w;
}

function SetAligns($a)
{
    //Set the array of column alignments
    $this->aligns=$a;
}

function Row($data)
{
    //Calculate the height of the row
    $nb=0;
    for($i=0;$i<count($data);$i++)
        $nb=max($nb,$this->NbLines($this->widths[$i],$data[$i]));
    $h=5*$nb;
    //Issue a page break first if needed
    $this->CheckPageBreak($h);
    //Draw the cells of the row
    for($i=0;$i<count($data);$i++)
    {
        $w=$this->widths[$i];
        $a=isset($this->aligns[$i]) ? $this->aligns[$i] : 'L';
        //Save the current position
        $x=$this->GetX();
        $y=$this->GetY();
        //Draw the border
        $this->Rect($x,$y,$w,$h);
        //Print the text
        $this->MultiCell($w,5,$data[$i],0,$a);
        //Put the position to the right of the cell
        $this->SetXY($x+$w,$y);
    }
    //Go to the next line
    $this->Ln($h);
}

function CheckPageBreak($h)
{
    //If the height h would cause an overflow, add a new page immediately
    if($this->GetY()+$h>$this->PageBreakTrigger)
        $this->AddPage($this->CurOrientation);
}

function NbLines($w,$txt)
{
    //Computes the number of lines a MultiCell of width w will take
    $cw=&$this->CurrentFont['cw'];
    if($w==0)
        $w=$this->w-$this->rMargin-$this->x;
    $wmax=($w-2*$this->cMargin)*1000/$this->FontSize;
    $s=str_replace("\r",'',$txt);
    $nb=strlen($s);
    if($nb>0 and $s[$nb-1]=="\n")
        $nb--;
    $sep=-1;
    $i=0;
    $j=0;
    $l=0;
    $nl=1;
    while($i<$nb)
    {
        $c=$s[$i];
        if($c=="\n")
        {
            $i++;
            $sep=-1;
            $j=$i;
            $l=0;
            $nl++;
            continue;
        }
        if($c==' ')
            $sep=$i;
        $l+=$cw[$c];
        if($l>$wmax)
        {
            if($sep==-1)
            {
                if($i==$j)
                    $i++;
            }
            else
                $i=$sep+1;
            $sep=-1;
            $j=$i;
            $l=0;
            $nl++;
        }
        else
            $i++;
    }
    return $nl;
}

}
include_once '../../database/db.php';
$dbOperation = new DB();
//$pdf=new PDF_MC_Table('L','mm','A4');
$pdf=new PDF_MC_Table();
$pdf->AliasNbPages();
$pdf->AddPage();
    $whereSQL = " ";   
    $dat = $_POST['dat'];  
    $sta = $_POST['sta'];
    $dep = $_POST['dep'];           
        
        if(!empty($dat) || !empty($dep)){
                $whereSQL .= " WHERE status = '$sta' AND (";
                if(!empty($dat)  && !empty($dep)){               
                $whereSQL .= " p_year LIKE '%".$dat."%'";               
                $whereSQL .= " AND pe_id LIKE '%".$dep."%'";
                     }                         
                else if(!empty($dat)  && empty($dep)){                 
                $whereSQL .= " p_year LIKE '%".$dat."%'";                                  
                     }                
                 else if(empty($dat) && !empty($dep)){
                 $whereSQL .= " pe_id LIKE '%".$dep."%'";                   
                     }                                 
                 $whereSQL .= " )";  
               }   
               else {
                 $whereSQL .= " WHERE status = '$sta' ";
               }
     $cat = array('W' =>'Works', 'G' => 'Goods','S' => 'Services');
     $stat = array('N' =>'Pending', 'A' => 'Approved','R' => 'Rejected'); 
     $plan_name =  $stat[trim($sta)]." No Objection Certificate";
    $pdf->SetFillColor(255,0,0);   
    $pdf->SetFont('Arial','B',12);    
    $pdf->Cell(200,10,$plan_name,'',0,'C');
    // Line break
    $pdf->Ln(10);
    //$pdf->SetLineWidth(.3);
    $pdf->SetFont('Arial','B',7);
    // Header  
    $z = array(10,50,55,30,20,25);
    $h_sub = "";
    if(trim($sta) == "A"){$h_sub = "DATE APPROVED";}
    else{$h_sub = "DATE SUBMITTED";}
    $header = array("S/N","PROCUREMENT ENTITY","DESCRIPTION","PROCURING YEAR","CATEGORY",$h_sub);    
    $pdf->SetFont('Arial','B',7);
    for($i=0;$i<count($header);$i++)
        $pdf->Cell($z[$i],7,$header[$i],1,0,'C');
    $pdf->Ln();    
   
$pdf->SetFont('Times','',9);
//Table with 20 rows and 4 columns
$pdf->SetWidths(array(10,50,55,30,20,25));
$pdf->SetAligns(array('C','L','L','C','C','C'));
srand(microtime()*1000000);
$pdf->SetFillColor(255, 255, 255);



$queryConfig = array('table' => 'dbo.noc_request', 'where' => $whereSQL, 'order_by' => " ORDER BY date_created "); 
$data = $dbOperation->getdata($queryConfig); 
$cat = array('W' =>'Works', 'G' => 'Goods','S' => 'Services');
$sta = array('N' =>'Pending', 'A' => 'Approved','R' => 'Rejected');
if(!empty($data)){    
    foreach($data as $dt){        
       $sn++;         
        $category = $cat[trim($dt['category'])];   $description = $dt['description'];         
        $pe_name = $dt['pe_name'];    $p_year = $dt['p_year'];
        if(trim($sta) == "A"){$date_created = date_format($dt['date_of_reply'], 'd/m/Y');}
        else{$date_created = date_format($dt['date_created'], 'd/m/Y'); }   
        $pdf->Row(array($sn,$pe_name,$description,$p_year,$category,$date_created));
     }  
     $pdf->Ln(10);
 $pdf->SetFont('Arial','B',8); 
 $pdf->Cell(20,10,'','',0,'L');
 $pdf->Cell(80,5,'Prepared by: .................................................','',0,'L');
 $pdf->Cell(80,5,'Reviewed by: .................................................','',0,'L'); 
 
 $pdf->Ln();
 
 $pdf->SetFont('Arial','',8); 
 $pdf->Cell(20,10,'','',0,'L');
 $pdf->Cell(80,5,'Position: ......................................................','',0,'L');
 $pdf->Cell(80,5,'Position: ......................................................','',0,'L'); 
 $pdf->Ln();
 $pdf->Cell(20,10,'','',0,'L');
 $pdf->Cell(80,5,'Signature & Date: ..........................................','',0,'L');
 $pdf->Cell(80,5,'Signature & Date: ..........................................','',0,'L');
 
 $pdf->Output();   
} 
else{
    $pdf->SetFont('Arial','B',12);
    $pdf->SetTextColor(255,0,0);
    $pdf->Cell(200,10,'Please select appropriate parameters','',0,'C');
    $pdf->Output(); exit;
}

         
    

    
?>
