<?php
require('../fpdf.php');

class PDF_MC_Table extends FPDF
{
var $widths;
var $aligns;

// Page header
function Header()
{
    // Logo
    $this->Image('rivers_logo.png',170,6,15,15);
    // Arial bold 15
    $this->SetFont('Arial','B',15);
    // Move to the right
    //$this->Cell(80);
     
    // Line break
    $this->Ln(10);
}

// Page footer
function Footer()
{
    // Position at 1.5 cm from bottom
     $this->SetY(-15);
    // Arial italic 8
      $this->Image('rsbopp_logo.png',170,275,15,15);
    $this->SetFont('Arial','I',8);
    // Page number
    $this->Cell(0,10,'Page '.$this->PageNo().'/{nb}',0,0,'C');
}
function SetWidths($w)
{
    //Set the array of column widths
    $this->widths=$w;
}

function SetAligns($a)
{
    //Set the array of column alignments
    $this->aligns=$a;
}

function Row($data)
{
    //Calculate the height of the row
    $nb=0;
    for($i=0;$i<count($data);$i++)
        $nb=max($nb,$this->NbLines($this->widths[$i],$data[$i]));
    $h=5*$nb;
    //Issue a page break first if needed
    $this->CheckPageBreak($h);
    //Draw the cells of the row
    for($i=0;$i<count($data);$i++)
    {
        $w=$this->widths[$i];
        $a=isset($this->aligns[$i]) ? $this->aligns[$i] : 'L';
        //Save the current position
        $x=$this->GetX();
        $y=$this->GetY();
        //Draw the border
        $this->Rect($x,$y,$w,$h);
        //Print the text
        $this->MultiCell($w,5,$data[$i],0,$a);
        //Put the position to the right of the cell
        $this->SetXY($x+$w,$y);
    }
    //Go to the next line
    $this->Ln($h);
}

function CheckPageBreak($h)
{
    //If the height h would cause an overflow, add a new page immediately
    if($this->GetY()+$h>$this->PageBreakTrigger)
        $this->AddPage($this->CurOrientation);
}

function NbLines($w,$txt)
{
    //Computes the number of lines a MultiCell of width w will take
    $cw=&$this->CurrentFont['cw'];
    if($w==0)
        $w=$this->w-$this->rMargin-$this->x;
    $wmax=($w-2*$this->cMargin)*1000/$this->FontSize;
    $s=str_replace("\r",'',$txt);
    $nb=strlen($s);
    if($nb>0 and $s[$nb-1]=="\n")
        $nb--;
    $sep=-1;
    $i=0;
    $j=0;
    $l=0;
    $nl=1;
    while($i<$nb)
    {
        $c=$s[$i];
        if($c=="\n")
        {
            $i++;
            $sep=-1;
            $j=$i;
            $l=0;
            $nl++;
            continue;
        }
        if($c==' ')
            $sep=$i;
        $l+=$cw[$c];
        if($l>$wmax)
        {
            if($sep==-1)
            {
                if($i==$j)
                    $i++;
            }
            else
                $i=$sep+1;
            $sep=-1;
            $j=$i;
            $l=0;
            $nl++;
        }
        else
            $i++;
    }
    return $nl;
}

}
include_once '../../database/db.php';
$dbOperation = new DB();
//$pdf=new PDF_MC_Table('L','mm','A3');
$pdf=new PDF_MC_Table();
$pdf->AliasNbPages();
$pdf->AddPage();

$pdf->SetFillColor(255,0,0);
   
    $pdf->SetFont('Arial','B',11);
    
    $pdf->Cell(180,10,'Rivers State Contractors and Service Providers','',0,'C');
    // Line break
    $pdf->Ln(20);
    //$pdf->SetLineWidth(.3);
    $pdf->SetFont('Arial','B',7);
    // Header    
    $z = array(10,35,35,20,20,20,20,20,18);
    $header = array("S/N","Name ","Registered Office ","Email/Website","Contact Person","Phone","Business Area","Tax ID No. ","Category");    
    $pdf->SetFont('Arial','B',7);
    for($i=0;$i<count($header);$i++)
        $pdf->Cell($z[$i],7,$header[$i],1,0,'C');
    $pdf->Ln();    
    
$pdf->SetFont('Times','',7);
//Table with 20 rows and 4 columns
$pdf->SetWidths(array(10,35,35,20,20,20,20,20,18));
$pdf->SetAligns(array('C','L','L','L','L','L','L','L','C'));
srand(microtime()*1000000);
$pdf->SetFillColor(255, 255, 255);



$queryConfig = array('table' => 'dbo.contractors', 'order_by' => " ORDER BY category "); 
$data = $dbOperation->getdata($queryConfig); 

if(!empty($data)){       
    foreach($data as $dt){        
       $sn++;  
                $name = $dt['name'];
                $address = $dt['address'];
                $website = $dt['website'];
                $con_person = $dt['con_person']; 
                $con_phone = $dt['con_phone'];                
                $business_area = "";
                $tin = $dt['tin'];
                $category = $dt['category'];
                if(empty($category)) $category = eval("<font color='red'>Not Registered</font>");
                if(!empty($dt['construction'])){$business_area .= "Works, ";}
                if(!empty($dt['supply'])){$business_area .= "Goods, ";}
                if(!empty($dt['service'])){$business_area .= "Services ";}
                if(!empty($dt['spec_oth'])){$business_area .= $value['spec_oth'];}
    $pdf->Row(array($sn,$name,$address,$website,$con_person,$con_phone,$business_area,$tin,$category));
     
    }       
        
}     
          
    

    $pdf->Output();
?>
