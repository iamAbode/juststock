<?php
require('../fpdf.php');

class PDF_MC_Table extends FPDF
{
var $widths;
var $aligns;

// Page header
function Header()
{
    // Logo
    $this->Image('rivers_logo.png',170,6,20,20);
    // Arial bold 15
    $this->SetFont('Arial','B',15);
    // Move to the right
    //$this->Cell(80);
     
    // Line break
    $this->Ln(16);
}

// Page footer
function Footer()
{
    // Position at 1.5 cm from bottom
     $this->SetY(-15);
    // Arial italic 8
      $this->Image('rsbopp_logo.png',170,275,15,15);
    $this->SetFont('Arial','I',8);
    // Page number
    $this->Cell(0,10,'Page '.$this->PageNo().'/{nb}',0,0,'C');
}
function SetWidths($w)
{
    //Set the array of column widths
    $this->widths=$w;
}

function SetAligns($a)
{
    //Set the array of column alignments
    $this->aligns=$a;
}

function Row($data)
{
    //Calculate the height of the row
    $nb=0;
    for($i=0;$i<count($data);$i++)
        $nb=max($nb,$this->NbLines($this->widths[$i],$data[$i]));
    $h=5*$nb;
    //Issue a page break first if needed
    $this->CheckPageBreak($h);
    //Draw the cells of the row
    for($i=0;$i<count($data);$i++)
    {
        $w=$this->widths[$i];
        $a=isset($this->aligns[$i]) ? $this->aligns[$i] : 'L';
        //Save the current position
        $x=$this->GetX();
        $y=$this->GetY();
        //Draw the border
        $this->Rect($x,$y,$w,$h);
        //Print the text
        $this->MultiCell($w,5,$data[$i],0,$a);
        //Put the position to the right of the cell
        $this->SetXY($x+$w,$y);
    }
    //Go to the next line
    $this->Ln($h);
}

function CheckPageBreak($h)
{
    //If the height h would cause an overflow, add a new page immediately
    if($this->GetY()+$h>$this->PageBreakTrigger)
        $this->AddPage($this->CurOrientation);
}

function NbLines($w,$txt)
{
    //Computes the number of lines a MultiCell of width w will take
    $cw=&$this->CurrentFont['cw'];
    if($w==0)
        $w=$this->w-$this->rMargin-$this->x;
    $wmax=($w-2*$this->cMargin)*1000/$this->FontSize;
    $s=str_replace("\r",'',$txt);
    $nb=strlen($s);
    if($nb>0 and $s[$nb-1]=="\n")
        $nb--;
    $sep=-1;
    $i=0;
    $j=0;
    $l=0;
    $nl=1;
    while($i<$nb)
    {
        $c=$s[$i];
        if($c=="\n")
        {
            $i++;
            $sep=-1;
            $j=$i;
            $l=0;
            $nl++;
            continue;
        }
        if($c==' ')
            $sep=$i;
        $l+=$cw[$c];
        if($l>$wmax)
        {
            if($sep==-1)
            {
                if($i==$j)
                    $i++;
            }
            else
                $i=$sep+1;
            $sep=-1;
            $j=$i;
            $l=0;
            $nl++;
        }
        else
            $i++;
    }
    return $nl;
}
function n2r($num) 
 {
     // Make sure that we only use the integer portion of the value
     $n = intval($num);
     $result = '';
 
     // Declare a lookup array that we will use to traverse the number:
     $lookup = array('M' => 1000, 'CM' => 900, 'D' => 500, 'CD' => 400,
     'C' => 100, 'XC' => 90, 'L' => 50, 'XL' => 40,
     'X' => 10, 'IX' => 9, 'V' => 5, 'IV' => 4, 'I' => 1);
 
     foreach ($lookup as $roman => $value) 
     {
         // Determine the number of matches
         $matches = intval($n / $value);
 
         // Store that many characters
         $result .= str_repeat($roman, $matches);
 
         // Substract that from the number
         $n = $n % $value;
     }
 
     // The Roman numeral should be built, return it
     return $result;
 } 
}
include_once '../../database/db.php';
$dbOperation = new DB();
$pdf=new PDF_MC_Table();
$pdf->AliasNbPages();
$pdf->AddPage();
$yr = (int)$_POST['trend_year'];  $mth = (int) $_POST['trend_month'];
//$yr = 2018;  $mth = 1;   
$mons_arr = array(1 => "January", 2 => "February", 3 => "March", 4 => "April", 5 => "May", 6 => "June", 7 => "July", 8 => "August", 9 => "September", 10 => "October", 11 => "November", 12 => "December");

$mon = $mons_arr[$mth].", ".$yr;
$header = array('SN','Description of Material', 'Unit', $mon, 'AVG');
$pdf->SetFillColor(255,0,0);
   
    $pdf->SetFont('Arial','B',11);
    
    $pdf->Cell(80,10,'TABLE OF ITEMS','',0,'L');
    // Line break
    $pdf->Ln(10);
    //$pdf->SetLineWidth(.3);
    $pdf->SetFont('Arial','B',11);
    // Header
    $w = array(10,65, 15, 80, 20);
    $z = array(10,65,15,20,20,20,20,20);
    $wks = array(" "," "," ","WK1","WK2","WK3","WK4"," ");
    
    for($i=0;$i<count($header);$i++)
        $pdf->Cell($w[$i],7,$header[$i],1,0,'C');
    $pdf->Ln();
    $pdf->SetFont('Arial','B',8);
     $pdf->Cell($z[0],7,$wks[0],'L',0,'C'); $pdf->Cell($z[1],7,$wks[1],'',0,'C');
     $pdf->Cell($z[2],7,$wks[2],'L',0,'C'); $pdf->Cell($z[3],7,$wks[3],'L',0,'C');
     $pdf->Cell($z[4],7,$wks[4],'L',0,'C'); $pdf->Cell($z[5],7,$wks[5],'LR',0,'C');
      $pdf->Cell($z[6],7,$wks[6],'R',0,'C'); $pdf->Cell($z[7],7,$wks[7],'R',0,'C');
    $pdf->Ln(); 
    
$pdf->SetFont('Times','',10);
//Table with 20 rows and 4 columns
$pdf->SetWidths(array(10,65,15,20,20,20,20,20));
$pdf->SetAligns(array('C','L','C','R','R','R','R','R'));
srand(microtime()*1000000);
$pdf->SetFillColor(255, 255, 255);

$item_cat = array('table' => 'dbo.item_category', 'select' => " code, description, sub_cat ", 'where' =>" WHERE cat_type = 'GD' "); 
$gd_cat = $dbOperation->getdata($item_cat); 

$item_cat2 = array('table' => 'dbo.item_category', 'select' => " code, description, sub_cat ", 'where' =>" WHERE cat_type = 'WK' "); 
$wk_cat = $dbOperation->getdata($item_cat2);

$item_cat3 = array('table' => 'dbo.item_category', 'select' => " code, description, sub_cat ", 'where' =>" WHERE cat_type = 'SR' "); 
$sr_cat = $dbOperation->getdata($item_cat3);
$cat_count = 1;
if(!empty($gd_cat)){     
 foreach ($gd_cat as $gd_val) {
 $sub_value = trim($gd_val['sub_cat']);
 $cat_code = trim($gd_val['code']);
 $cat_name = $gd_val['description'];
 
$queryConfig = array('table' => 'dbo.weekly_price', 'where' =>" WHERE cat_code = '$cat_code' AND month_report = '$mth' AND year_report = '$yr' "); 
$data = $dbOperation->getdata($queryConfig); 

if(!empty($data)){    
     
    $pdf->SetFont('Arial','B',10);     
    if($sub_value == "Y"){     
        
    $item_subcat = array('table' => 'dbo.item_subcategory', 'select' => " code, description ", 'where' =>" WHERE category_code = '$cat_code' "); 
    $gd_subcat = $dbOperation->getdata($item_subcat); 
    
    foreach ($gd_subcat as $gd_subval) {        
        $subcat_code = trim($gd_subval['code']);
        $subcat_name = $gd_subval['description'];
      $querysub = array('table' => 'dbo.weekly_price', 'where' =>" WHERE sub_code = '$subcat_code' AND month_report = '$mth' AND year_report = '$yr'  "); 
      $datasb = $dbOperation->getdata($querysub); 
     if(!empty($datasb)){ 
       $pdf->SetFont('Arial','B',10);   
       $pdf->Row(array($cat_count++,$subcat_name, " ", " "," "," ", " ", " "));
    
    $arr_cnt = count($datasb);
    $pdf->SetFont('Times','',9);
    $avg_wk1 = 0;  $avg_wk2 = 0; $avg_wk3 = 0;  $avg_wk4 = 0; 
    for($i=0;$i<$arr_cnt;$i++){
      $avg_wk1 += (int)$datasb[$i]['week1'];  $avg_wk2+= (int)$datasb[$i]['week2']; 
     $avg_wk3 += (int)$datasb[$i]['week3'];  $avg_wk4 += (int)$datasb[$i]['week4'];      
    $sn = $i + 1;
    $rsn = strtolower($pdf->n2r($sn));
    $pdf->Row(array($rsn,$datasb[$i]['description'],$datasb[$i]['unit_of_measurement'],number_format($datasb[$i]['week1'],0),number_format($datasb[$i]['week2'],0),number_format($datasb[$i]['week3'],0),number_format($datasb[$i]['week4'],0),number_format($datasb[$i]['ave_weeks'],0)));
         
        }  
        $pdf->SetFont('Times','B',9);
        $pdf->Row(array(" ","Total weekly price ", " ", number_format($avg_wk1,0),number_format($avg_wk2,0),number_format($avg_wk3,0),number_format($avg_wk4,0), " "));
        $pdf->SetFont('Times','',9);
        $pdf->Row(array(" "," ", " ", " "," "," ", " ", " "));  
     }  
     
    } 
    }    
    else{
    $pdf->Row(array($cat_count++,$cat_name, " ", " "," "," ", " ", " "));    
    $pdf->SetFont('Times','',9);
    $avg_wk1 = 0;  $avg_wk2 = 0; $avg_wk3 = 0;  $avg_wk4 = 0; 
    foreach($data as $dt){ 
     $avg_wk1 += (int)$dt['week1'];  $avg_wk2+= (int)$dt['week2']; 
     $avg_wk3 += (int)$dt['week3'];  $avg_wk4 += (int)$dt['week4'];   
       $sn ++;
    $rsn = strtolower($pdf->n2r($sn));
    $pdf->Row(array($rsn,$dt['description'],$dt['unit_of_measurement'],number_format($dt['week1'],0),number_format($dt['week2'],0),number_format($dt['week3'],0),number_format($dt['week4'],0),number_format($dt['ave_weeks'],0)));
     
    }  
     $pdf->SetFont('Times','B',9);
     $pdf->Row(array(" ","Total weekly price ", " ", number_format($avg_wk1,0),number_format($avg_wk2,0),number_format($avg_wk3,0),number_format($avg_wk4,0), " "));
     $pdf->SetFont('Times','',9);
     $pdf->Row(array(" "," ", " ", " "," "," ", " ", " "));
        }
}     
          
    } 
} 
if(!empty($wk_cat)){     
 foreach ($wk_cat as $wk_val) {
 $sub_value = trim($wk_val['sub_cat']);
 $cat_code = trim($wk_val['code']);
 $cat_name = $wk_val['description'];
 
$queryConfig = array('table' => 'dbo.weekly_price', 'where' =>" WHERE cat_code = '$cat_code' AND month_report = '$mth' AND year_report = '$yr' "); 
$data = $dbOperation->getdata($queryConfig); 

if(!empty($data)){    
     
    $pdf->SetFont('Arial','B',10);     
    if($sub_value == "Y"){     
        
    $item_subcat = array('table' => 'dbo.item_subcategory', 'select' => " code, description ", 'where' =>" WHERE category_code = '$cat_code' "); 
    $gd_subcat = $dbOperation->getdata($item_subcat); 
    
    foreach ($gd_subcat as $gd_subval) {        
        $subcat_code = trim($gd_subval['code']);
        $subcat_name = $gd_subval['description'];
      $querysub = array('table' => 'dbo.weekly_price', 'where' =>" WHERE sub_code = '$subcat_code' AND month_report = '$mth' AND year_report = '$yr'  "); 
      $datasb = $dbOperation->getdata($querysub); 
     if(!empty($datasb)){ 
       $pdf->SetFont('Arial','B',10);   
       $pdf->Row(array($cat_count++,$subcat_name, " ", " "," "," ", " ", " "));
    
    $arr_cnt = count($datasb);
    $pdf->SetFont('Times','',9);
    $avg_wk1 = 0;  $avg_wk2 = 0; $avg_wk3 = 0;  $avg_wk4 = 0; 
    for($i=0;$i<$arr_cnt;$i++){
      $avg_wk1 += (int)$datasb[$i]['week1'];  $avg_wk2+= (int)$datasb[$i]['week2']; 
     $avg_wk3 += (int)$datasb[$i]['week3'];  $avg_wk4 += (int)$datasb[$i]['week4'];      
    $sn = $i + 1;
    $rsn = strtolower($pdf->n2r($sn));
    $pdf->Row(array($rsn,$datasb[$i]['description'],$datasb[$i]['unit_of_measurement'],number_format($datasb[$i]['week1'],0),number_format($datasb[$i]['week2'],0),number_format($datasb[$i]['week3'],0),number_format($datasb[$i]['week4'],0),number_format($datasb[$i]['ave_weeks'],0)));
         
        }  
        $pdf->SetFont('Times','B',9);
        $pdf->Row(array(" ","Total weekly price ", " ", number_format($avg_wk1,0),number_format($avg_wk2,0),number_format($avg_wk3,0),number_format($avg_wk4,0), " "));
        $pdf->SetFont('Times','',9);
        $pdf->Row(array(" "," ", " ", " "," "," ", " ", " "));  
     }  
     
    } 
    }    
    else{
    $pdf->Row(array($cat_count++,$cat_name, " ", " "," "," ", " ", " "));    
    $pdf->SetFont('Times','',9);
    $avg_wk1 = 0;  $avg_wk2 = 0; $avg_wk3 = 0;  $avg_wk4 = 0; 
    foreach($data as $dt){ 
     $avg_wk1 += (int)$dt['week1'];  $avg_wk2+= (int)$dt['week2']; 
     $avg_wk3 += (int)$dt['week3'];  $avg_wk4 += (int)$dt['week4'];   
       $sn ++;
    $rsn = strtolower($pdf->n2r($sn));
    $pdf->Row(array($rsn,$dt['description'],$dt['unit_of_measurement'],number_format($dt['week1'],0),number_format($dt['week2'],0),number_format($dt['week3'],0),number_format($dt['week4'],0),number_format($dt['ave_weeks'],0)));
     
    }  
     $pdf->SetFont('Times','B',9);
     $pdf->Row(array(" ","Total weekly price ", " ", number_format($avg_wk1,0),number_format($avg_wk2,0),number_format($avg_wk3,0),number_format($avg_wk4,0), " "));
     $pdf->SetFont('Times','',9);
     $pdf->Row(array(" "," ", " ", " "," "," ", " ", " "));
        }
}     
          
    } 
} 
if(!empty($sr_cat)){     
 foreach ($sr_cat as $sr_val) {
 $sub_value = trim($sr_val['sub_cat']);
 $cat_code = trim($sr_val['code']);
 $cat_name = $sr_val['description'];
 
$queryConfig = array('table' => 'dbo.weekly_price', 'where' =>" WHERE cat_code = '$cat_code' AND month_report = '$mth' AND year_report = '$yr' "); 
$data = $dbOperation->getdata($queryConfig); 

if(!empty($data)){    
     
    $pdf->SetFont('Arial','B',10);     
    if($sub_value == "Y"){     
        
    $item_subcat = array('table' => 'dbo.item_subcategory', 'select' => " code, description ", 'where' =>" WHERE category_code = '$cat_code' "); 
    $gd_subcat = $dbOperation->getdata($item_subcat); 
    
    foreach ($gd_subcat as $gd_subval) {        
        $subcat_code = trim($gd_subval['code']);
        $subcat_name = $gd_subval['description'];
      $querysub = array('table' => 'dbo.weekly_price', 'where' =>" WHERE sub_code = '$subcat_code' AND month_report = '$mth' AND year_report = '$yr'  "); 
      $datasb = $dbOperation->getdata($querysub); 
     if(!empty($datasb)){ 
       $pdf->SetFont('Arial','B',10);   
       $pdf->Row(array($cat_count++,$subcat_name, " ", " "," "," ", " ", " "));
    
    $arr_cnt = count($datasb);
    $pdf->SetFont('Times','',9);
    $avg_wk1 = 0;  $avg_wk2 = 0; $avg_wk3 = 0;  $avg_wk4 = 0; 
    for($i=0;$i<$arr_cnt;$i++){
      $avg_wk1 += (int)$datasb[$i]['week1'];  $avg_wk2+= (int)$datasb[$i]['week2']; 
     $avg_wk3 += (int)$datasb[$i]['week3'];  $avg_wk4 += (int)$datasb[$i]['week4'];      
    $sn = $i + 1;
    $rsn = strtolower($pdf->n2r($sn));
    $pdf->Row(array($rsn,$datasb[$i]['description'],$datasb[$i]['unit_of_measurement'],number_format($datasb[$i]['week1'],0),number_format($datasb[$i]['week2'],0),number_format($datasb[$i]['week3'],0),number_format($datasb[$i]['week4'],0),number_format($datasb[$i]['ave_weeks'],0)));
         
        }  
        $pdf->SetFont('Times','B',9);
        $pdf->Row(array(" ","Total weekly price ", " ", number_format($avg_wk1,0),number_format($avg_wk2,0),number_format($avg_wk3,0),number_format($avg_wk4,0), " "));
        $pdf->SetFont('Times','',9);
        $pdf->Row(array(" "," ", " ", " "," "," ", " ", " "));  
     }  
     
    } 
    }    
    else{
    $pdf->Row(array($cat_count++,$cat_name, " ", " "," "," ", " ", " "));    
    $pdf->SetFont('Times','',9);
    $avg_wk1 = 0;  $avg_wk2 = 0; $avg_wk3 = 0;  $avg_wk4 = 0; 
    foreach($data as $dt){ 
     $avg_wk1 += (int)$dt['week1'];  $avg_wk2+= (int)$dt['week2']; 
     $avg_wk3 += (int)$dt['week3'];  $avg_wk4 += (int)$dt['week4'];   
       $sn ++;
    $rsn = strtolower($pdf->n2r($sn));
    $pdf->Row(array($rsn,$dt['description'],$dt['unit_of_measurement'],number_format($dt['week1'],0),number_format($dt['week2'],0),number_format($dt['week3'],0),number_format($dt['week4'],0),number_format($dt['ave_weeks'],0)));
     
    }  
     $pdf->SetFont('Times','B',9);
     $pdf->Row(array(" ","Total weekly price ", " ", number_format($avg_wk1,0),number_format($avg_wk2,0),number_format($avg_wk3,0),number_format($avg_wk4,0), " "));
     $pdf->SetFont('Times','',9);
     $pdf->Row(array(" "," ", " ", " "," "," ", " ", " "));
        }
}     
          
    } 
} 
    $pdf->Output();
?>
