<?php
require('../fpdf.php');

class PDF_MC_Table extends FPDF
{
var $widths;
var $aligns;

// Page header
function Header()
{
    // Logo
    $this->Image('rivers_logo.png',170,6,17,17);
    
    $this->SetFont('Arial','B',11);
    // Line break
    $this->Ln(16);
    $w = array(10, 120, 25, 25);
    $z = array(10,120, 25, 25);   
    $amt = "AMOUNT (N)";
    $header = array('SN','DESCRIPTION', 'UNIT', $amt);     
    for($i=0;$i<count($header);$i++)
        $this->Cell($w[$i],7,$header[$i],1,0,'C');
    $this->Ln();  
}

// Page footer
function Footer()
{
    // Position at 1.5 cm from bottom
     $this->SetY(-15);
    // Arial italic 8
      $this->Image('rsbopp_logo.png',170,275,15,15);
    $this->SetFont('Arial','I',8);
    // Page number
    $this->Cell(0,10,'Page '.$this->PageNo().'/{nb}',0,0,'C');
}
function SetWidths($w)
{
    //Set the array of column widths
    $this->widths=$w;
}

function SetAligns($a)
{
    //Set the array of column alignments
    $this->aligns=$a;
}

function Row($data)
{
    //Calculate the height of the row
    $nb=0;
    for($i=0;$i<count($data);$i++)
        $nb=max($nb,$this->NbLines($this->widths[$i],$data[$i]));
    $h=5*$nb;
    //Issue a page break first if needed
    $this->CheckPageBreak($h);
    //Draw the cells of the row
    for($i=0;$i<count($data);$i++)
    {
        $w=$this->widths[$i];
        $a=isset($this->aligns[$i]) ? $this->aligns[$i] : 'L';
        //Save the current position
        $x=$this->GetX();
        $y=$this->GetY();
        //Draw the border
        $this->Rect($x,$y,$w,$h);
        //Print the text
        $this->MultiCell($w,5,$data[$i],0,$a);
        //Put the position to the right of the cell
        $this->SetXY($x+$w,$y);
    }
    //Go to the next line
    $this->Ln($h);
}

function CheckPageBreak($h)
{
    //If the height h would cause an overflow, add a new page immediately
    if($this->GetY()+$h>$this->PageBreakTrigger)
        $this->AddPage($this->CurOrientation);
}

function NbLines($w,$txt)
{
    //Computes the number of lines a MultiCell of width w will take
    $cw=&$this->CurrentFont['cw'];
    if($w==0)
        $w=$this->w-$this->rMargin-$this->x;
    $wmax=($w-2*$this->cMargin)*1000/$this->FontSize;
    $s=str_replace("\r",'',$txt);
    $nb=strlen($s);
    if($nb>0 and $s[$nb-1]=="\n")
        $nb--;
    $sep=-1;
    $i=0;
    $j=0;
    $l=0;
    $nl=1;
    while($i<$nb)
    {
        $c=$s[$i];
        if($c=="\n")
        {
            $i++;
            $sep=-1;
            $j=$i;
            $l=0;
            $nl++;
            continue;
        }
        if($c==' ')
            $sep=$i;
        $l+=$cw[$c];
        if($l>$wmax)
        {
            if($sep==-1)
            {
                if($i==$j)
                    $i++;
            }
            else
                $i=$sep+1;
            $sep=-1;
            $j=$i;
            $l=0;
            $nl++;
        }
        else
            $i++;
    }
    return $nl;
}
}
include_once '../../database/db.php'; 

$pdf=new PDF_MC_Table();
$pdf->AliasNbPages();
$pdf->AddPage();

      

$pdf->SetWidths(array(10, 120, 25, 25));
$pdf->SetAligns(array('C','L','C','R'));
srand(microtime()*1000000);

$dbOperation = new DB();
 


$item_cat = array('table' => 'dbo.item_category', 'select' => " code, description, sub_cat ", 'where' =>" WHERE cat_type = 'GD' "); 
$gd_cat = $dbOperation->getdata($item_cat); 

$item_cat2 = array('table' => 'dbo.item_category', 'select' => " code, description, sub_cat ", 'where' =>" WHERE cat_type = 'WK' "); 
$wk_cat = $dbOperation->getdata($item_cat2);

$item_cat3 = array('table' => 'dbo.item_category', 'select' => " code, description, sub_cat ", 'where' =>" WHERE cat_type = 'SR' "); 
$sr_cat = $dbOperation->getdata($item_cat3);

if(!empty($gd_cat)){
    $pdf->SetTextColor(0,0,255);   
     $pdf->SetFont('Arial','B',15);
     $pdf->Cell(180,15,'GOODS',1,0,'L');
     $pdf->Ln();         
     $pdf->SetTextColor(); 
 foreach ($gd_cat as $gd_val) {
 $sub_value = trim($gd_val['sub_cat']);
 $cat_code = trim($gd_val['code']);
 $cat_name = $gd_val['description'];
  
$queryConfig = array('table' => 'dbo.price_list', 'where' =>" WHERE cat_code = '$cat_code' "); 
$data = $dbOperation->getdata($queryConfig); 

if(!empty($data)){    
    $pdf->SetFillColor(0,128,0);  
    $pdf->SetFont('Arial','B',12);   
    $pdf->Cell(180,10,$cat_name,1,0,'L',true);
    $pdf->Ln(); 
    
    if($sub_value == "Y"){     
        
    $item_subcat = array('table' => 'dbo.item_subcategory', 'select' => " code, description ", 'where' =>" WHERE category_code = '$cat_code' "); 
    $gd_subcat = $dbOperation->getdata($item_subcat); 
    
    foreach ($gd_subcat as $gd_subval) {        
        $subcat_code = trim($gd_subval['code']);
        $subcat_name = $gd_subval['description'];
      $querysub = array('table' => 'dbo.price_list', 'where' =>" WHERE sub_code = '$subcat_code' "); 
      $datasb = $dbOperation->getdata($querysub); 
     if(!empty($datasb)){ 
       $pdf->SetFont('Arial','B',10);   
       $pdf->Row(array(" ",$subcat_name, " ", " "));
    
    $arr_cnt = count($datasb);
    $pdf->SetFont('Times','',11);
    for($i=0;$i<$arr_cnt;$i++){
    $sn = $i + 1;
    $pdf->Row(array($sn,$datasb[$i]['description'],$datasb[$i]['unit_of_measurement'],number_format($datasb[$i]['amount'],0)));
       
        }  
         
     }  
     $pdf->Row(array(" "," ", " ", " "));
    } 
    }    
    else{    
    $arr_cnt = count($data);
    $pdf->SetFont('Times','',11);
    for($i=0;$i<$arr_cnt;$i++){
    $sn = $i + 1;
    $pdf->Row(array($sn,$data[$i]['description'],$data[$i]['unit_of_measurement'],number_format($data[$i]['amount'],0)));
       
        }
     $pdf->Row(array(" "," ", " ", " "));
        }
}     
          
    } 
} 
    
if(!empty($wk_cat)){
    $pdf->AddPage();
    $pdf->SetTextColor(0,0,255);   
     $pdf->SetFont('Arial','B',15);
     $pdf->Cell(180,15,'WORKS',1,0,'L');
     $pdf->Ln();         
     $pdf->SetTextColor();     
foreach ($wk_cat as $wk_val) {
 $sub_value = trim($wk_val['sub_cat']);
 $cat_code = trim($wk_val['code']);
 $cat_name = $wk_val['description'];
  
$queryConfig = array('table' => 'dbo.price_list', 'where' =>" WHERE cat_code = '$cat_code' "); 
$data = $dbOperation->getdata($queryConfig); 

if(!empty($data)){    
    $pdf->SetFillColor(0,128,0);  
    $pdf->SetFont('Arial','B',12);   
    $pdf->Cell(180,10,$cat_name,1,0,'L',true);
    $pdf->Ln(); 
    
    if($sub_value == "Y"){     
        
    $item_subcat = array('table' => 'dbo.item_subcategory', 'select' => " code, description ", 'where' =>" WHERE category_code = '$cat_code' "); 
    $gd_subcat = $dbOperation->getdata($item_subcat); 
    
    foreach ($gd_subcat as $gd_subval) {        
        $subcat_code = trim($gd_subval['code']);
        $subcat_name = $gd_subval['description'];
      $querysub = array('table' => 'dbo.price_list', 'where' =>" WHERE sub_code = '$subcat_code' "); 
      $datasb = $dbOperation->getdata($querysub); 
     if(!empty($datasb)){ 
       $pdf->SetFont('Arial','B',10);   
       $pdf->Row(array(" ",$subcat_name, " ", " "));
    
    $arr_cnt = count($datasb);
    $pdf->SetFont('Times','',11);
    for($i=0;$i<$arr_cnt;$i++){
    $sn = $i + 1;
    $pdf->Row(array($sn,$datasb[$i]['description'],$datasb[$i]['unit_of_measurement'],number_format($datasb[$i]['amount'],0)));
       
        }  
         
     }  
     $pdf->Row(array(" "," ", " ", " "));
    } 
    }    
    else{    
    $arr_cnt = count($data);
    $pdf->SetFont('Times','',11);
    for($i=0;$i<$arr_cnt;$i++){
    $sn = $i + 1;
    $pdf->Row(array($sn,$data[$i]['description'],$data[$i]['unit_of_measurement'],number_format($data[$i]['amount'],0)));
       
        }
     $pdf->Row(array(" "," ", " ", " "));
        }
}     
          
    }    
}

if(!empty($sr_cat)){
    $pdf->AddPage();
    $pdf->SetTextColor(0,0,255);   
     $pdf->SetFont('Arial','B',15);
     $pdf->Cell(180,15,'SERVICES',1,0,'L');
     $pdf->Ln();         
     $pdf->SetTextColor();     
foreach ($sr_cat as $sr_val) {
 $sub_value = trim($sr_val['sub_cat']);
 $cat_code = trim($sr_val['code']);
 $cat_name = $sr_val['description'];
  
$queryConfig = array('table' => 'dbo.price_list', 'where' =>" WHERE cat_code = '$cat_code' "); 
$data = $dbOperation->getdata($queryConfig); 

if(!empty($data)){    
    $pdf->SetFillColor(0,128,0);  
    $pdf->SetFont('Arial','B',12);   
    $pdf->Cell(180,10,$cat_name,1,0,'L',true);
    $pdf->Ln(); 
    
    if($sub_value == "Y"){     
        
    $item_subcat = array('table' => 'dbo.item_subcategory', 'select' => " code, description ", 'where' =>" WHERE category_code = '$cat_code' "); 
    $gd_subcat = $dbOperation->getdata($item_subcat); 
    
    foreach ($gd_subcat as $gd_subval) {        
        $subcat_code = trim($gd_subval['code']);
        $subcat_name = $gd_subval['description'];
      $querysub = array('table' => 'dbo.price_list', 'where' =>" WHERE sub_code = '$subcat_code' "); 
      $datasb = $dbOperation->getdata($querysub); 
     if(!empty($datasb)){ 
       $pdf->SetFont('Arial','B',10);   
       $pdf->Row(array(" ",$subcat_name, " ", " "));
    
    $arr_cnt = count($datasb);
    $pdf->SetFont('Times','',11);
    for($i=0;$i<$arr_cnt;$i++){
    $sn = $i + 1;
    $pdf->Row(array($sn,$datasb[$i]['description'],$datasb[$i]['unit_of_measurement'],number_format($datasb[$i]['amount'],0)));
       
        }  
         
     }  
     $pdf->Row(array(" "," ", " ", " "));
    } 
    }    
    else{    
    $arr_cnt = count($data);
    $pdf->SetFont('Times','',11);
    for($i=0;$i<$arr_cnt;$i++){
    $sn = $i + 1;
    $pdf->Row(array($sn,$data[$i]['description'],$data[$i]['unit_of_measurement'],number_format($data[$i]['amount'],0)));
       
        }
     $pdf->Row(array(" "," ", " ", " "));
        }
}     
          
    }    
}
    $pdf->Output();
?>
