<?php
require('../fpdf.php');

class PDF_MC_Table extends FPDF
{
var $widths;
var $aligns;
var $styles;
var $sizes;
var $borders;

// Page header
function Header()
{
    // Logo
    $this->Image('rivers_logo.png',260,6,15,15);
    // Arial bold 15
    $this->SetFont('Arial','B',15);
    // Move to the right
    //$this->Cell(80);
     
    // Line break
    $this->Ln(2);
}

// Page footer
function Footer()
{
    // Position at 1.5 cm from bottom
     $this->SetY(-15);   
     
    $this->SetFont('Arial','I',8);
    // Page number
    $this->Cell(0,10,'Page '.$this->PageNo().'/{nb}',0,0,'C');
}
function SetWidths($w)
{
    //Set the array of column widths
    $this->widths=$w;
}

function SetAligns($a)
{
    //Set the array of column alignments
    $this->aligns=$a;
}
function SetStyle($a)
{
    //Set the array of column alignments
    $this->styles=$a;
}
function SetSize($a)
{
    //Set the array of column alignments
    $this->sizes=$a;
}
function SetBorder($a)
{
    //Set the array of column alignments
    $this->borders=$a;
}

function Row($data)
{
    //Calculate the height of the row
    $nb=0;
    for($i=0;$i<count($data);$i++)
        $nb=max($nb,$this->NbLines($this->widths[$i],$data[$i]));
    $h=5*$nb;
    //Issue a page break first if needed
    $this->CheckPageBreak($h);
    //Draw the cells of the row
    for($i=0;$i<count($data);$i++)
    {
        $w=$this->widths[$i];
        $a=isset($this->aligns[$i]) ? $this->aligns[$i] : 'L';
        //Save the current position
        $x=$this->GetX();
        $y=$this->GetY();
        //Draw the border
        $this->Rect($x,$y,$w,$h);
        //Print the text
        $this->MultiCell($w,5,$data[$i],0,$a);
        //Put the position to the right of the cell
        $this->SetXY($x+$w,$y);
    }
    //Go to the next line
    $this->Ln($h);
}

function TopRow($data)
{
    //Calculate the height of the row
    $nb=0;
    for($i=0;$i<count($data);$i++)
        $nb=max($nb,$this->NbLines($this->widths[$i],$data[$i]));
    $h=5*$nb;
    //Issue a page break first if needed
    $this->CheckPageBreak($h);
    //Draw the cells of the row
    for($i=0;$i<count($data);$i++)
    {
        $w=$this->widths[$i];
        $a=isset($this->aligns[$i]) ? $this->aligns[$i] : 'L';
        //Save the current position
        $x=$this->GetX();
        $y=$this->GetY();
       
        $t=$this->styles[$i];   $s=$this->sizes[$i];  $b=$this->borders[$i];      
        $this->SetFont('Times',$t,$s);
        $this->MultiCell($w,5,$data[$i],$b,$a);
        //Put the position to the right of the cell
        $this->SetXY($x+$w,$y);
    }
    //Go to the next line
    $this->Ln(15);
}
function MiddleRow($data)
{
   //Calculate the height of the row
    $nb=0;
    for($i=0;$i<count($data);$i++)
        $nb=max($nb,$this->NbLines($this->widths[$i],$data[$i]));
    $h=5*$nb;
    //Issue a page break first if needed
    $this->CheckPageBreak($h);
    //Draw the cells of the row
    for($i=0;$i<count($data);$i++)
    {
        $w=$this->widths[$i];
        $a=isset($this->aligns[$i]) ? $this->aligns[$i] : 'L';
        //Save the current position
        $x=$this->GetX();
        $y=$this->GetY();
       
        $t=$this->styles[$i];   $s=$this->sizes[$i];  $b=$this->borders[$i];
        
        $this->SetFillColor(255, 0, 255);
        $this->SetFont('Times',$t,$s);
        $this->MultiCell($w,3,$data[$i],$b,$a);
        //Put the position to the right of the cell
        $this->SetXY($x+$w,$y);
    }
    //Go to the next line
    $this->Ln(6);
    $this->SetFillColor(255,0,0);
}
function MainRow($data)
{
    //Calculate the height of the row
    $nb=0;
    for($i=0;$i<count($data);$i++)
        $nb=max($nb,$this->NbLines($this->widths[$i],$data[$i]));
    $h=3*$nb;
    //Issue a page break first if needed
    $this->CheckPageBreak($h);
    //Draw the cells of the row
    for($i=0;$i<count($data);$i++)
    {
        $w=$this->widths[$i];
        $a=isset($this->aligns[$i]) ? $this->aligns[$i] : 'L';
        //Save the current position
        $x=$this->GetX();
        $y=$this->GetY();
        //Draw the border
        $b = 0;
        if($i == 0 || $i == 1){
            $b = 'LTR';
        }
        else{$this->Rect($x,$y,$w,$h);}
        //$this->Rect($x,$y,$w,$h);
        $s=$this->sizes[$i]; 
        $this->SetFont('Times','',$s);
        $this->MultiCell($w,3,$data[$i],$b,$a);
        //Put the position to the right of the cell
        $this->SetXY($x+$w,$y);
    }
    //Go to the next line
    $this->Ln($h);
}
function SubRow($data)
{
    //Calculate the height of the row
    $nb=0;
    for($i=0;$i<count($data);$i++)
        $nb=max($nb,$this->NbLines($this->widths[$i],$data[$i]));
    $h=3*$nb;
    //Issue a page break first if needed
    $this->CheckPageBreak($h);
    //Draw the cells of the row
    for($i=0;$i<count($data);$i++)
    {
        $w=$this->widths[$i];
        $a=isset($this->aligns[$i]) ? $this->aligns[$i] : 'L';
        //Save the current position
        $x=$this->GetX();
        $y=$this->GetY();
        //Draw the border
        $b = 'LR';
        if($i == 0 || $i == 1){
            $b = 'LR';
        }
        else{
            $this->Rect($x,$y,$w,$h);            
        }        
        $s=$this->sizes[$i]; 
        //$this->SetFont('Times','',$s);
        $this->MultiCell($w,3,$data[$i],$b,$a);
        //Put the position to the right of the cell
        $this->SetXY($x+$w,$y);
    }
    //Go to the next line
    $this->Ln($h);
}
function CheckPageBreak($h)
{
    //If the height h would cause an overflow, add a new page immediately
    if($this->GetY()+$h>$this->PageBreakTrigger)
        $this->AddPage($this->CurOrientation);
}

function NbLines($w,$txt)
{
    //Computes the number of lines a MultiCell of width w will take
    $cw=&$this->CurrentFont['cw'];
    if($w==0)
        $w=$this->w-$this->rMargin-$this->x;
    $wmax=($w-2*$this->cMargin)*1000/$this->FontSize;
    $s=str_replace("\r",'',$txt);
    $nb=strlen($s);
    if($nb>0 and $s[$nb-1]=="\n")
        $nb--;
    $sep=-1;
    $i=0;
    $j=0;
    $l=0;
    $nl=1;
    while($i<$nb)
    {
        $c=$s[$i];
        if($c=="\n")
        {
            $i++;
            $sep=-1;
            $j=$i;
            $l=0;
            $nl++;
            continue;
        }
        if($c==' ')
            $sep=$i;
        $l+=$cw[$c];
        if($l>$wmax)
        {
            if($sep==-1)
            {
                if($i==$j)
                    $i++;
            }
            else
                $i=$sep+1;
            $sep=-1;
            $j=$i;
            $l=0;
            $nl++;
        }
        else
            $i++;
    }
    return $nl;
}

}
include_once '../../database/db.php';
$dbOperation = new DB();
$pdf=new PDF_MC_Table('L','mm','A3');
//$pdf=new PDF_MC_Table();
$pdf->AliasNbPages(); 
$pdf->AddPage();
    
   //$plan_id = trim($dbOperation->bite_string($_GET['plan_id']));         
   $plan_id = "2017PE1507801618W";     
        
     $cat = array('W' =>'Works', 'G' => 'Goods','S' => 'Services');
     $stat = array('N' =>'Pending', 'A' => 'Approved','R' => 'Rejected'); 
     
   
    $pdf->SetFillColor(255,0,0);   
    
    // Line break
    $pdf->Ln(10);
    //$pdf->SetLineWidth(.3);
    $pdf->SetFont('Arial','B',10);
    // Header
   
    
    $name_of_org = "\n NAME OF ORGANISATION: "."Rivers State Prigrimage Welfare Board \n"."PROCUREMENT PLAN PERIOD: "." 2017 \n"."PROCUREMENT PLAN CATEGORY: "."GOODS";
    $org = array(400);    
    $org_name = array($name_of_org);
    $pdf->MultiCell($org[0],5,$org_name[0],1,'L');  
    
    $pdf->SetWidths(array(155,10,20,20,40,40,10,60,45));   $pdf->SetAligns(array('C','C','L','C','C','C','C','C','C'));
    $pdf->SetStyle(array('B','B','','B','B','B','B','B','B'));   $pdf->SetSize(array(10,7,5,8,8,8,7,8,8));
    $pdf->SetBorder(array(1,0,1,1,1,1,0,1,1)); 
    $pdf->TopRow(array("\n BASIC DATA \n ","Plan \n vs.\n Actual", "Draft Bid Documents, including specs and quantities draft SPN", " \n Spec Proc Notice Advert \n", " \n Bidding Period \n \n", " \n Bid Evaluation \n ", "Plan \n vs. \n Actual", "\n Contract Finalization \n ","\n Contract Implementation \n \n"));
     
    $pdf->SetWidths(array(10,45,20,15,20,15,15,15,10,20,20,20,20,20,20,10,15,15,15,15,15,15,15));
    $pdf->SetAligns(array('C','C','C','C','C','C','C','C','C','C','C','C','C','C','C','C','C','C','C','C','C','C','C'));
    $pdf->SetStyle(array('B','B','','B','B','B','B','B','B','B','B','B','B','B','B','B','B','B','B','B','B','B','B'));
    $pdf->SetSize(array(6,6,6,6,6,6,6,6,6,6,6,6,6,5,6,6,5,6,6,6,5,6,5));    
    $pdf->SetBorder(array(1,1,1,1,1,1,1,1,0,1,1,1,1,1,1,0,1,1,1,1,1,1,1)); 
    $pdf->MiddleRow(array("S/N \n ","DESCRIPTION \n ", "Package Number \n ", "Lot Number \n ", "Estimated Amount in Naira", "Procurement Method", "Pre or Post Qualification", "Prior or Post Review", " ","Prep by Procuring Entity","Nat Press/Website \n ","Bid Invitation \n Date","Bid Closing Opening","Submission Bid Eval Rpt by P.E","No-objection Date by RSBoPP","","Contract Amount in Naira","Date Contract Award","Date Contract Signature","Date Contract Advert","Opening of Letter of Credit","Arrival of Goods","Inspection Final Acceptance"));
   
    $queryConfig = array('table' => 'dbo.plans_upload', 'where' => " WHERE cat_plan_id = '$plan_id'"); 
    $data = $dbOperation->getdata($queryConfig);

    $queryConfig2 = array('table' => 'dbo.actual_plans', 'where' => " WHERE cat_plan_id = '$plan_id'"); 
    $data2 = $dbOperation->getdata($queryConfig2);

    $cat = array('W' =>'Works', 'G' => 'Goods','S' => 'Services');
    $sta = array('N' =>'Pending', 'A' => 'Approved','R' => 'Rejected');
    $pdf->SetWidths(array(10,45,20,15,20,15,15,15,10,20,20,20,20,20,20,10,15,15,15,15,15,15,15));
    $pdf->SetAligns(array('C','L','C','C','C','C','C','C','C','L','L','C','C','C','C','C','C','C','C','C','C','C','C'));
    $pdf->SetStyle(array('B','B','','B','B','B','B','B','B','B','B','B','B','B','B','B','B','B','B','B','B','B','B'));
    $pdf->SetSize(array(7,7,7,7,7,7,7,7,7,5,5,7,7,5,7,7,7,7,7,7,7,7,7));
    
    
    
    if(!empty($data)){    
    foreach($data as $dt){        
       $sn++;    
      $pdf->SetBorder(array(1,1,1,1,1,1,1,1,0,1,1,1,1,1,1,0,1,1,1,1,1,1,1)); 
      $pdf->MainRow(array($sn,$dt['description'],$dt['package_number'] , $dt['lot_number'], number_format($dt['estimated_amount'],2), $dt['procurement_method'], $dt['qualification'], $dt['review'], "Plan ",$dt['pe_name'],$dt['website'], date_format($dt['invitation_date'], 'd/m/Y'), date_format($dt['closing_opening'], 'd/m/Y'), date_format($dt['evaluation_report'], 'd/m/Y'), date_format($dt['no_objection_date'], 'd/m/Y'),"Plan", number_format($dt['contract_amount'],2), date_format($dt['date_award'], 'd/m/Y'), date_format($dt['date_of_signing'], 'd/m/Y'), date_format($dt['con_advertisement'], 'd/m/Y'),date_format($dt['letter_of_credit'], 'd/m/Y'),date_format($dt['arrival_of_goods'], 'd/m/Y'),date_format($dt['inspection'], 'd/m/Y')));
      $pdf->SetBorder(array(0,0,1,1,1,1,1,1,0,1,1,1,1,1,1,0,1,1,1,1,1,1,1)); 
      $pdf->SubRow(array('','',$dt['package_number'] , $dt['lot_number'], number_format($dt['estimated_amount'],2), $dt['procurement_method'], $dt['qualification'], $dt['review'], "Actual ",$dt['pe_name'],$dt['website'], date_format($dt['invitation_date'], 'd/m/Y'), date_format($dt['closing_opening'], 'd/m/Y'), date_format($dt['evaluation_report'], 'd/m/Y'), date_format($dt['no_objection_date'], 'd/m/Y'),"Actual ", number_format($dt['contract_amount'],2), date_format($dt['date_award'], 'd/m/Y'), date_format($dt['date_of_signing'], 'd/m/Y'), date_format($dt['con_advertisement'], 'd/m/Y'),date_format($dt['letter_of_credit'], 'd/m/Y'),date_format($dt['arrival_of_goods'], 'd/m/Y'),date_format($dt['inspection'], 'd/m/Y')));
   
     }  
    }

    $filename="Goods_2017.pdf";
    
    $pdf->Output('I',$filename); 
    
    
    
    
    
    
    
    
    
    
    
    
    
/*$pdf->SetFont('Times','',9);
//Table with 20 rows and 4 columns
$pdf->SetWidths(array(10,50,55,30,20,25));
$pdf->SetAligns(array('C','L','L','C','C','C'));
srand(microtime()*1000000);
$pdf->SetFillColor(255, 255, 255);

$queryConfig = array('table' => 'dbo.plans_upload', 'where' => "WHERE cat_plan_id = '$plan_id'"); 
$data = $dbOperation->getdata($queryConfig);

$queryConfig2 = array('table' => 'dbo.actual_plans', 'where' => "WHERE cat_plan_id = '$plan_id'"); 
$data2 = $dbOperation->getdata($queryConfig2);

$cat = array('W' =>'Works', 'G' => 'Goods','S' => 'Services');
$sta = array('N' =>'Pending', 'A' => 'Approved','R' => 'Rejected');
if(!empty($data)){    
    foreach($data as $dt){        
       $sn++;         
        $category = $cat[trim($dt['category'])];   $description = $dt['description'];         
        $pe_name = $dt['pe_name'];    $p_year = $dt['p_year'];
        if(trim($sta) == "A"){$date_created = date_format($dt['date_of_reply'], 'd/m/Y');}
        else{$date_created = date_format($dt['date_created'], 'd/m/Y'); }   
        $pdf->Row(array($sn,$pe_name,$description,$p_year,$category,$date_created));
     }  
     $pdf->Ln(10);
 $pdf->SetFont('Arial','B',8); 
 $pdf->Cell(20,10,'','',0,'L');
 $pdf->Cell(80,5,'Prepared by: .................................................','',0,'L');
 $pdf->Cell(80,5,'Reviewed by: .................................................','',0,'L'); 
 
 $pdf->Ln();
 
 $pdf->SetFont('Arial','',8); 
 $pdf->Cell(20,10,'','',0,'L');
 $pdf->Cell(80,5,'Position: ......................................................','',0,'L');
 $pdf->Cell(80,5,'Position: ......................................................','',0,'L'); 
 $pdf->Ln();
 $pdf->Cell(20,10,'','',0,'L');
 $pdf->Cell(80,5,'Signature & Date: ..........................................','',0,'L');
 $pdf->Cell(80,5,'Signature & Date: ..........................................','',0,'L');
 
 $pdf->Output();   
} 
else{
    $pdf->SetFont('Arial','B',12);
    $pdf->SetTextColor(255,0,0);
    $pdf->Cell(200,10,'Please ','',0,'C');
    $pdf->Output(); exit;
}*/
    
    
?>
