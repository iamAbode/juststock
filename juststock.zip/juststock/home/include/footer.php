<footer class="navbar navbar-fixed-bottom">
          <div class="pull-right">
            Powered by Rapidbite <center>&copy; <?php echo date('Y'); ?></center>
          </div>
          <div class="clearfix"></div>
          <?php
          
          //$dbOperation->close();
          ?>
</footer>