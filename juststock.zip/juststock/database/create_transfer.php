<?php
    session_start();
//echo "ok it working"; exit;
 //session_start();

 include_once 'db.php'; 
 $dbOperation = new DB();    
 
 if(isset($_POST['action_type']) && !empty($_POST['action_type']))
        {  
     
     $dbOperation->off_auto();
     
     $dbOperation->start_transaction();
     
        $product_list_array = $_SESSION['cart_item'];  
        $comment = $dbOperation->bite_string($_POST['comment']);   $store = $dbOperation->bite_string($_POST['buyer']);
        $name = ''; $quantity = 0; $price = 0; $product_id = ''; $stmterr = 'ok';
        $by_id = $_SESSION['user_id']; $username = $_SESSION['username'];
        $subtotal = 0; $total = 0; $count = 0;
        $queryConfig = array('table' => "id_table", 'where' => " WHERE name='sales' ",'return_type' => "single" ); 
        $data = $dbOperation->getdata($queryConfig);  
        $nxtval = (int)$data['valu']; $nxtval++;
        $yr = date("Y"); $mth = date("m"); $dy = date("d");
        $tran_id = "TR/".$yr."/".$mth."/".$dy."/".$nxtval;
         $sqlnxt = "UPDATE id_table SET valu = '$nxtval' where name = 'sales'";              
         $stmtnxt = $dbOperation->update($sqlnxt);   
         
if($product_list_array) {
    foreach($product_list_array as $p){
        $count++;
        foreach($p as $key=>$value) {            
           
            switch($key){
                case "product_id": 
                    $product_id = $value;
                    break;
                case "product_name": 
                    $name = $value;
                    break;
                case "product_quantity":
                   $quantity = $value;
                      break;                 
                case "product_price":
                   $price = $value;   
                      break;               
            }
           $subtotal =  bcmul($quantity, $price, 2);
           $f_subtotal = number_format($subtotal, 2);    
        }      
       $total = $total + $subtotal; 
       
        $queryConfig1 = array('table' => "items", 'where' => " WHERE item_id='$product_id' ",'return_type' => "single" ); 
        $data1 = $dbOperation->getdata($queryConfig1);  
        $qty2 = $data1['quantity'];        
        $qty3 = (int)$qty2 - (int)$quantity;
        $cat1 = $data1['category'];
        $make1 = $data1['brand'];
           
       $sql = "INSERT INTO trans_detail (item_id, description, category, brand, trans_id, quantity, price, total, store) VALUES ('$product_id', '$name', '$cat1', '$make1', '$tran_id', '$quantity', '$price', '$subtotal', '$store')";        
        $stmt = $dbOperation->insert($sql);
        
       if($stmt == "ok"){           
         $sql1 = "UPDATE items SET quantity = '$qty3' where item_id = '$product_id'";              
         $stmt1 = $dbOperation->update($sql1);           
       }
       else{ $stmterr = $stmt; }
       
    }
     $f_total = number_format($total,2);
     
}        
         
        $sql2 = "INSERT INTO trans (trans_id, amount, by_id, tran_by, no_of_item, store, comment) VALUES ('$tran_id', '$total', '$by_id', '$username', '$count', '$store', '$comment')";        
        $stmt2 = $dbOperation->insert($sql2);
        
        unset( $_SESSION['cart_item']);
       if( $stmt2 == "ok" && $stmterr == "ok") {
           //echo "cannot insert into db";           
           $dbOperation->tr_commit();
           //$dbOperation->on_auto();
           echo "ok";
        }
        else {
            $dbOperation->rollbk();
            //$dbOperation->on_auto();
            print_r($stmt2);
            //echo "Unable to complete goods transfer at this time";
        }
               
      $dbOperation->on_auto();  
   $dbOperation->close();
               
}
 
 
?>

