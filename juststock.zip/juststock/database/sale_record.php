<?php
 include_once 'db.php'; 
 $dbOperation = new DB(); 
 $tableName = "sales";
 $results = "";
 if(isset($_POST['action_type']) && !empty($_POST['action_type']))
     {
     
    if($_POST['action_type'] == 'data')
        {
        $id = trim($_POST['id']);        
        //$tableName = "dbo.products";
        $whereSQL = " WHERE sales_id = '$id' ";
        $type = "single";
        $queryConfig = array(
        'table' => $tableName,
        'where' => $whereSQL,        
        'return_type' => $type 
        );
 
        $data = $dbOperation->getdata($queryConfig);   
        $dbOperation->close();       
        echo json_encode($data);
        }   
    else if($_POST['action_type'] == 'load')
        {      $table = $_POST['table'];             
        $queryConfig = array(
        'table' => $table              
        ); 
        $data = $dbOperation->getdata($queryConfig);   
        $dbOperation->close();          
        echo json_encode($data);
        }     
    else if($_POST['action_type'] == 'add')
        { 
        
        $code = $dbOperation->bite_string($_POST['code']); 
        $name = $dbOperation->bite_string($_POST['name']); 
        $category = $dbOperation->bite_string($_POST['category']); 
        $brand = $dbOperation->bite_string($_POST['brand']); 
        $unit = $dbOperation->bite_string($_POST['unit']); 
        $amount = $dbOperation->bite_number($_POST['amount']); 
        $item_id = time();
        $sql = "INSERT INTO items (item_id, bar_code, description, category, brand, unit_measure, cost_price) VALUES ('$item_id', '$code', '$name', '$category', '$brand', '$unit', '$amount')";        
        $stmt = $dbOperation->insert($sql);       
        $dbOperation->close();
       if( $stmt == "ok") {
           //echo "cannot insert into db";
           echo "ok";
        }
        else {
            print_r($stmt);
        }
               }

    elseif($_POST['action_type'] == 'edit')
        {
        $sales_id = trim($_POST['id']);              
        $amtEdit = (int)$dbOperation->bite_number($_POST['amtEdit']);        
        $amt_owed = (int)$dbOperation->bite_number($_POST['amt_owed']); 
        $cust = $dbOperation->bite_string($_POST['cust']);
        if($amt_owed > $amtEdit){echo "Invalid amount, please put the appropriate figure"; exit;}
        $amount = $amtEdit - $amt_owed;
        $t_type = "C";
        if($amount == 0){$t_type = "P";}
        $timestamp = date('Y-m-d H:i:s');
        $sql = "UPDATE sales SET amt_owed= '$amount', t_type= '$t_type', date_updated = '$timestamp' where sales_id = '$sales_id'";
        $stmt = $dbOperation->update($sql);
        
        $query = "INSERT INTO balance_payment (sales_id, customer, amt_owed, amt_paid, balance) VALUES ('$sales_id', '$cust', '$amtEdit', '$amt_owed', '$amount')";        
        $stm = $dbOperation->insert($query);
        $dbOperation->close();
        // echo "it got here".$stmt; exit;    
        if( $stmt == "ok") { echo "ok";}
        else {echo "Unable to Update transaction at this time"; }       
        
        }    
        
    elseif($_POST['action_type'] == 'view')
        { //echo "it got here"; exit;
                if(isset($_POST['page'])){
            //Include pagination class file
            include_once '../admin/misc/Pagination.php';
           
            $start = !empty($_POST['page'])?$_POST['page']:0;
            $limit = !empty($_POST['limit'])?$_POST['limit']:10;
            $count = $start; 
            //set conditions for search
            $whereSQL = $orderSQL = '';
            $keywords = $dbOperation->bite_string($_POST['keywords']);
            $sortBy = $_POST['sortBy'];  $p_type = $_POST['p_type'];  $t_type = $_POST['t_type'];           
             
            if(!empty($keywords)){ 
                $whereSQL = " WHERE sales_id LIKE '%".$keywords."%'";   $whereSQL .= " OR buyer LIKE '%".$keywords."%'"; 
                $whereSQL .= " OR sale_by LIKE '%".$keywords."%'";   $whereSQL .= " OR amount LIKE '%".$keywords."%'";
            }
            else if(!empty($p_type) || !empty($t_type)){
                $whereSQL .= " WHERE "; 
                if(!empty($p_type) && !empty($t_type)){
                $whereSQL .= " p_type LIKE '%".$p_type."%'";              
                $whereSQL .= " AND t_type LIKE '%".$t_type."%'";
                     } 
                else if(!empty($p_type) && empty($t_type)){
                $whereSQL .= " p_type LIKE '%".$p_type."%'";                        
                     }                           
                else if(empty($p_type) && !empty($t_type)){               
                $whereSQL .= " t_type LIKE '%".$t_type."%'";
                     }                    
               }  
            
            if(!empty($sortBy)){
                $orderSQL = " ORDER BY sale_date ".$sortBy;
            }else{
                $orderSQL = " ORDER BY sale_date DESC ";
            }
               
              $sql = "SELECT count(sales_id) as code FROM sales ".$whereSQL;
              $data = $dbOperation->getPages($sql);
              $rowCount = $data['code'];    
               
            //initialize pagination class
            $pagConfig = array(
                'currentPage' => $start,
                'totalRows' => $rowCount,
                'perPage' => $limit,
                'link_func' => 'searchFilter'
            );
           
            $pagination =  new Pagination($pagConfig);
             
            $queryConfig = array(
                'table' => 'sales',
                'where' => $whereSQL,
                'limit' => $limit,
                'start' => $start,
                'order_by' => $orderSQL
            );
             
            //get rows
            $data = $dbOperation->getdata($queryConfig);            
            
            $p_type = array('N' => 'None','C' => 'Cash','P' => 'POS','T' => 'Online Transfer');
            $t_type = array('P' => 'Paid','C' => 'Credit');
    
            $dbOperation->close();
            if(!empty($data)){
            $results .= "<table class='table table-hover table-striped table-bordered'>
                  <thead>
                  <tr>                  
                       <th></th>                        
                        <th>SALES ID</th>
                        <th>CUSTOMER</th> 
                        <th>PAYMENT TYPE</th> 
                        <th>TRANSACTION TYPE</th>                        
                        <th>AMOUNT(₦)</th> 
                        <th>DATE OF SALES</th>                          
                        <th>ACTION</th>
                    </tr>
                </thead>";
            $count = 0;
            foreach ($data as $value) {
             $count++;
             $sales_id = $value['sales_id']; 
             $buyer = $value['buyer']; 
             $p1 = $p_type[trim($value['p_type'])]; 
             $t1 = $t_type[trim($value['t_type'])];             
             $amount = number_format($value['amount'],2);             
            $sale_date =  date_format(date_create($value['sale_date']), 'F, j Y');         
           
          $results .= "<tr>     
                     <td>$count</td>                     
                     <td> $sales_id </td> 
                     <td>$buyer</td>                     
                     <td> $p1 </td> 
                     <td>$t1</td> 
                     <td>$amount</td>     
                     <td> $sale_date  </td>                                           
                      <td>  <a target='_blank' title='View Sales Detail' href='sales_detail.php?id=$sales_id' class='glyphicon glyphicon-eye-open'></a>                                                       
                      </td>                    
                    </tr>";       
              }   
               $results .= "</table>";
                echo $results.$pagination->createLinks();
                 
            } else{echo "<br><br><center><font color='red'><h2>Record Not Available</h2></font></center><br><br>";}
                
             }   
        
        }     
     elseif($_POST['action_type'] == 'viewc')
        { //echo "it got here"; exit;
                if(isset($_POST['page'])){
            //Include pagination class file
            include_once '../admin/misc/Pagination.php';
           
            $start = !empty($_POST['page'])?$_POST['page']:0;
            $limit = !empty($_POST['limit'])?$_POST['limit']:10;
            $count = $start; 
            //set conditions for search
            $whereSQL = $orderSQL = '';
            $keywords = $dbOperation->bite_string($_POST['keywords']);
            $sortBy = $_POST['sortBy'];         
            
            if(!empty($keywords)){ 
                $whereSQL = " WHERE t_type = 'C' AND (";
                $whereSQL .= " sales_id LIKE '%".$keywords."%'";   $whereSQL .= " OR buyer LIKE '%".$keywords."%'"; 
                $whereSQL .= " OR sale_by LIKE '%".$keywords."%'";   $whereSQL .= " OR amount LIKE '%".$keywords."%'";
                $whereSQL .= ")";
            }           
            else{
                $whereSQL = " WHERE t_type = 'C' ";
            }
            if(!empty($sortBy)){
                $orderSQL = " ORDER BY sale_date ".$sortBy;
            }else{
                $orderSQL = " ORDER BY sale_date DESC ";
            }
               
              $sql = "SELECT count(sales_id) as code FROM sales ".$whereSQL;
              $data = $dbOperation->getPages($sql);
              $rowCount = $data['code'];    
               
            //initialize pagination class
            $pagConfig = array(
                'currentPage' => $start,
                'totalRows' => $rowCount,
                'perPage' => $limit,
                'link_func' => 'searchFilter'
            );
           
            $pagination =  new Pagination($pagConfig);
             
            $queryConfig = array(
                'table' => 'sales',
                'where' => $whereSQL,
                'limit' => $limit,
                'start' => $start,
                'order_by' => $orderSQL
            );
             
            //get rows
            $data = $dbOperation->getdata($queryConfig);            
            
            $p_type = array('N' => 'None','C' => 'Cash','P' => 'POS','T' => 'Online Transfer');
            $t_type = array('P' => 'Paid','C' => 'Credit');
    
            $dbOperation->close();
            if(!empty($data)){
            $results .= "<table class='table table-hover table-striped table-bordered'>
                  <thead>
                  <tr>                  
                       <th></th>                        
                        <th>SALES ID</th>
                        <th>CUSTOMER</th> 
                        <th>AMOUNT(₦)</th> 
                        <th>AMOUNT OWED(₦)</th>                        
                        <th>DATE OF SALES</th> 
                        <th>DATE UPDATED</th>                         
                        <th>ACTION</th>
                    </tr>
                </thead>";
            $count = 0;
            foreach ($data as $value) {
             $count++;
             $sales_id = $value['sales_id']; 
             $buyer = $value['buyer'];                      
             $amount = number_format($value['amount'],2); 
             $amt_owed = number_format($value['amt_owed'],2);
            $sale_date =  date_format(date_create($value['sale_date']), 'F, j Y');  
            $date_updated =  date_format(date_create($value['date_updated']), 'F, j Y');   
          if($date_updated == "November, 30 -0001") {$date_updated="";}  
           
          $results .= "<tr>     
                     <td>$count</td>                     
                     <td> $sales_id </td> 
                     <td>$buyer</td>                      
                     <td>$amount</td>     
                     <td> $amt_owed  </td>  
                     <td>$sale_date</td>     
                     <td> $date_updated  </td>       
                      <td>  <a target='_blank' title='View Sales Detail' href='sales_detail.php?id=$sales_id' class='glyphicon glyphicon-eye-open'></a>                                                       
                            <a href='javascript:void(0);' title='Update Sales' class='glyphicon glyphicon-pencil' onclick=\" loadContent('$sales_id')\"></a>   
                             </td>                    
                    </tr>";       
              }   
               $results .= "</table>";
                echo $results.$pagination->createLinks();
                 
            } else{echo "<br><br><center><font color='red'><h2>Record Not Available</h2></font></center><br><br>";}
                
             }   
        
        } 
    elseif($_POST['action_type'] == 'tview')
        { //echo "it got here"; exit;
                if(isset($_POST['page'])){
            //Include pagination class file
            include_once '../admin/misc/Pagination.php';
           
            $start = !empty($_POST['page'])?$_POST['page']:0;
            $limit = !empty($_POST['limit'])?$_POST['limit']:30;
            $count = $start; 
            //set conditions for search
            $whereSQL = $orderSQL = '';
            $keywords = $dbOperation->bite_string($_POST['keywords']);
            $sortBy = $_POST['sortBy'];  $s_mth = $_POST['s_mth']; $s_yr = $_POST['s_yr'];                     
             
            if(!empty($keywords)){ 
                $whereSQL = " WHERE trans_id LIKE '%".$keywords."%'";   $whereSQL .= " OR store LIKE '%".$keywords."%'"; 
                $whereSQL .= " OR tran_by LIKE '%".$keywords."%'";   $whereSQL .= " OR amount LIKE '%".$keywords."%'";
            }
            elseif(!empty($s_yr)){   
              $whereSQL .= " WHERE YEAR(tran_date) = '$s_yr' ";   
                if(!empty($s_mth)){ 
                    $whereSQL .= " AND MONTH(tran_date) = '$s_mth' ";                  
                }  
            }         
            if(!empty($sortBy)){
                $orderSQL = " ORDER BY tran_date ".$sortBy;
            }else{
                $orderSQL = " ORDER BY tran_date DESC ";
            }
               
              $sql = "SELECT count(trans_id) as code FROM trans ".$whereSQL;
              $data = $dbOperation->getPages($sql);
              $rowCount = $data['code'];    
               
            //initialize pagination class
            $pagConfig = array(
                'currentPage' => $start,
                'totalRows' => $rowCount,
                'perPage' => $limit,
                'link_func' => 'searchFilter'
            );
           
            $pagination =  new Pagination($pagConfig);
             
            $queryConfig = array(
                'table' => 'trans',
                'where' => $whereSQL,
                'limit' => $limit,
                'start' => $start,
                'order_by' => $orderSQL
            );
             
            //get rows
            $data = $dbOperation->getdata($queryConfig);   
            $dbOperation->close();
            if(!empty($data)){
            $results .= "<table class='table table-hover table-striped table-bordered'>
                  <thead>
                  <tr>                  
                       <th></th>                        
                       <th>TRANSFER ID</th>
                        <th>STORE</th>  
                        <th>NO. OF PRODUCTS TYPE</th> 
                        <th>AMOUNT(₦)</th> 
                        <th>DATE OF TRANSFER</th>                        
                        <th>ACTION</th>
                    </tr>
                </thead>";
            $count = 0;
            foreach ($data as $value) {
             $count++;
             $sales_id = $value['trans_id']; 
             $store = $value['store'];  
             $no_of_item = $value['no_of_item']; 
             $amount = number_format($value['amount'],2);             
            $tran_date =  date_format(date_create($value['tran_date']), 'F, j Y');         
           
          $results .= "<tr>     
                     <td>$count</td>                     
                     <td> $sales_id </td> 
                     <td>$store</td>                     
                     <td> $no_of_item </td>                      
                     <td>$amount</td>     
                     <td> $tran_date  </td>                                           
                      <td>  <a target='_blank' title='View Transfer Detail'  href='trans_detail.php?id=$sales_id' class='glyphicon glyphicon-eye-open'></a>                                                       
                      </td>                    
                    </tr>";       
              }   
               $results .= "</table>";
                echo $results.$pagination->createLinks();
                 
            } else{echo "<br><br><center><font color='red'><h2>Record Not Available</h2></font></center><br><br>";}
                
             }   
        
        }
     else if($_POST['action_type'] == 'rstock')
        { //echo "it got here"; exit;
                if(isset($_POST['page'])){
            //Include pagination class file
            include_once '../admin/misc/Pagination.php';
           
            $start = !empty($_POST['page'])?$_POST['page']:0;
            $limit = !empty($_POST['limit'])?$_POST['limit']:20;
            $count = $start; 
            //set conditions for search
            $whereSQL = $orderSQL = '';
            
            $sortBy = $_POST['sortBy'];  $cat = $_POST['cat'];  $brd = $_POST['brd'];           
            $s_dy = $_POST['s_dy'];  $s_mth = $_POST['s_mth'];  $s_yr = $_POST['s_yr'];
            if(!empty($s_yr)){   
              $whereSQL .= " WHERE YEAR(sale_date) = '$s_yr' ";   
                if(!empty($s_mth)){ 
                    $whereSQL .= " AND MONTH(sale_date) = '$s_mth' ";
                 if(!empty($s_dy)){ 
                     $whereSQL .= " AND DAY(sale_date) = '$s_dy' ";
                 }   
                }  
              
              if(!empty($cat) || !empty($brd)){                
                if(!empty($cat) && !empty($brd)){
                $whereSQL .= " AND category LIKE '%".$cat."%'";              
                $whereSQL .= " AND brand LIKE '%".$brd."%'";
                     } 
                else if(!empty($cat) && empty($brd)){
                $whereSQL .= " AND category LIKE '%".$cat."%'";                        
                     }                           
                else if(empty($cat) && !empty($brd)){               
                $whereSQL .= " AND brand LIKE '%".$brd."%'";
                     }                    
               }  
            }        
            else if(empty($s_yr) && (!empty($cat) || !empty($brd))){                
                 if(!empty($cat) && !empty($brd)){
                $whereSQL .= " WHERE category LIKE '%".$cat."%'";              
                $whereSQL .= " AND brand LIKE '%".$brd."%'";
                     } 
                else if(!empty($cat) && empty($brd)){
                $whereSQL .= " WHERE category LIKE '%".$cat."%'";                        
                     }                           
                else if(empty($cat) && !empty($brd)){               
                $whereSQL .= " WHERE brand LIKE '%".$brd."%'";
                     }                  
               }  
            
            if(!empty($sortBy)){
                $orderSQL = " ORDER BY sale_date ".$sortBy;
            }else{
                $orderSQL = " ORDER BY sale_date DESC ";
            }
               
              $sql = "SELECT count(item_id) as code FROM sales_detail ".$whereSQL;
              $data = $dbOperation->getPages($sql);
              $rowCount = $data['code'];    
               
            //initialize pagination class
            $pagConfig = array(
                'currentPage' => $start,
                'totalRows' => $rowCount,
                'perPage' => $limit,
                'link_func' => 'searchFilter'
            );
           
            $pagination =  new Pagination($pagConfig);
             
            $queryConfig = array(
                'table' => 'sales_detail',
                'where' => $whereSQL,
                'limit' => $limit,
                'start' => $start,
                'order_by' => $orderSQL
            );
             
            //get rows
            $data = $dbOperation->getdata($queryConfig);            
                           
            $dbOperation->close();
            if(!empty($data)){
            $results .= "<table class='table table-hover table-striped table-bordered'>
                  <thead>
                  <tr>                  
                       <th></th>                        
                        <th>DESCRIPTION</th>
                        <th>CATEGORY</th> 
                        <th>QTY</th> 
                        <th>UNIT SP</th>                        
                        <th>TOTAL SP(₦)</th>                       
                        <th>DATE OF SALES</th>
                        <th>ACTION</th>   
                    </tr>
                </thead>";
            $count = !empty($_POST['page'])?$start:0;
            foreach ($data as $value) {
             $count++;   
              $item_id = $value['item_id']; 
              $sales_id = $value['sales_id']; 
            $description = $value['description']; 
            $category = $value['category']; 
            $quantity = $value['quantity'];            
             $price = number_format($value['price'],2);
             $total = number_format($value['total'],2);       
            $sale_date =  date_format(date_create($value['sale_date']), 'F, j Y');         
           
          $results .= "<tr>     
                     <td>$count</td>                     
                     <td> $description </td> 
                     <td>$category</td>                     
                     <td> $quantity </td>                     
                     <td> $price </td> 
                     <td>$total</td>                         
                     <td> $sale_date  </td> 
                         <td><a  title='Return Stock' target='_blank' href='return_item.php?id=$item_id&sales_id=$sales_id' class='glyphicon glyphicon-repeat'></a></td>    
                    </tr>";       
              }   
            $results .= "</table>";
                echo $results.$pagination->createLinks();
                 
            } else{echo "<br><br><center><font color='red'><h2>Record Not Available</h2></font></center><br><br>";}
                
             }   
        
        }          
    elseif($_POST['action_type'] == 'delete')
            {
         $id = $_POST['id'];
        $sql = "delete from dbo.item_category where code = '$id' ";
         $data = $dbOperation->delete($sql);   
        $dbOperation->close();   
        if( $data == "ok") { echo "ok";}
        else {echo "Unable to delete item at this time"; }
            }              
               
               
}
 
 
?>

