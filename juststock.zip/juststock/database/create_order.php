<?php
    session_start();
//echo "ok it working"; exit;
 //session_start();

 include_once 'db.php'; 
 $dbOperation = new DB();    
 
 if(isset($_POST['action_type']) && !empty($_POST['action_type']))
        {  
     
     $dbOperation->off_auto();
     
     $dbOperation->start_transaction();
     
        $product_list_array = $_SESSION['cart_item'];  
        $comment = $dbOperation->bite_string($_POST['comment']);  $p_type = $_POST['p_type'];
        $t_type = $_POST['t_type'];  $buyer = $dbOperation->bite_string($_POST['buyer']);
        $name = ''; $quantity = 0; $price = 0; $product_id = ''; $stmterr = 'ok';
        $by_id = $_SESSION['user_id']; $username = $_SESSION['username'];
        $subtotal = 0; $total = 0; $count = 0;
        $queryConfig = array('table' => "id_table", 'where' => " WHERE name='sales' ",'return_type' => "single" ); 
        $data = $dbOperation->getdata($queryConfig);  
        $nxtval = (int)$data['valu']; $nxtval++;
        $yr = date("Y"); $mth = date("m"); $dy = date("d");
        $sale_id = "JS/".$yr."/".$mth."/".$dy."/".$nxtval;
         $sqlnxt = "UPDATE id_table SET valu = '$nxtval' where name = 'sales'";              
         $stmtnxt = $dbOperation->update($sqlnxt);   
         
if($product_list_array) {
    foreach($product_list_array as $p){
        $count++;
        foreach($p as $key=>$value) {            
           
            switch($key){
                case "product_id": 
                    $product_id = $value;
                    break;
                case "product_name": 
                    $name = $value;
                    break;
                case "product_quantity":
                   $quantity = $value;
                      break;                 
                case "product_price":
                   $price = $value;   
                      break;               
            }
           $subtotal =  bcmul($quantity, $price, 2);
           $f_subtotal = number_format($subtotal, 2);    
        }      
       $total = $total + $subtotal; 
       
        $queryConfig1 = array('table' => "items", 'where' => " WHERE item_id='$product_id' ",'return_type' => "single" ); 
        $data1 = $dbOperation->getdata($queryConfig1);  
        $qty2 = $data1['quantity'];
        $cat1 = $data1['category'];
        $make1 = $data1['brand'];
        $cp = (int)$data1['cost_price'];
        $total_cost = $cp * $quantity;
        $income = $subtotal - $total_cost;
        
        $qty3 = (int)$qty2 - (int)$quantity;
         $date2 = date('Y-m-d');  
         
        $sql = "INSERT INTO sales_detail (item_id, description, category, brand, sales_id, quantity, cost_price, price, total_cost, total, income, date_created) VALUES ('$product_id', '$name', '$cat1', '$make1', '$sale_id', '$quantity', '$cp', '$price', '$total_cost', '$subtotal', '$income', '$date2')";        
        $stmt = $dbOperation->insert($sql);
        
        $timestamp = date('Y-m-d H:i:s');
        $year = (int)date('Y'); $month = (int)date('m'); $day = (int)date('d'); $mth_word = date("F");
        
       if($stmt == "ok"){           
         $sql1 = "UPDATE items SET quantity = '$qty3' where item_id = '$product_id'";              
         $stmt1 = $dbOperation->update($sql1); 
                     
        $queryConfig2 = array('table' => "item_sales", 'where' => " WHERE item_id = '$product_id' AND month_report = $month AND year_report = $year ",'return_type' => "single" ); 
        $data2 = $dbOperation->getdata($queryConfig2);
        
        if($data2['month_report'] == $month ){
            if($day > 0 && $day < 8 ){
                $sql2 = "UPDATE item_sales SET week1 = week1 + '$quantity', month_total = month_total + '$quantity' where item_id = '$product_id' AND month_report = $month AND year_report = $year ";              
                $stmt2 = $dbOperation->update($sql2); 
            }
            else if($day > 7 && $day < 15 ){
               $sql2 = "UPDATE item_sales SET week2 = week2 + '$quantity', month_total = month_total + '$quantity' where item_id = '$product_id' AND month_report = $month AND year_report = $year ";              
                $stmt2 = $dbOperation->update($sql2); 
            }
            else if($day > 14 && $day < 22 ){
               $sql2 = "UPDATE item_sales SET week3 = week3 + '$quantity', month_total = month_total + '$quantity' where item_id = '$product_id' AND month_report = $month AND year_report = $year ";              
                $stmt2 = $dbOperation->update($sql2); 
            }            
            else{
               $sql2 = "UPDATE item_sales SET week4 = week4 + '$quantity', month_total = month_total + '$quantity' where item_id = '$product_id' AND month_report = $month AND year_report = $year ";              
                $stmt2 = $dbOperation->update($sql2);  
            }       
         }
         else{
             $wk = "";   
            if($day > 0 && $day < 8 ){ $wk ="week1"; }
            else if($day > 7 && $day < 15 ){ $wk ="week2"; }
            else if($day > 14 && $day < 22 ){ $wk ="week3"; }
            else { $wk ="week4"; }  
            
             $sql3 = "INSERT INTO item_sales (item_id, description, year_report, month_report, month_word, $wk, month_total) VALUES ('$product_id', '$name', '$year', '$month', '$mth_word', '$quantity', '$quantity')";        
             $stmt3 = $dbOperation->insert($sql3);             
         }
         
         
         $queryConfig3 = array('table' => "item_yearly", 'where' => " WHERE item_id = '$product_id' AND year_report = $year ",'return_type' => "single" ); 
        $data3 = $dbOperation->getdata($queryConfig3);
        
        $col_mth = "month".$month;
        
        if($data3['year_report'] == $year ){           
               $sql3 = "UPDATE item_yearly SET quantity = quantity + '$quantity', $col_mth = $col_mth + '$quantity', date_updated = '$timestamp' where item_id = '$product_id' AND year_report = $year ";              
                $stmt3 = $dbOperation->update($sql3);                 
         }
         else{                        
             $sql3 = "INSERT INTO item_yearly (item_id, description, year_report, $col_mth, quantity, date_updated) VALUES ('$product_id', '$name', '$year', '$quantity', '$quantity', '$timestamp')";        
             $stmt3 = $dbOperation->insert($sql3);             
         }    
                           
       }
       else{ $stmterr = $stmt; }
       
    }
     $f_total = number_format($total,2);
     
}        
         $amt_owed=0;
         if(trim($t_type) == "C"){$amt_owed=$total;}
        //$year = (int)date('Y'); $month = (int)date('m'); $day = (int)date('d'); $mth_word = date("F");
        
        $sql2 = "INSERT INTO sales (sales_id, amount, by_id, sale_by, p_type, t_type, no_of_item, buyer, comment, amt_owed, sales_day, sales_month, sales_year) VALUES ('$sale_id', '$total', '$by_id', '$username', '$p_type', '$t_type', '$count', '$buyer', '$comment', '$amt_owed', '$day', '$month', '$year')";          
        $stmt2 = $dbOperation->insert($sql2);
        
        unset( $_SESSION['cart_item']);
       if( $stmt2 == "ok" && $stmterr == "ok") {
           //echo "cannot insert into db";           
           $dbOperation->tr_commit();
           //$dbOperation->on_auto();
           echo "ok";
        }
        else {
            $dbOperation->rollbk();
            //$dbOperation->on_auto();
            //print_r($stmt2);
            echo "Unable to complete transaction at this time";
        }
               
      $dbOperation->on_auto();  
   $dbOperation->close();
               
}
 
 
?>

