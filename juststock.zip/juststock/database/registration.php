<?php
//echo "ok"; exit;
  session_start();

 include_once 'db.php'; 
 
 
 $dbOperation = new DB();   
 
         $firstname = trim($dbOperation->bite_string($_POST['firstname']));  $lastname = trim($dbOperation->bite_string($_POST['lastname']));
        $email = trim($dbOperation->bite_string($_POST['email']));  $category = $_POST['category'];
        $pename = "";          
        $password = trim($dbOperation->bite_string($_POST['password'])); $password2 = trim($dbOperation->bite_string($_POST['password2']));
        if($password != $password2){echo "Password does not match"; exit;}
        if(!preg_match("/^[A-Za-z0-9._\%-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,4}$/", $email))
	{	
	  echo "Invalid Email Address";
	  exit;
	}      
        $password = md5($password);  
        
        $staff_id = "";
        if($category == "PE"){
            $pename = $_POST['pename']; 
            $staff_id= "PE".time();
             $arr = explode(":", $pename);
            $code = $arr[0]; $pename = $arr[1]; 
        }
        else if($category == "CON"){
             $pename = trim($dbOperation->bite_string($_POST['coname'])); 
             $staff_id= "CON".time();
             $code = $staff_id;
        } 
        else{echo "Choose a category"; exit;}
        $sql = "SELECT email FROM  dbo.staff where email = '$email' ";
          $data = $dbOperation->getSingle($sql);            
           if(!empty($data['email'])){
              $dbOperation->close();
              echo "Email Already Exit";                
               exit;                
               }                   
               
        $sql = "INSERT INTO dbo.staff (staff_id, firstname, lastname, email, password, category, code, department) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        $params = array($staff_id, $firstname, $lastname, $email, $password, $category, $code, $pename);


        $stmt = $dbOperation->insert($sql, $params);
        $dbOperation->close();

       if( $stmt == "ok") {          
           echo "ok";
        }
        else {
            echo "Unable to register user at this time";
        }  
 

?>

