<?php
 include_once 'db.php'; 
 $dbOperation = new DB(); 
 $tableName = "items";
 $results = "";
 if(isset($_POST['action_type']) && !empty($_POST['action_type']))
     {
     
    if($_POST['action_type'] == 'data')
        {
        $id = trim($_POST['id']);        
        //$tableName = "dbo.products";
        $whereSQL = " WHERE item_id = '$id' ";
        $type = "single";
        $queryConfig = array(
        'table' => $tableName,
        'where' => $whereSQL,        
        'return_type' => $type 
        );
 
        $data = $dbOperation->getdata($queryConfig);   
        $dbOperation->close();       
        echo json_encode($data);
        }   
    else if($_POST['action_type'] == 'load')
        {      $table = $_POST['table'];             
        $queryConfig = array(
        'table' => $table              
        ); 
        $data = $dbOperation->getdata($queryConfig);   
        $dbOperation->close();          
        echo json_encode($data);
        }     
    else if($_POST['action_type'] == 'add')
        { 
        
        $code = $dbOperation->bite_string($_POST['code']); 
        $name = $dbOperation->bite_string($_POST['name']); 
        $category = $dbOperation->bite_string($_POST['category']); 
        $brand = $dbOperation->bite_string($_POST['brand']); 
        $unit = $dbOperation->bite_string($_POST['unit']); 
        $amount = $dbOperation->bite_number($_POST['amount']); 
        $item_id = time();
        $sql = "INSERT INTO items (item_id, bar_code, description, category, brand, unit_measure, cost_price) VALUES ('$item_id', '$code', '$name', '$category', '$brand', '$unit', '$amount')";        
        $stmt = $dbOperation->insert($sql);       
        $dbOperation->close();
       if( $stmt == "ok") {
           //echo "cannot insert into db";
           echo "ok";
        }
        else {
            print_r($stmt);
        }
               }

    elseif($_POST['action_type'] == 'edit')
        {
        $code = trim($_POST['id']);             
        $ncol = $dbOperation->bite_string($_POST['ncol']); 
        $vcol = $dbOperation->bite_number($_POST['vcol']);       
        $timestamp = date('Y-m-d H:i:s');
        $sql = "UPDATE items SET $ncol = '$vcol', date_updated = '$timestamp' where item_id = '$code'";
              
        $stmt = $dbOperation->update($sql);
        $dbOperation->close();
        // echo "it got here".$stmt; exit;    
        if( $stmt == "ok") { echo "ok";}
        else {echo "Unable to Update item at this time"; }       
        
        }    
        
    elseif($_POST['action_type'] == 'view')
        { //echo "it got here"; exit;
                if(isset($_POST['page'])){
            //Include pagination class file
            include_once '../admin/misc/Pagination.php';
           
            $start = !empty($_POST['page'])?$_POST['page']:0;
            $limit = !empty($_POST['limit'])?$_POST['limit']:10;
            $count = $start; 
            //set conditions for search
            $whereSQL = $orderSQL = '';
            $keywords = $dbOperation->bite_string($_POST['keywords']);
            $sortBy = $_POST['sortBy'];  $cat = $_POST['cat'];  $brd = $_POST['brd'];           
             
            if(!empty($keywords)){ 
                $whereSQL = " WHERE bar_code LIKE '%".$keywords."%'";   $whereSQL .= " OR description LIKE '%".$keywords."%'"; 
                $whereSQL .= " OR category LIKE '%".$keywords."%'";   $whereSQL .= " OR brand LIKE '%".$keywords."%'";
            }
            else if(!empty($cat) || !empty($brd)){
                $whereSQL .= " WHERE "; 
                if(!empty($cat) && !empty($brd)){
                $whereSQL .= " category LIKE '%".$cat."%'";              
                $whereSQL .= " AND brand LIKE '%".$brd."%'";
                     } 
                else if(!empty($cat) && empty($brd)){
                $whereSQL .= " category LIKE '%".$cat."%'";                        
                     }                           
                else if(empty($cat) && !empty($brd)){               
                $whereSQL .= " brand LIKE '%".$brd."%'";
                     }                    
               }  
            
            if(!empty($sortBy)){
                $orderSQL = " ORDER BY date_created ".$sortBy;
            }else{
                $orderSQL = " ORDER BY date_created DESC ";
            }
               
              $sql = "SELECT count(item_id) as code FROM items ".$whereSQL;
              $data = $dbOperation->getPages($sql);
              $rowCount = $data['code'];    
               
            //initialize pagination class
            $pagConfig = array(
                'currentPage' => $start,
                'totalRows' => $rowCount,
                'perPage' => $limit,
                'link_func' => 'searchFilter'
            );
           
            $pagination =  new Pagination($pagConfig);
             
            $queryConfig = array(
                'table' => 'items',
                'where' => $whereSQL,
                'limit' => $limit,
                'start' => $start,
                'order_by' => $orderSQL
            );
             
            //get rows
            $data = $dbOperation->getdata($queryConfig);            
            
            $dbOperation->close();
            if(!empty($data)){
            $results .= "<table class='table table-hover table-striped table-bordered'>
                  <thead>
                  <tr>                  
                       <th></th>                        
                        <th>DESCRIPTION</th> 
                        <th>CATEGORY</th> 
                        <th>MAKE</th>                        
                        <th>QUANTITIES</th> 
                        <th>COST PRICE(₦)</th> 
                        <th>SELLING PRICE(₦)</th>
                        <th>DATE UPDATED</th>                          
                        <th>ACTION</th>
                    </tr>
                </thead>";
            $count = !empty($_POST['page'])?$start:0;
            foreach ($data as $value) {
             $count++;
             $item_id = $value['item_id'];             
             $description = $value['description']; 
             $category = $value['category'];
             $brand = $value['brand'];
             $quantity = $value['quantity'];
             $cost_price = number_format($value['cost_price'],2); 
             $selling_price = number_format($value['selling_price'],2);
            $date_updated =  date_format(date_create($value['date_updated']), 'F, j Y');           
            if($date_updated == "November, 30 -0001") {$date_updated = "";}
          $results .= "<tr>     
                     <td>$count</td>                
                     <td>$description</td>                     
                     <td> $category </td> 
                     <td>$brand</td> 
                     <td>$quantity</td>    
                     <td>$cost_price</td>  
                     <td>$selling_price</td>      
                     <td> $date_updated  </td>                                           
                      <td>  
                             <a href='javascript:void(0);' title='Update Stock' class='glyphicon glyphicon-pencil' onclick=\" loadContent('$item_id')\"></a>   
                          
                      </td>                    
                    </tr>";       
              }   
               $results .= "</table>";
                echo $results.$pagination->createLinks();
                 
            } else{echo "<br><br><center><font color='red'><h2>Brand Not Available</h2></font></center><br><br>";}
                
             }   
        
        }     
            
    elseif($_POST['action_type'] == 'delete')
            {
         $id = $_POST['id'];
        $sql = "delete from dbo.item_category where code = '$id' ";
         $data = $dbOperation->delete($sql);   
        $dbOperation->close();   
        if( $data == "ok") { echo "ok";}
        else {echo "Unable to delete item at this time"; }
            }              
               
               
}
 
 
?>

