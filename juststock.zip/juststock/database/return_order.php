<?php
    session_start();
//echo "ok it working"; exit;
 //session_start();

 include_once 'db.php'; 
 $dbOperation = new DB();    
 
 if(isset($_POST['action_type']) && !empty($_POST['action_type']))
        {  
     
     $dbOperation->off_auto();
     
     $dbOperation->start_transaction();     
        
        $sales_id = $_POST['sales_id'];  $item_id = $_POST['item_id'];  $qty = $_POST['qty']; 
        $price = $_POST['price'];  $total = $_POST['total'];   $sale_date = date_create($_POST['sale_date']);
        $nqty = $dbOperation->bite_number($_POST['nqty']); $description = $_POST['description']; $comment = $_POST['comment'];
        $ntotal = $nqty * $price;
        if($nqty > $qty){ echo "Invalid returned quantities"; exit;}
        $day = (int)date_format($sale_date, "d"); $month = (int)date_format($sale_date, "m"); $year = (int)date_format($sale_date, "Y");
        
        if($ntotal == $total){
            $sql1 = "DELETE FROM sales_detail where item_id = '$item_id' AND sales_id = '$sales_id' ";              
            $stmt1 = $dbOperation->update($sql1);                
         
         $sql3 = "UPDATE items SET quantity = quantity + '$nqty' where item_id = '$item_id'";              
         $stmt3 = $dbOperation->update($sql3);         
       
            if($day > 0 && $day < 8 ){
                $sql2 = "UPDATE item_sales SET week1 = week1 - '$nqty', month_total = month_total - '$nqty' where item_id = '$item_id' AND month_report = $month AND year_report = $year ";              
                $stmt2 = $dbOperation->update($sql2); 
            }
            else if($day > 7 && $day < 15 ){
                $sql2 = "UPDATE item_sales SET week2 = week2 - '$nqty', month_total = month_total - '$nqty' where item_id = '$item_id' AND month_report = $month AND year_report = $year ";              
                $stmt2 = $dbOperation->update($sql2); 
            }
            else if($day > 14 && $day < 22 ){
                $sql2 = "UPDATE item_sales SET week3 = week3 - '$nqty', month_total = month_total - '$nqty' where item_id = '$item_id' AND month_report = $month AND year_report = $year ";              
                $stmt2 = $dbOperation->update($sql2); 
            }            
            else{
                $sql2 = "UPDATE item_sales SET week4 = week4 - '$nqty', month_total = month_total - '$nqty' where item_id = '$item_id' AND month_report = $month AND year_report = $year ";              
                $stmt2 = $dbOperation->update($sql2); 
            }            
              
         $col_mth = "month".$month;               
         $sql3 = "UPDATE item_yearly SET quantity = quantity - '$nqty', $col_mth = $col_mth - '$nqty' where item_id = '$item_id' AND year_report = $year ";              
         $stmt3 = $dbOperation->update($sql3);                        
         
         $sql4 = "DELETE FROM sales where sales_id = '$sales_id'";              
         $stmt4 = $dbOperation->update($sql4);   
         
          $sql5 = "INSERT INTO item_returned (item_id, sales_id, description, comment) VALUES ('$item_id', '$sales_id', '$description', '$comment')";        
          $stmt5 = $dbOperation->insert($sql5);  
            
        }
         else{
             if($nqty == $qty){
            $sql1 = "DELETE FROM sales_detail where item_id = '$item_id' AND sales_id = '$sales_id' ";              
            $stmt1 = $dbOperation->update($sql1);  
             }
             else{
         $sql1 = "UPDATE sales_detail SET quantity = quantity - '$nqty', total = total - '$ntotal' where item_id = '$item_id' AND sales_id = '$sales_id' ";              
         $stmt1 = $dbOperation->update($sql1);                
             }
         $sql3 = "UPDATE items SET quantity = quantity + '$nqty' where item_id = '$item_id'";              
         $stmt3 = $dbOperation->update($sql3);         
       
            if($day > 0 && $day < 8 ){
                $sql2 = "UPDATE item_sales SET week1 = week1 - '$nqty', month_total = month_total - '$nqty' where item_id = '$item_id' AND month_report = $month AND year_report = $year ";              
                $stmt2 = $dbOperation->update($sql2); 
            }
            else if($day > 7 && $day < 15 ){
                $sql2 = "UPDATE item_sales SET week2 = week2 - '$nqty', month_total = month_total - '$nqty' where item_id = '$item_id' AND month_report = $month AND year_report = $year ";              
                $stmt2 = $dbOperation->update($sql2); 
            }
            else if($day > 14 && $day < 22 ){
                $sql2 = "UPDATE item_sales SET week3 = week3 - '$nqty', month_total = month_total - '$nqty' where item_id = '$item_id' AND month_report = $month AND year_report = $year ";              
                $stmt2 = $dbOperation->update($sql2); 
            }            
            else{
                $sql2 = "UPDATE item_sales SET week4 = week4 - '$nqty', month_total = month_total - '$nqty' where item_id = '$item_id' AND month_report = $month AND year_report = $year ";              
                $stmt2 = $dbOperation->update($sql2); 
            }            
              
         $col_mth = "month".$month;               
         $sql3 = "UPDATE item_yearly SET quantity = quantity - '$nqty', $col_mth = $col_mth - '$nqty' where item_id = '$item_id' AND year_report = $year ";              
         $stmt3 = $dbOperation->update($sql3);                        
         
         $sql4 = "UPDATE sales SET amount = amount - '$ntotal' where sales_id = '$sales_id'";              
         $stmt4 = $dbOperation->update($sql4);   
         
          $sql5 = "INSERT INTO item_returned (item_id, sales_id, description, quantity, price, total, comment) VALUES ('$item_id', '$sales_id', '$description', '$nqty', '$price', '$ntotal', '$comment')";       
          $stmt5 = $dbOperation->insert($sql5);  
         }
       if( $stmt1 == "ok") {
           //echo "cannot insert into db";           
           $dbOperation->tr_commit();
           //$dbOperation->on_auto();
           echo "ok";
        }
        else {
            $dbOperation->rollbk();
            //$dbOperation->on_auto();
            //print_r($stmt2);
            echo "Unable to complete transaction at this time";
        }
               
      $dbOperation->on_auto();  
   $dbOperation->close();
               
}
 
 
?>

