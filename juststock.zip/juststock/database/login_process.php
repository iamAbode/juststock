<?php
//echo "ok"; exit;
  session_start();

 include_once 'db.php'; 
 date_default_timezone_set("Africa/Lagos"); 
 
 $dbOperation = new DB();   
 
  $username = $dbOperation->bite_string($_POST['username']);
  $user_password = $dbOperation->bite_string($_POST['password']);
  //echo "ok"; exit;
  $password = md5($user_password);  
  $timestamp = date('Y-m-d H:i:s');
   //$sql = "SELECT * FROM dbo.staffs WHERE email = '$user_email'";
   $tableName = "users";
   $whereSQL = " WHERE username = '$username' ";
   $type = "single";
 $queryConfig = array(
        'table' => $tableName,
        'where' => $whereSQL,        
        'return_type' => $type 
    );
 
   $data = $dbOperation->getdata($queryConfig);   
   
   $status = trim($data['status']);   
   if(($data['password'] == $password)){
      $_SESSION['user_id'] = $data['user_id'];  $_SESSION['firstname'] = $data['firstname']; 
      $_SESSION['lastname'] = $data['lastname'];  $_SESSION['username'] = $data['username'];
      $_SESSION['role'] = $data['role'];       
      
      $dbOperation->close();
     echo "ok";
    
   }
   else if(($data['password'] != $password)){
       $dbOperation->close();
       echo "Invalid Password"; 
   }    
   else{  
       $dbOperation->close();
       echo "Invalid Email or Password ";    
   }
 
 
  

?>

