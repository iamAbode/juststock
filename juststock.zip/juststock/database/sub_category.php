<?php
//echo "ok it working"; exit;
 //session_start();
  //$add = trim($_POST['action_type']);
  //echo "it got".$add; exit;
 include_once '../db.php'; 
 $dbOperation = new DB(); 
 $tableName = "dbo.item_subcategory";
 
 if(isset($_POST['action_type']) && !empty($_POST['action_type']))
     {
     
    if($_POST['action_type'] == 'data')
        {
        $id = trim($_POST['id']);        
        //$tableName = "dbo.products";
        $whereSQL = " WHERE code = '$id' ";
        $type = "single";
        $queryConfig = array(
        'table' => $tableName,
        'where' => $whereSQL,        
        'return_type' => $type 
        );
 
        $data = $dbOperation->getdata($queryConfig);   
        $dbOperation->close();       
        echo json_encode($data);
        }         
    else if($_POST['action_type'] == 'load')
        {                   
        $queryConfig = array(
        'table' => 'dbo.item_category'              
        ); 
        $data = $dbOperation->getdata($queryConfig);   
        $dbOperation->close();          
        echo json_encode($data);
        }    
    else if($_POST['action_type'] == 'add')
        { 
        $category = trim($_POST['category']);
        $name = $dbOperation->bite_string($_POST['name']);          
         
        $where1 = " WHERE code = '$category' ";
        $type = "single";
        $sel = " sub_value ";
        $queryConfig = array(
        'table' => 'item_category',
        'select' => $sel,    
        'where' => $where1,        
        'return_type' => $type 
        ); 
        $data = $dbOperation->getdata($queryConfig);
        $cur = (int)$data['sub_value'];         
        $cur++;
        $code = $category.$cur;
        $sql = "INSERT INTO dbo.item_subcategory (code, description, category_code) VALUES (?, ?, ?)";
        $params = array($code, $name, $category);
        $stmt = $dbOperation->insert($sql, $params);
        
        $sql1 = "UPDATE dbo.item_category SET sub_cat=(?), sub_value=(?) where code = '$category'";
        $params1 = array("Y",$cur);
       
        $stmt1 = $dbOperation->update($sql1, $params1);
        $dbOperation->close();

       if( $stmt == "ok") {           
           echo "ok";
        }
        else {
            echo "Unable to add a item sub category at this time";
        }
               }

    elseif($_POST['action_type'] == 'edit')
        {
        $code = $_POST['idEdit'];              
        $name = $dbOperation->bite_string($_POST['nameEdit']);  
        $cat = $_POST['catEdit'];
        $timestamp = date('Y-m-d H:i:s');
        $sql = "UPDATE dbo.item_subcategory SET description=(?), category_code=(?), date_updated=(?) where code = '$code'";
        $params = array($name, $cat, $timestamp);
       
        $stmt = $dbOperation->update($sql, $params);
        $dbOperation->close();
        // echo "it got here".$stmt; exit;    
        if( $stmt == "ok") { echo "ok";}
        else {echo "Unable to Update Item Sub Category at this time"; }       
        
        }    
        
    elseif($_POST['action_type'] == 'view')
        { 
                if(isset($_POST['page'])){
            //Include pagination class file
            include_once '../../admin/misc/Pagination.php';
           
            $start = !empty($_POST['page'])?$_POST['page']:0;
            $limit = !empty($_POST['limit'])?$_POST['limit']:10;
            $count = $start; 
            //set conditions for search
            $whereSQL = $orderSQL = '';
            $keywords = $_POST['keywords'];
            $sortBy = $_POST['sortBy'];            
             
            if(!empty($keywords)){
                $whereSQL = " WHERE description LIKE '%".$keywords."%'";   $whereSQL .= " OR code LIKE '%".$keywords."%'";               
            }  
            if(!empty($sortBy)){
                $orderSQL = " ORDER BY date_created ".$sortBy;
            }else{
                $orderSQL = " ORDER BY date_created DESC ";
            }
               
              $sql = "SELECT count(indexer) as code FROM dbo.item_subcategory ".$whereSQL;
              $data = $dbOperation->getPages($sql);
              $rowCount = $data['code'];    
               
            //initialize pagination class
            $pagConfig = array(
                'currentPage' => $start,
                'totalRows' => $rowCount,
                'perPage' => $limit,
                'link_func' => 'searchFilter'
            );
           
            $pagination =  new Pagination($pagConfig);
             
            $queryConfig = array(
                'table' => $tableName,
                'where' => $whereSQL,
                'limit' => $limit,
                'start' => $start,
                'order_by' => $orderSQL
            );
             
            //get rows
            $data = $dbOperation->getdata($queryConfig);            
            
            $dbOperation->close();
            $results .= "<table class='table table-hover table-striped'>
                  <thead>
                  <tr>                  
                       <th></th>
                        <th>ID</th>
                        <th>Description</th>                        
                        <th>Date Created</th>  
                        <th>Date Updated</th>  
                        <th>Action</th>
                    </tr>
                </thead>";
            $count = !empty($_POST['page'])?$start:0;
            foreach ($data as $value) {
             $count++;
             $code = $value['code']; 
             $name = $value['description'];              
            $date_created =  date_format($value['date_created'], 'F, j Y');
            $date_updated =  date_format($value['date_updated'], 'F, j Y');
            
          $results .= "<tr>     
                     <td>$count</td>
                     <td> $code </td>
                     <td> $name </td>                     
                      <td> $date_created  </td>
                      <td> $date_updated   </td>                      
                      <td>  <a href='javascript:void(0);' class='glyphicon glyphicon-edit' onclick=\" loadContent('$code','edit')\"></a>                           
                      </td>                    
                    </tr>";       
              }   
               $results .= "</table>";
                echo $results.$pagination->createLinks();
                 
             }   
        
        }     
            
    elseif($_POST['action_type'] == 'delete')
            {
         $id = $_POST['id'];
        $sql = "delete from dbo.item_subcategory where code = '$id' ";
         $data = $dbOperation->delete($sql);   
        $dbOperation->close();   
        if( $data == "ok") { echo "ok";}
        else {echo "Unable to delete item sub category at this time"; }
            }              
               
               
}
 
 
?>

