<?php
class DB{
    private $dbHost     = "localhost";
    private $dbUsername = "root";
    private $dbPassword = "";
    private $dbName     = "juststock";
    
    private $db = false;
    public function __construct(){
        if(!$this->db){
            // Connect to the database
            $conn = new mysqli($this->dbHost, $this->dbUsername, $this->dbPassword, $this->dbName); 
            if($conn->connect_error){
                die("Failed to connect with MySQL: " . $conn->connect_error);
            }else{
                $this->db = $conn;
            }
        }
    }
    public function start_transaction(){
        $this->db->begin_transaction();
    }
    public function rollbk(){
        $this->db->rollback();
    }
    public function tr_commit(){
        $this->db->commit();
    }
    public function on_auto(){
        $this->db->autocommit(true);
    }
    public function off_auto(){
        $this->db->autocommit(false);
    }
    public function getdata($conditions = array()){
        $table = $conditions['table'];
        $sql = 'SELECT ';
        $sql .= array_key_exists("select",$conditions)?$conditions['select']:'*';
        $sql .= ' FROM '.$table;
       if(array_key_exists("where",$conditions)){
            $sql .= $conditions['where'];           
        }
        
        if(array_key_exists("order_by",$conditions)){
            $sql .= $conditions['order_by']; 
        }
                
        if(array_key_exists("start",$conditions) && array_key_exists("limit",$conditions)){
            $sql .= ' LIMIT '.$conditions['start'].','.$conditions['limit']; 
        }elseif(!array_key_exists("start",$conditions) && array_key_exists("limit",$conditions)){
            $sql .= ' LIMIT '.$conditions['limit']; 
        }
        /*else{
            $sql .= ' LIMIT 10';
        }*/
        $result = $this->db->query($sql);
        
        if(array_key_exists("return_type",$conditions) && $conditions['return_type'] != 'all'){
            switch($conditions['return_type']){
                case 'count':
                    $data = $result->num_rows;
                    break;
                case 'single':
                    $data = $result->fetch_assoc();
                    break;
                default:
                    $data = '';
            }
        }else{
            if($result->num_rows > 0){
                while($row = $result->fetch_assoc()){
                    $data[] = $row;
                }
            }
        }
        return !empty($data)?$data:false;
    }
    public function getPages($sql){      
    $result = $this->db->query($sql);
    //$rows = sqlsrv_num_rows( $stmt );
    $data = $result->fetch_assoc();
    return $data;
    }  
   
    public function insert($query){       
            $insert = $this->db->query($query);
            //return $insert?$this->db->insert_id:false;  
            return $insert?"ok":$this->db->error;  
    }
       
    public function update($query){               
            $update = $this->db->query($query);
            //return $update?$this->db->affected_rows:false; 
            return $update?"ok":false;
    }    
  
    public function delete($query){        
        $delete = $this->db->query($query);
        return $delete?"ok":false;
    }
    
    public function bite_string($data){
		if ( !isset($data) or empty($data) ) return '';
        if ( is_numeric($data) ) return $data;
 
        $non_displayables = array(
            '/%0[0-8bcef]/',            // url encoded 00-08, 11, 12, 14, 15
            '/%1[0-9a-f]/',             // url encoded 16-31
            '/[\x00-\x08]/',            // 00-08
            '/\x0b/',                   // 11
            '/\x0c/',                   // 12
            '/[\x0e-\x1f]/'             // 14-31
        );
        foreach ( $non_displayables as $regex )
            $data = preg_replace( $regex, '', $data );
        $data = str_replace("'", "''", $data );
        return $data;
    }
    
    public function bite_number($data){
		if ( !isset($data) or empty($data) ) return '';
        if ( is_numeric($data) ) return $data;
 
        $non_displayables = array(
            '/%0[0-8bcef]/',            // url encoded 00-08, 11, 12, 14, 15
            '/%1[0-9a-f]/',             // url encoded 16-31
            '/[\x00-\x08]/',            // 00-08
            '/\x0b/',                   // 11
            '/\x0c/',                   // 12
            '/[\x0e-\x1f]/'             // 14-31
        );
        foreach ( $non_displayables as $regex )
            $data = preg_replace( $regex, '', $data );
        $data = str_replace("'", "''", $data );
        $data = str_replace(",", "", $data );
        return $data;
    }
    
     public function close(){
       $this->db->close();
    }
}




?>