<?php
 include_once 'db.php'; 
 $dbOperation = new DB(); 
 $tableName = "item_category";
 $results = "";
 if(isset($_POST['action_type']) && !empty($_POST['action_type']))
     {
     
    if($_POST['action_type'] == 'data')
        {
        $id = trim($_POST['id']);        
        //$tableName = "dbo.products";
        $whereSQL = " WHERE cat_id = '$id' ";
        $type = "single";
        $queryConfig = array(
        'table' => $tableName,
        'where' => $whereSQL,        
        'return_type' => $type 
        );
 
        $data = $dbOperation->getdata($queryConfig);   
        $dbOperation->close();       
        echo json_encode($data);
        }   
        
    else if($_POST['action_type'] == 'add')
        { 
        
        $name = $dbOperation->bite_string($_POST['name']);          
        $code = time();
        $sql = "INSERT INTO item_category (cat_id, cat_name) VALUES ('$code', '$name')";        
        $stmt = $dbOperation->insert($sql);       
        $dbOperation->close();
       if( $stmt == "ok") {
           //echo "cannot insert into db";
           echo "ok";
        }
        else {
            print_r($stmt);
        }
               }

    elseif($_POST['action_type'] == 'edit')
        {
        $code = trim($_POST['idEdit']);              
        $name = $dbOperation->bite_string($_POST['nameEdit']);             
        $timestamp = date('Y-m-d H:i:s');
        $sql = "UPDATE item_category SET cat_name= '$name', date_updated= '$timestamp' where cat_id = '$code'";
               
        $stmt = $dbOperation->update($sql);
        $dbOperation->close();
        // echo "it got here".$stmt; exit;    
        if( $stmt == "ok") { echo "ok";}
        else {echo "Unable to Update product Category at this time"; }       
        
        }    
        
    elseif($_POST['action_type'] == 'view')
        { 
                if(isset($_POST['page'])){
            //Include pagination class file
            include_once '../admin/misc/Pagination.php';
           
            $start = !empty($_POST['page'])?$_POST['page']:0;
            $limit = !empty($_POST['limit'])?$_POST['limit']:10;
            $count = $start; 
            //set conditions for search
            $whereSQL = $orderSQL = '';
            $keywords = $dbOperation->bite_string($_POST['keywords']);
            $sortBy = $_POST['sortBy'];            
             
            if(!empty($keywords)){
                $whereSQL = " WHERE cat_name LIKE '%".$keywords."%'";   $whereSQL .= " OR cat_id LIKE '%".$keywords."%'";               
            }  
            if(!empty($sortBy)){
                $orderSQL = " ORDER BY date_created ".$sortBy;
            }else{
                $orderSQL = " ORDER BY date_created DESC ";
            }
               
              $sql = "SELECT count(cat_id) as code FROM item_category ".$whereSQL;
              $data = $dbOperation->getPages($sql);
              $rowCount = $data['code'];    
               
            //initialize pagination class
            $pagConfig = array(
                'currentPage' => $start,
                'totalRows' => $rowCount,
                'perPage' => $limit,
                'link_func' => 'searchFilter'
            );
           
            $pagination =  new Pagination($pagConfig);
             
            $queryConfig = array(
                'table' => 'item_category',
                'where' => $whereSQL,
                'limit' => $limit,
                'start' => $start,
                'order_by' => $orderSQL
            );
             
            //get rows
            $data = $dbOperation->getdata($queryConfig);            
            
            $dbOperation->close();
            if(!empty($data)){
            $results .= "<table class='table table-hover table-striped'>
                  <thead>
                  <tr>                  
                       <th></th>                        
                        <th>Description</th>                        
                        <th>Date Created</th>  
                        <th>Date Updated</th>  
                        <th>Action</th>
                    </tr>
                </thead>";
            $count = !empty($_POST['page'])?$start:0;
            foreach ($data as $value) {
             $count++;
             $code = $value['cat_id']; 
             $name = $value['cat_name'];              
            $date_created =  date_format(date_create($value['date_created']), 'F, j Y');
            $date_updated =  date_format(date_create($value['date_updated']), 'F, j Y');
            if($date_updated != "November, 30 -0001") {$date_updated= $date_updated;}
            else {$date_updated = "";}
          $results .= "<tr>     
                     <td>$count</td>                     
                     <td> $name </td>                     
                      <td> $date_created  </td>
                      <td> $date_updated   </td>                      
                      <td>  <a href='javascript:void(0);' class='glyphicon glyphicon-edit' onclick=\" loadContent('$code','edit')\"></a>                            
                      </td>                    
                    </tr>";       
              }   
               $results .= "</table>";
                echo $results.$pagination->createLinks();
                 
            } else{echo "<br><br><center><font color='red'><h2>Item Category Not Available</h2></font></center><br><br>";}
                
             }   
        
        }     
            
    elseif($_POST['action_type'] == 'delete')
            {
         $id = $_POST['id'];
        $sql = "delete from dbo.item_category where code = '$id' ";
         $data = $dbOperation->delete($sql);   
        $dbOperation->close();   
        if( $data == "ok") { echo "ok";}
        else {echo "Unable to delete item at this time"; }
            }              
               
               
}
 
 
?>

