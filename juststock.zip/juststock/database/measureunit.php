<?php
 include_once '../db.php'; 
 $dbOperation = new DB(); 
 $tableName = "dbo.unit_of_measurement";
 
 if(isset($_POST['action_type']) && !empty($_POST['action_type']))
     {
     
    if($_POST['action_type'] == 'data')
        {
        $id = trim($_POST['id']);        
        //$tableName = "dbo.products";
        $whereSQL = " WHERE unit_code = '$id' ";
        $type = "single";
        $queryConfig = array(
        'table' => $tableName,
        'where' => $whereSQL,        
        'return_type' => $type 
        );
 
        $data = $dbOperation->getdata($queryConfig);   
        $dbOperation->close();       
        echo json_encode($data);
        }         
    else if($_POST['action_type'] == 'load')
        {                   
        $queryConfig = array(
        'table' => 'dbo.item_category'              
        ); 
        $data = $dbOperation->getdata($queryConfig);   
        $dbOperation->close();          
        echo json_encode($data);
        }    
    else if($_POST['action_type'] == 'add')
        {  
        $code = "U".time();
        $name = $dbOperation->bite_string($_POST['name']);         
        
        $sql = "INSERT INTO dbo.unit_of_measurement (unit_code, unit_name) VALUES (?, ?)";
        $params = array($code, $name);
        $stmt = $dbOperation->insert($sql, $params);        
        
        $dbOperation->close();

       if( $stmt == "ok") {           
           echo "ok";
        }
        else {
            echo "Unable to create a unit at this time";
        }
               }

    elseif($_POST['action_type'] == 'edit')
        {
        $code = $_POST['idEdit'];              
        $name = $dbOperation->bite_string($_POST['nameEdit']);          
        $timestamp = date('Y-m-d H:i:s');
        $sql = "UPDATE dbo.unit_of_measurement SET unit_name=(?), date_updated=(?) where unit_code = '$code'";
        $params = array($name, $timestamp);
       
        $stmt = $dbOperation->update($sql, $params);
        $dbOperation->close();
        // echo "it got here".$stmt; exit;    
        if( $stmt == "ok") { echo "ok";}
        else {echo "Unable to Update Unit at this time"; }       
        
        }    
        
    elseif($_POST['action_type'] == 'view')
        { 
                if(isset($_POST['page'])){
            //Include pagination class file
            include_once '../../admin/misc/Pagination.php';
           
            $start = !empty($_POST['page'])?$_POST['page']:0;
            $limit = !empty($_POST['limit'])?$_POST['limit']:10;
            $count = $start; 
            //set conditions for search
            $whereSQL = $orderSQL = '';
            $keywords = $dbOperation->bite_string($_POST['keywords']);
            $sortBy = $_POST['sortBy'];            
             
            if(!empty($keywords)){
                $whereSQL = " WHERE description LIKE '%".$keywords."%'";   $whereSQL .= " OR code LIKE '%".$keywords."%'";               
            }  
            if(!empty($sortBy)){
                $orderSQL = " ORDER BY date_created ".$sortBy;
            }else{
                $orderSQL = " ORDER BY date_created DESC ";
            }
               
              $sql = "SELECT count(indexer) as code FROM dbo.item_subcategory ".$whereSQL;
              $data = $dbOperation->getPages($sql);
              $rowCount = $data['code'];    
               
            //initialize pagination class
            $pagConfig = array(
                'currentPage' => $start,
                'totalRows' => $rowCount,
                'perPage' => $limit,
                'link_func' => 'searchFilter'
            );
           
            $pagination =  new Pagination($pagConfig);
             
            $queryConfig = array(
                'table' => $tableName,
                'where' => $whereSQL,
                'limit' => $limit,
                'start' => $start,
                'order_by' => $orderSQL
            );
             
            //get rows
            $data = $dbOperation->getdata($queryConfig);            
            
            $dbOperation->close();
            $results .= "<table class='table table-hover table-striped'>
                  <thead>
                  <tr>                  
                       <th></th>
                        <th>ID</th>
                        <th>Description</th>                        
                        <th>Date Created</th>  
                        <th>Date Updated</th>  
                        <th>Action</th>
                    </tr>
                </thead>";
            $count = !empty($_POST['page'])?$start:0;
            foreach ($data as $value) {
             $count++;
             $code = $value['code']; 
             $name = $value['description'];              
            $date_created =  date_format($value['date_created'], 'F, j Y');
            $date_updated =  date_format($value['date_updated'], 'F, j Y');
            
          $results .= "<tr>     
                     <td>$count</td>
                     <td> $code </td>
                     <td> $name </td>                     
                      <td> $date_created  </td>
                      <td> $date_updated   </td>                      
                      <td>  <a href='javascript:void(0);' class='glyphicon glyphicon-edit' onclick=\" loadContent('$code','edit')\"></a>
                            <a href='javascript:void(0);' class='glyphicon glyphicon-trash' onclick=\"return confirm('Are you sure to delete data?')?userAction('delete','$code'):false;\"></a>
                      </td>                    
                    </tr>";       
              }   
               $results .= "</table>";
                echo $results.$pagination->createLinks();
                 
             }   
        
        }     
            
    elseif($_POST['action_type'] == 'delete')
            {
         $id = $_POST['id'];
        $sql = "delete from dbo.item_subcategory where code = '$id' ";
         $data = $dbOperation->delete($sql);   
        $dbOperation->close();   
        if( $data == "ok") { echo "ok";}
        else {echo "Unable to delete item sub category at this time"; }
            }              
               
               
}
 
 
?>

