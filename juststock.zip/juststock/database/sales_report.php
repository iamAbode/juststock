<?php
 include_once 'db.php'; 
 $dbOperation = new DB(); 
 $tableName = "sales";
 $results = "";
 if(isset($_POST['action_type']) && !empty($_POST['action_type']))
     {
      if($_POST['action_type'] == 'data')
        {
        $id = trim($_POST['id']);  
        $yr = trim($_POST['yr']);        
        $whereSQL = " WHERE item_id = '$id' AND year_report = '$yr' ";
        $type = "single";
        $queryConfig = array(
        'table' => 'item_yearly',
        'where' => $whereSQL,        
        'return_type' => $type 
        );
 
        $data = $dbOperation->getdata($queryConfig);   
        $dbOperation->close();       
        echo json_encode($data);
        }   
        
    else if($_POST['action_type'] == 'daily')
        { //echo "it got here"; exit;
                if(isset($_POST['page'])){
            //Include pagination class file
            include_once '../admin/misc/Pagination.php';
           
            $start = !empty($_POST['page'])?$_POST['page']:0;
            $limit = !empty($_POST['limit'])?$_POST['limit']:20;
            $count = $start; 
            //set conditions for search
            $whereSQL = $orderSQL = '';
            
            $sortBy = $_POST['sortBy'];  $p_type = $_POST['p_type'];  $t_type = $_POST['t_type'];           
            $s_dy = $_POST['s_dy'];  $s_mth = $_POST['s_mth'];  $s_yr = $_POST['s_yr']; 
            $whereSQL .= " WHERE sales_day = '$s_dy' AND sales_month = '$s_mth' AND sales_year = '$s_yr' "; 
            
            if(!empty($p_type) || !empty($t_type)){                
                if(!empty($p_type) && !empty($t_type)){
                $whereSQL .= " AND p_type LIKE '%".$p_type."%'";              
                $whereSQL .= " AND t_type LIKE '%".$t_type."%'";
                     } 
                else if(!empty($p_type) && empty($t_type)){
                $whereSQL .= " AND p_type LIKE '%".$p_type."%'";                        
                     }                           
                else if(empty($p_type) && !empty($t_type)){               
                $whereSQL .= " AND t_type LIKE '%".$t_type."%'";
                     }                    
               }  
            
            if(!empty($sortBy)){
                $orderSQL = " ORDER BY sale_date ".$sortBy;
            }else{
                $orderSQL = " ORDER BY sale_date DESC ";
            }
               
              $sql = "SELECT count(sales_id) as code FROM sales ".$whereSQL;
              $data = $dbOperation->getPages($sql);
              $rowCount = $data['code'];    
               
            //initialize pagination class
            $pagConfig = array(
                'currentPage' => $start,
                'totalRows' => $rowCount,
                'perPage' => $limit,
                'link_func' => 'searchFilter'
            );
           
            $pagination =  new Pagination($pagConfig);
             
            $queryConfig = array(
                'table' => 'sales',
                'where' => $whereSQL,
                'limit' => $limit,
                'start' => $start,
                'order_by' => $orderSQL
            );
             
            //get rows
            $data = $dbOperation->getdata($queryConfig);            
            $total_amount = 0;
            $p_type = array('N' => 'None','C' => 'Cash','P' => 'POS','T' => 'Online Transfer');
            $t_type = array('P' => 'Paid','C' => 'Credit');
                
            $dbOperation->close();
            if(!empty($data)){
            $results .= "<table class='table table-hover table-striped table-bordered'>
                  <thead>
                  <tr>                  
                       <th></th>                        
                        <th>SALES ID</th>
                        <th>CUSTOMER</th> 
                        <th>PAYMENT TYPE</th> 
                        <th>TRANSACTION TYPE</th>                        
                        <th>AMOUNT(₦)</th> 
                        <th>DATE OF SALES</th>                          
                        <th>ACTION</th>
                    </tr>
                </thead>";
            $count = !empty($_POST['page'])?$start:0;
            foreach ($data as $value) {
             $count++; $total_amount = $total_amount + $value['amount'];
             $sales_id = $value['sales_id']; 
             $buyer = $value['buyer']; 
             $p1 = $p_type[trim($value['p_type'])]; 
             $t1 = $t_type[trim($value['t_type'])];             
             $amount = number_format($value['amount'],2);             
            $sale_date =  date_format(date_create($value['sale_date']), 'F, j Y');         
           
          $results .= "<tr>     
                     <td>$count</td>                     
                     <td> $sales_id </td> 
                     <td>$buyer</td>                     
                     <td> $p1 </td> 
                     <td>$t1</td> 
                     <td>$amount</td>     
                     <td> $sale_date  </td>                                           
                      <td>  <a target='_blank' title='View Sales Detail' href='sales_detail.php?id=$sales_id' class='glyphicon glyphicon-eye-open'></a>                                                       
                      </td>                    
                    </tr>";       
              }   
             $tf_amount = number_format($total_amount,2);
           $results .= "<tr><td></td><td></td><td colspan='3'><strong style='color: black'>TOTAL</strong></td><td colspan='2'><strong style='color: black; font-size: 14px'> $tf_amount </strong> </td><td></td></tr>";   
               $results .= "</table>";
                echo $results.$pagination->createLinks();
                 
            } else{echo "<br><br><center><font color='red'><h2>Record Not Available</h2></font></center><br><br>";}
                
             }   
        
        }  
     else if($_POST['action_type'] == 'inc')
        { //echo "it got here"; exit;
                if(isset($_POST['page'])){
            //Include pagination class file
            include_once '../admin/misc/Pagination.php';
           
            $start = !empty($_POST['page'])?$_POST['page']:0;
            $limit = !empty($_POST['limit'])?$_POST['limit']:20;
            $count = $start; 
            //set conditions for search
            $whereSQL = $orderSQL = '';
            
            $sortBy = $_POST['sortBy'];  $cat = $_POST['cat'];  $brd = $_POST['brd'];           
            $s_dy = $_POST['s_dy'];  $s_mth = $_POST['s_mth'];  $s_yr = $_POST['s_yr'];
            if(!empty($s_yr)){   
              $whereSQL .= " WHERE YEAR(sale_date) = '$s_yr' ";   
                if(!empty($s_mth)){ 
                    $whereSQL .= " AND MONTH(sale_date) = '$s_mth' ";
                 if(!empty($s_dy)){ 
                     $whereSQL .= " AND DAY(sale_date) = '$s_dy' ";
                 }   
                }  
              
              if(!empty($cat) || !empty($brd)){                
                if(!empty($cat) && !empty($brd)){
                $whereSQL .= " AND category LIKE '%".$cat."%'";              
                $whereSQL .= " AND brand LIKE '%".$brd."%'";
                     } 
                else if(!empty($cat) && empty($brd)){
                $whereSQL .= " AND category LIKE '%".$cat."%'";                        
                     }                           
                else if(empty($cat) && !empty($brd)){               
                $whereSQL .= " AND brand LIKE '%".$brd."%'";
                     }                    
               }  
            }        
            else if(empty($s_yr) && (!empty($cat) || !empty($brd))){                
                 if(!empty($cat) && !empty($brd)){
                $whereSQL .= " WHERE category LIKE '%".$cat."%'";              
                $whereSQL .= " AND brand LIKE '%".$brd."%'";
                     } 
                else if(!empty($cat) && empty($brd)){
                $whereSQL .= " WHERE category LIKE '%".$cat."%'";                        
                     }                           
                else if(empty($cat) && !empty($brd)){               
                $whereSQL .= " WHERE brand LIKE '%".$brd."%'";
                     }                  
               }  
            
            if(!empty($sortBy)){
                $orderSQL = " ORDER BY sale_date ".$sortBy;
            }else{
                $orderSQL = " ORDER BY sale_date DESC ";
            }
               
              $sql = "SELECT count(item_id) as code FROM sales_detail ".$whereSQL;
              $data = $dbOperation->getPages($sql);
              $rowCount = $data['code'];    
               
            //initialize pagination class
            $pagConfig = array(
                'currentPage' => $start,
                'totalRows' => $rowCount,
                'perPage' => $limit,
                'link_func' => 'searchFilter'
            );
           
            $pagination =  new Pagination($pagConfig);
             
            $queryConfig = array(
                'table' => 'sales_detail',
                'where' => $whereSQL,
                'limit' => $limit,
                'start' => $start,
                'order_by' => $orderSQL
            );
             
            //get rows
            $data = $dbOperation->getdata($queryConfig);            
                           
            $dbOperation->close();
            if(!empty($data)){
            $results .= "<table class='table table-hover table-striped table-bordered'>
                  <thead>
                  <tr>                  
                       <th></th>                        
                        <th>DESCRIPTION</th>
                        <th>CATEGORY</th> 
                        <th>QTY</th> 
                        <th>UNIT CP</th>                        
                        <th>TOTAL CP(₦)</th> 
                        <th>UNIT SP</th>                        
                        <th>TOTAL SP(₦)</th> 
                        <th>INCOME(₦)</th> 
                        <th>DATE OF SALES</th>
                    </tr>
                </thead>";
            $count = !empty($_POST['page'])?$start:0;
            foreach ($data as $value) { 
             $count++;
            $description = $value['description']; 
            $category = $value['category']; 
            $quantity = $value['quantity']; 
             $cost_price = number_format($value['cost_price'],2); 
             $total_cost = number_format($value['total_cost'],2);
             $price = number_format($value['price'],2);
             $total = number_format($value['total'],2);
             $income = number_format($value['income'],2);
             
            $sale_date =  date_format(date_create($value['sale_date']), 'F, j Y');         
           
          $results .= "<tr>     
                     <td>$count</td>                     
                     <td> $description </td> 
                     <td>$category</td>                     
                     <td> $quantity </td> 
                     <td>$cost_price</td> 
                     <td>$total_cost</td>
                     <td> $price </td> 
                     <td>$total</td> 
                     <td>$income</td>     
                     <td> $sale_date  </td>                                  
                    </tr>";       
              }   
            $results .= "</table>";
                echo $results.$pagination->createLinks();
                 
            } else{echo "<br><br><center><font color='red'><h2>Record Not Available</h2></font></center><br><br>";}
                
             }   
        
        }     
    else if($_POST['action_type'] == 'yearly')
        { //echo "it got here"; exit;
                if(isset($_POST['page'])){
            //Include pagination class file
            include_once '../admin/misc/Pagination.php';
           
            $start = !empty($_POST['page'])?$_POST['page']:0;
            $limit = !empty($_POST['limit'])?$_POST['limit']:20;
            $count = $start; 
            //set conditions for search
            $whereSQL = $orderSQL = '';
            $sortBy = $_POST['sortBy'];  $p_type = $_POST['p_type'];  $t_type = $_POST['t_type'];           
             $s_yr = $_POST['s_yr'];    $s_mth = $_POST['s_mth']; $year = (int)date('Y'); 
            
            if(!empty($p_type) || !empty($t_type) || !empty($s_yr) || !empty($s_mth)){                
                if(!empty($p_type) && !empty($t_type) && !empty($s_yr) && !empty($s_mth)){
                $whereSQL .= " WHERE p_type LIKE '%".$p_type."%'"; 
                $whereSQL .= " AND t_type LIKE '%".$t_type."%'";
                $whereSQL .= " AND sales_year LIKE '%".$s_yr."%'";
                $whereSQL .= " AND sales_month LIKE '%".$s_mth."%'";
                     }
                else if(!empty($p_type) && !empty($t_type) && empty($s_yr) && !empty($s_mth)){
                $whereSQL .= " WHERE p_type LIKE '%".$p_type."%'"; 
                $whereSQL .= " AND t_type LIKE '%".$t_type."%'";                
                $whereSQL .= " AND sales_month LIKE '%".$s_mth."%'";         
                     } 
                else if(!empty($p_type) && empty($t_type) && empty($s_yr) && !empty($s_mth)){
                $whereSQL .= " WHERE p_type LIKE '%".$p_type."%'";                 
                $whereSQL .= " AND sales_month LIKE '%".$s_mth."%'";         
                     } 
                else if(empty($p_type) && empty($t_type) && empty($s_yr) && !empty($s_mth)){                
                $whereSQL .= " WHERE sales_month LIKE '%".$s_mth."%'";         
                     }                
                else if(!empty($p_type) && !empty($t_type) && !empty($s_yr) && empty($s_mth)){
                $whereSQL .= " WHERE p_type LIKE '%".$p_type."%'"; 
                $whereSQL .= " AND t_type LIKE '%".$t_type."%'";
                $whereSQL .= " AND sales_year LIKE '%".$s_yr."%'";                  
                     } 
                else if(!empty($p_type) && !empty($t_type) && empty($s_yr) && empty($s_mth)){
                 $whereSQL .= " WHERE p_type LIKE '%".$p_type."%'"; 
                $whereSQL .= " AND t_type LIKE '%".$t_type."%'";                   
                     } 
                 else if(!empty($p_type) && empty($t_type) && empty($s_yr) && empty($s_mth)){
                 $whereSQL .= " WHERE p_type LIKE '%".$p_type."%'";                     
                     } 
                else if(empty($p_type) && !empty($t_type) && !empty($s_yr) && !empty($s_mth)){                
                $whereSQL .= " WHERE t_type LIKE '%".$t_type."%'";
                $whereSQL .= " AND sales_year LIKE '%".$s_yr."%'";
                $whereSQL .= " AND sales_month LIKE '%".$s_mth."%'";         
                     } 
                  else if(empty($p_type) && !empty($t_type) && !empty($s_yr) && empty($s_mth)){                 
                $whereSQL .= " WHERE t_type LIKE '%".$t_type."%'";
                $whereSQL .= " AND sales_year LIKE '%".$s_yr."%'";                         
                     } 
                  else if(empty($p_type) && !empty($t_type) && empty($s_yr) && empty($s_mth)){                 
                $whereSQL .= " WHERE t_type LIKE '%".$t_type."%'";                      
                     } 
                else if(!empty($p_type) && empty($t_type) && !empty($s_yr) && !empty($s_mth)){
                $whereSQL .= " WHERE p_type LIKE '%".$p_type."%'";                 
                $whereSQL .= " AND sales_year LIKE '%".$s_yr."%'";
                $whereSQL .= " AND sales_month LIKE '%".$s_mth."%'";         
                     } 
                else if(empty($p_type) && empty($t_type) && !empty($s_yr) && !empty($s_mth)){                
                $whereSQL .= " WHERE sales_year LIKE '%".$s_yr."%'";
                $whereSQL .= " AND sales_month LIKE '%".$s_mth."%'";         
                     } 
                else if(empty($p_type) && empty($t_type) && !empty($s_yr) && empty($s_mth)){                
                $whereSQL .= " WHERE sales_year LIKE '%".$s_yr."%'";                       
                     }            
               } 
               else{  
                    $whereSQL =  " WHERE sales_year = '$year' " ;
               }
                         
            if(!empty($sortBy)){
                $orderSQL = " ORDER BY sale_date ".$sortBy;
            }else{
                $orderSQL = " ORDER BY sale_date DESC ";
            }
               
              $sql = "SELECT count(sales_id) as code FROM sales ".$whereSQL;
              $data = $dbOperation->getPages($sql);
              $rowCount = $data['code'];    
               
            //initialize pagination class
            $pagConfig = array(
                'currentPage' => $start,
                'totalRows' => $rowCount,
                'perPage' => $limit,
                'link_func' => 'searchFilter'
            );
           
            $pagination =  new Pagination($pagConfig);
             
            $queryConfig = array(
                'table' => 'sales',
                'where' => $whereSQL,
                'limit' => $limit,
                'start' => $start,
                'order_by' => $orderSQL
            );
             
            //get rows
            $data = $dbOperation->getdata($queryConfig);            
            
            $p_type = array('N' => 'None','C' => 'Cash','P' => 'POS','T' => 'Online Transfer');
            $t_type = array('P' => 'Paid','C' => 'Credit');
    
            $dbOperation->close();
            if(!empty($data)){
            $results .= "<table class='table table-hover table-striped table-bordered'>
                  <thead>
                  <tr>                  
                       <th></th>                        
                        <th>SALES ID</th>
                        <th>CUSTOMER</th> 
                        <th>PAYMENT TYPE</th> 
                        <th>TRANSACTION TYPE</th>                        
                        <th>AMOUNT(₦)</th> 
                        <th>DATE OF SALES</th>                          
                        <th>ACTION</th>
                    </tr>
                </thead>";
            $count = !empty($_POST['page'])?$start:0;
            foreach ($data as $value) {
             $count++;
             $sales_id = $value['sales_id']; 
             $buyer = $value['buyer']; 
             $p1 = $p_type[trim($value['p_type'])]; 
             $t1 = $t_type[trim($value['t_type'])];             
             $amount = number_format($value['amount'],2);             
            $sale_date =  date_format(date_create($value['sale_date']), 'F, j Y');         
           
          $results .= "<tr>     
                     <td>$count</td>                     
                     <td> $sales_id </td> 
                     <td>$buyer</td>                     
                     <td> $p1 </td> 
                     <td>$t1</td> 
                     <td>$amount</td>     
                     <td> $sale_date  </td>                                           
                      <td>  <a target='_blank' title='View Sales Detail' href='sales_detail.php?id=$sales_id' class='glyphicon glyphicon-eye-open'></a>                                                       
                      </td>                    
                    </tr>";       
              }   
               $results .= "</table>";
                echo $results.$pagination->createLinks();
                 
            } else{echo "<br><br><center><font color='red'><h2>Record Not Available</h2></font></center><br><br>";}
                
             }   
        
        }    
     else if($_POST['action_type'] == 'item_yearly')
        { //echo "it got here"; exit;
                if(isset($_POST['page'])){
            //Include pagination class file
            include_once '../admin/misc/Pagination.php';
           
            $start = !empty($_POST['page'])?$_POST['page']:0;
            $limit = !empty($_POST['limit'])?$_POST['limit']:20;
            $count = $start; 
            //set conditions for search
            $whereSQL = $orderSQL = '';
            $sortBy = $_POST['sortBy'];  $s_yr = $_POST['s_yr'];       
             
            if(!empty($s_yr)){
                $whereSQL .= " WHERE year_report = '$s_yr' "; 
               }  
            
            if(!empty($sortBy)){
                $orderSQL = " ORDER BY quantity ".$sortBy;
            }else{
                $orderSQL = " ORDER BY quantity DESC ";
            }
               
              $sql = "SELECT count(item_id) as code FROM item_yearly ".$whereSQL;
              $data = $dbOperation->getPages($sql);
              $rowCount = $data['code'];    
               
            //initialize pagination class
            $pagConfig = array(
                'currentPage' => $start,
                'totalRows' => $rowCount,
                'perPage' => $limit,
                'link_func' => 'searchFilter'
            );
           
            $pagination =  new Pagination($pagConfig);
             
            $queryConfig = array(
                'table' => 'item_yearly',
                'where' => $whereSQL,
                'limit' => $limit,
                'start' => $start,
                'order_by' => $orderSQL
            );
             
            //get rows
            $data = $dbOperation->getdata($queryConfig);            
                       
            $dbOperation->close();
            if(!empty($data)){
            $results .= "<table class='table table-hover table-striped table-bordered'>
                  <thead>
                  <tr>                  
                       <th></th>                        
                        <th>DESCRIPTION</th>
                        <th>YEAR</th> 
                        <th>TOTAL QUANTITIES SOLD</th>  
                        <th>DATE LAST UPDATED</th>  
                        <th>ACTION</th>
                    </tr>
                </thead>";
            $count = 0;
            foreach ($data as $value) {
             $count++;
            $item_id = $value['item_id'];   $year_report = $value['year_report'];     
            $date_created =  date_format(date_create($value['date_updated']), 'F, j Y');
             $name = $value['description'];  $quantity = number_format($value['quantity'],0);      
           
          $results .= "<tr>     
                     <td>$count</td>                     
                     <td> $name </td> 
                     <td>$year_report</td>                     
                     <td> $quantity </td> 
                     <td>$date_created</td>                                                             
                      <td> <a href='javascript:void(0);' class='glyphicon glyphicon-eye-open' onclick=\" viewItem('$item_id','$year_report')\"></a>                              
                      </td>                    
                    </tr>";       
              }   
               $results .= "</table>";
                echo $results.$pagination->createLinks();
                 
            } else{echo "<br><br><center><font color='red'><h2>Record Not Available</h2></font></center><br><br>";}
                
             }   
        
        }     
     else if($_POST['action_type'] == 'item_monthly')
        { //echo "it got here"; exit;
                if(isset($_POST['page'])){
            //Include pagination class file
            include_once '../admin/misc/Pagination.php';
           
            $start = !empty($_POST['page'])?$_POST['page']:0;
            $limit = !empty($_POST['limit'])?$_POST['limit']:20;
            $count = $start; 
            //set conditions for search
            $whereSQL = $orderSQL = '';
            $sortBy = $_POST['sortBy'];  $s_yr = $_POST['s_yr'];  $s_mth = $_POST['s_mth'];      
             
            $whereSQL .= " WHERE year_report = '$s_yr' AND month_report = '$s_mth' "; 
                 
            
            if(!empty($sortBy)){
                $orderSQL = " ORDER BY month_total ".$sortBy;
            }else{
                $orderSQL = " ORDER BY month_total DESC ";
            }
               
              $sql = "SELECT count(item_id) as code FROM item_sales ".$whereSQL;
              $data = $dbOperation->getPages($sql);
              $rowCount = $data['code'];    
               
            //initialize pagination class
            $pagConfig = array(
                'currentPage' => $start,
                'totalRows' => $rowCount,
                'perPage' => $limit,
                'link_func' => 'searchFilter'
            );
           
            $pagination =  new Pagination($pagConfig);
             
            $queryConfig = array(
                'table' => 'item_sales',
                'where' => $whereSQL,
                'limit' => $limit,
                'start' => $start,
                'order_by' => $orderSQL
            );
             
            //get rows
            $data = $dbOperation->getdata($queryConfig);            
                       
            $dbOperation->close();
            if(!empty($data)){
            $results .= "<table class='table table-hover table-striped table-bordered'>
                  <thead>
                  <tr>                  
                       <th></th>                        
                        <th>DESCRIPTION</th>
                        <th>YEAR</th> 
                        <th>MONTH</th>  
                        <th>WEEK 1</th> 
                        <th>WEEK 2</th> 
                        <th>WEEK 3</th>  
                        <th>WEEK 4</th> 
                        <th>MONTH TOTAL</th> 
                    </tr>
                </thead>";
            $count = !empty($_POST['page'])?$start:0;
            foreach ($data as $value) {
             $count++;
           $description = $value['description'];   $year_report = $value['year_report']; 
           $month_word = $value['month_word'];   $week1 = number_format($value['week1'],0);
           $week2 = number_format($value['week2'],0); $week3 = number_format($value['week3'],0);
           $week4 = number_format($value['week4'],0);  $month_total = $value['month_total'];
           
          $results .= "<tr>     
                     <td>$count</td>                     
                     <td> $description </td> 
                     <td>$year_report</td>                     
                     <td> $month_word </td> 
                     <td>$week1</td>   
                     <td>$week2</td>
                     <td>$week3</td>
                     <td>$week4</td>
                     <td>$month_total</td>                   
                    </tr>";       
              }   
               $results .= "</table>";
                echo $results.$pagination->createLinks();
                 
            } else{echo "<br><br><center><font color='red'><h2>Record Not Available</h2></font></center><br><br>";}
                
             }   
        
        }                    
      elseif($_POST['action_type'] == 'stock_reg')
        { //echo "it got here"; exit;
                if(isset($_POST['page'])){
            //Include pagination class file
            include_once '../admin/misc/Pagination.php';
           
            $start = !empty($_POST['page'])?$_POST['page']:0;
            $limit = !empty($_POST['limit'])?$_POST['limit']:10;
            $count = $start; 
            //set conditions for search
            $whereSQL = $orderSQL = '';
            $keywords = $dbOperation->bite_string($_POST['keywords']);
            $sortBy = $_POST['sortBy'];  $cat = $_POST['cat'];  $brd = $_POST['brd'];           
             
            if(!empty($keywords)){ 
                $whereSQL = " WHERE bar_code LIKE '%".$keywords."%'";   $whereSQL .= " OR description LIKE '%".$keywords."%'"; 
                $whereSQL .= " OR category LIKE '%".$keywords."%'";   $whereSQL .= " OR brand LIKE '%".$keywords."%'";
            }
            else if(!empty($cat) || !empty($brd)){
                $whereSQL .= " WHERE "; 
                if(!empty($cat) && !empty($brd)){
                $whereSQL .= " category LIKE '%".$cat."%'";              
                $whereSQL .= " AND brand LIKE '%".$brd."%'";
                     } 
                else if(!empty($cat) && empty($brd)){
                $whereSQL .= " category LIKE '%".$cat."%'";                        
                     }                           
                else if(empty($cat) && !empty($brd)){               
                $whereSQL .= " brand LIKE '%".$brd."%'";
                     }                    
               }  
                           
            if(!empty($sortBy)){
                $orderSQL = " ORDER BY date_created ".$sortBy;
            }else{
                $orderSQL = " ORDER BY date_created DESC ";
            }
               
              $sql = "SELECT count(item_id) as code FROM items ".$whereSQL;
              $data = $dbOperation->getPages($sql);
              $rowCount = $data['code'];    
               
            //initialize pagination class
            $pagConfig = array(
                'currentPage' => $start,
                'totalRows' => $rowCount,
                'perPage' => $limit,
                'link_func' => 'searchFilter'
            );
           
            $pagination =  new Pagination($pagConfig);
             
            $queryConfig = array(
                'table' => 'items',
                'where' => $whereSQL,
                'limit' => $limit,
                'start' => $start,
                'order_by' => $orderSQL
            );
             
            //get rows
            $data = $dbOperation->getdata($queryConfig);            
            
            $dbOperation->close();
            if(!empty($data)){
            $results .= "<table class='table table-hover table-striped table-bordered'>
                  <thead>
                  <tr>                  
                       <th></th>                        
                        <th>DESCRIPTION</th> 
                        <th>CATEGORY</th> 
                        <th>MAKE</th>                        
                        <th>QUANTITIES</th> 
                        <th>COST PRICE(₦)</th> 
                        <th>TOTAL VALUE(₦)</th>
                        <th>SELLING PRICE(₦)</th>
                        <th>DATE UPDATED</th>             
                    </tr>
                </thead>";
            $count = !empty($_POST['page'])?$start:0;
            foreach ($data as $value) {
             $count++;
             $item_id = $value['item_id'];             
             $description = $value['description']; 
             $category = $value['category'];
             $brand = $value['brand'];
             $quantity = $value['quantity'];
             $cost_price = number_format($value['cost_price'],2); 
             $selling_price = number_format($value['selling_price'],2);
             $total_val = number_format(($value['quantity'] * $value['cost_price']),2);
            $date_updated =  date_format(date_create($value['date_updated']), 'F, j Y');           
            if($date_updated == "November, 30 -0001") {$date_updated = "";}
          $results .= "<tr>     
                     <td>$count</td>                
                     <td>$description</td>                     
                     <td> $category </td> 
                     <td>$brand</td> 
                     <td>$quantity</td>    
                     <td>$cost_price</td> 
                     <td>$total_val</td>    
                     <td>$selling_price</td>      
                     <td> $date_updated  </td>                                           
                                        
                    </tr>";       
              }   
               $results .= "</table>";
                echo $results.$pagination->createLinks();
                 
            } else{echo "<br><br><center><font color='red'><h2>Brand Not Available</h2></font></center><br><br>";}
                
             }   
        
        }              
       else if($_POST['action_type'] == 'tran')
        { //echo "it got here"; exit;
                if(isset($_POST['page'])){
            //Include pagination class file
            include_once '../admin/misc/Pagination.php';
           
            $start = !empty($_POST['page'])?$_POST['page']:0;
            $limit = !empty($_POST['limit'])?$_POST['limit']:20;
            $count = $start; 
            //set conditions for search
            $whereSQL = $orderSQL = '';
            
            $sortBy = $_POST['sortBy'];  $cat = $_POST['cat'];  $brd = $_POST['brd'];           
            $s_dy = $_POST['s_dy'];  $s_mth = $_POST['s_mth'];  $s_yr = $_POST['s_yr'];
            if(!empty($s_yr)){   
              $whereSQL .= " WHERE YEAR(tran_date) = '$s_yr' ";   
                if(!empty($s_mth)){ 
                    $whereSQL .= " AND MONTH(tran_date) = '$s_mth' ";
                 if(!empty($s_dy)){ 
                     $whereSQL .= " AND DAY(tran_date) = '$s_dy' ";
                 }   
                }  
              
              if(!empty($cat) || !empty($brd)){                
                if(!empty($cat) && !empty($brd)){
                $whereSQL .= " AND category LIKE '%".$cat."%'";              
                $whereSQL .= " AND brand LIKE '%".$brd."%'";
                     } 
                else if(!empty($cat) && empty($brd)){
                $whereSQL .= " AND category LIKE '%".$cat."%'";                        
                     }                           
                else if(empty($cat) && !empty($brd)){               
                $whereSQL .= " AND brand LIKE '%".$brd."%'";
                     }                    
               }  
            }        
            else if(empty($s_yr) && (!empty($cat) || !empty($brd))){                
                 if(!empty($cat) && !empty($brd)){
                $whereSQL .= " WHERE category LIKE '%".$cat."%'";              
                $whereSQL .= " AND brand LIKE '%".$brd."%'";
                     } 
                else if(!empty($cat) && empty($brd)){
                $whereSQL .= " WHERE category LIKE '%".$cat."%'";                        
                     }                           
                else if(empty($cat) && !empty($brd)){               
                $whereSQL .= " WHERE brand LIKE '%".$brd."%'";
                     }                  
               }  
            
            if(!empty($sortBy)){
                $orderSQL = " ORDER BY tran_date ".$sortBy;
            }else{
                $orderSQL = " ORDER BY tran_date DESC ";
            }
               
              $sql = "SELECT count(item_id) as code FROM trans_detail ".$whereSQL;
              $data = $dbOperation->getPages($sql);
              $rowCount = $data['code'];    
               
            //initialize pagination class
            $pagConfig = array(
                'currentPage' => $start,
                'totalRows' => $rowCount,
                'perPage' => $limit,
                'link_func' => 'searchFilter'
            );
           
            $pagination =  new Pagination($pagConfig);
             
            $queryConfig = array(
                'table' => 'trans_detail',
                'where' => $whereSQL,
                'limit' => $limit,
                'start' => $start,
                'order_by' => $orderSQL
            );
             
            //get rows
            $data = $dbOperation->getdata($queryConfig);            
                           
            $dbOperation->close();
            if(!empty($data)){
            $results .= "<table class='table table-hover table-striped table-bordered'>
                  <thead>
                  <tr>                  
                       <th></th>                        
                        <th>TRANSFER ID</th> 
                        <th>DESCRIPTION</th>
                        <th>CATEGORY</th> 
                        <th>BRAND</th> 
                        <th>STORE</th> 
                        <th>QTY</th>                        
                        <th>PRICE(₦)</th>                                       
                        <th>TOTAL (₦)</th>                        
                        <th>DATE OF SALES</th>  
                    </tr>
                </thead>";
            $count = !empty($_POST['page'])?$start:0;
            foreach ($data as $value) {
             $count++;   
             $trans_id = $value['trans_id']; 
            $description = $value['description']; 
            $category = $value['category'];
            $brand = $value['brand']; 
            $store = $value['store']; 
            $quantity = $value['quantity']; 
             $price = number_format($value['price'],2); 
             $total = number_format($value['total'],2);            
             
            $tran_date =  date_format(date_create($value['tran_date']), 'F, j Y');         
           
          $results .= "<tr>     
                     <td>$count</td>  
                     <td>$trans_id</td>     
                     <td> $description </td> 
                     <td>$category</td>  
                     <td>$brand</td>  
                     <td>$store</td>      
                     <td> $quantity </td> 
                     <td>$price</td> 
                     <td>$total</td>                                         
                     <td> $tran_date  </td>                                  
                    </tr>";       
              }   
            $results .= "</table>";
                echo $results.$pagination->createLinks();
                 
            } else{echo "<br><br><center><font color='red'><h2>Record Not Available</h2></font></center><br><br>";}
                
             }   
        
        }  
        elseif($_POST['action_type'] == 'rstock')
        { //echo "it got here"; exit;
                if(isset($_POST['page'])){
            //Include pagination class file
            include_once '../admin/misc/Pagination.php';
           
            $start = !empty($_POST['page'])?$_POST['page']:0;
            $limit = !empty($_POST['limit'])?$_POST['limit']:10;
            $count = $start; 
            //set conditions for search
            $whereSQL = $orderSQL = '';
            $keywords = $dbOperation->bite_string($_POST['keywords']);
            $sortBy = $_POST['sortBy'];            
             
            if(!empty($keywords)){ 
                $whereSQL = " WHERE description LIKE '%".$keywords."%'";   $whereSQL .= " OR item_id LIKE '%".$keywords."%'"; 
                $whereSQL .= " OR sales_id LIKE '%".$keywords."%'";  
            }
                                       
            if(!empty($sortBy)){
                $orderSQL = " ORDER BY date_returned ".$sortBy;
            }else{
                $orderSQL = " ORDER BY date_returned DESC ";
            }
               
              $sql = "SELECT count(item_id) as code FROM item_returned ".$whereSQL;
              $data = $dbOperation->getPages($sql);
              $rowCount = $data['code'];    
               
            //initialize pagination class
            $pagConfig = array(
                'currentPage' => $start,
                'totalRows' => $rowCount,
                'perPage' => $limit,
                'link_func' => 'searchFilter'
            );
           
            $pagination =  new Pagination($pagConfig);
             
            $queryConfig = array(
                'table' => 'item_returned',
                'where' => $whereSQL,
                'limit' => $limit,
                'start' => $start,
                'order_by' => $orderSQL
            );
             
            //get rows
            $data = $dbOperation->getdata($queryConfig);            
            
            $dbOperation->close();
            if(!empty($data)){
            $results .= "<table class='table table-hover table-striped table-bordered'>
                  <thead>
                  <tr>                  
                       <th></th>                        
                        <th>ITEM ID</th> 
                        <th>DESCRIPTION</th>                                       
                        <th>QUANTITY</th> 
                        <th>PRICE(₦)</th> 
                        <th>TOTAL(₦)</th>
                        <th>COMMENT</th>
                        <th>DATE RETURNED</th>              
                    </tr>
                </thead>";
            $count = !empty($_POST['page'])?$start:0;
            foreach ($data as $value) {
             $count++;
             $item_id = $value['item_id'];             
             $description = $value['description'];             
             $quantity = $value['quantity'];
             $price = number_format($value['price'],2); 
             $total = number_format($value['total'],2); 
             $comment = $value['comment'];
            $date_updated =  date_format(date_create($value['date_returned']), 'F, j Y');           
            if($date_updated == "November, 30 -0001") {$date_updated = "";}
          $results .= "<tr>     
                     <td>$count</td> 
                     <td>$item_id</td>      
                     <td>$description</td>                   
                     <td>$quantity</td>    
                     <td>$price</td> 
                     <td>$total</td>    
                     <td>$comment</td>      
                     <td> $date_updated  </td>                                           
                                        
                    </tr>";       
              }   
               $results .= "</table>";
                echo $results.$pagination->createLinks();
                 
            } else{echo "<br><br><center><font color='red'><h2>Item Not Available</h2></font></center><br><br>";}
                
             }   
        
        } 
}
 
 
?>

