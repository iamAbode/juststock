<?php
//echo "ok it working"; exit;
 //session_start();

 include_once 'db.php'; 
 include_once '../config/config.php';
 $dbOperation = new DB();    
 
 if(isset($_POST['action_type']) && !empty($_POST['action_type']))
     {
     
    if($_POST['action_type'] == 'data')
        {
        $id = trim($_POST['id']);        
        $tableName = " users ";
        $whereSQL = " WHERE user_id = '$id' ";
        $type = "single";
        $queryConfig = array(
        'table' => $tableName,
        'where' => $whereSQL,        
        'return_type' => $type 
        );
 
        $data = $dbOperation->getdata($queryConfig);   
        $dbOperation->close();   //echo $data;   
        echo json_encode($data);
        }   
        
    elseif($_POST['action_type'] == 'add')
        {
        $user_id = time(); $firstname = $_POST['firstname'];  $lastname = $_POST['lastname'];
        $username = $_POST['username']; $password = md5($_POST['password']); 
        $role = $_POST['role'];   
        $date= date('Y-m-d H:i:s');         
        
         $queryConfig1 = array('table' => "users", 'where' => " WHERE username='$username' ",'return_type' => "single" ); 
        $data1 = $dbOperation->getdata($queryConfig1);  
                
           if(!empty($data1['username'])){
              $dbOperation->close();
              echo "Username already exist";                
               exit;                
               }          
               
               
        $sql = "INSERT INTO users (user_id, firstname, lastname, username, password, role) VALUES ('$user_id', '$firstname', '$lastname', '$username', '$password', '$role')";        
        $stmt = $dbOperation->insert($sql);
        
        $dbOperation->close();

       if( $stmt == "ok") {
           
           echo "ok";
        }
        else {
            echo "ok";
        }
               }       
   
    elseif($_POST['action_type'] == 'delete')
            {
         $user_id = $_POST['id'];
        $sql = "delete from users where user_id = '$user_id' ";
         $data = $dbOperation->delete($sql);   
        $dbOperation->close();   
        if( $data == "ok") { echo "ok";}
        else {echo "Unable to delete user at this time"; }
            }              
               
               
}
 
 
?>

