<?php
 include_once 'db.php'; 
 $dbOperation = new DB(); 
 
  $year = (int)date('Y'); $month = (int)date('m'); $day = (int)date('d');
  
 if(isset($_POST['action_type']) && !empty($_POST['action_type']))
     {
     
    if($_POST['action_type'] == 'monthly')
        {         
        $whereSQL =  " WHERE year_report = '$year' AND month_report = '$month' " ;
        $orderSQL = " ORDER BY month_total DESC ";
                
        $queryConfig = array(
        'table' => "item_sales",
        'where' => $whereSQL,        
        'limit' => "5",        
        'order_by' => $orderSQL
        );
 
        $data = $dbOperation->getdata($queryConfig);   
        $dbOperation->close();       
        echo json_encode($data);
        } 
        else if($_POST['action_type'] == 'lasthy')
        {         
        $whereSQL =  " WHERE date_created > CURDATE() - 30 " ;
        $orderSQL = " ORDER BY month_total DESC ";
                
        $queryConfig = array(
        'table' => "item_sales",
        'where' => $whereSQL,        
        'limit' => "5",        
        'order_by' => $orderSQL
        );
 
        $data = $dbOperation->getdata($queryConfig);   
        $dbOperation->close();       
        echo json_encode($data);
        } 
                   
}
 
 
?>

