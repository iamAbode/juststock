<!DOCTYPE html>
<html lang="en-US">
<head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
	<meta charset="UTF-8">
	<meta name="viewport" content="user-scalable=yes, width=device-width, initial-scale=1.0, minimum-scale=1">
<meta name="description" content="">
	<title>STOCK INVENTORY SOLUTION</title>
  <link rel="icon" type="image/jpg" href="home/images/steph_logo.png" />       
<link href='vendors/bootstrap/dist/css/bootstrap.min.css' rel='stylesheet'>
<link href="home/css/custom.css" rel="stylesheet">

<link href="home/css/bootstrap-responsive.min.css" rel="stylesheet">
<link rel="stylesheet" href="home/css/slippry.css"> 
<script type="text/javascript" src="home/js/jquery.min.js" ></script>
<script type="text/javascript" src="home/js/bootstrap.min.js"></script>

<script src="home/js/slippry.min.js"></script>
<script>
			$(function() {
				var demo1 = $("#demo1").slippry({
					
				});
                                
			});
		</script>                
  
<script type="text/javascript">

    function submitForm()
    {  
             
	  var username = $('#username').val();
	  var password = $('#password').val();
         if(username.length < 1 || password.length < 1 ) {
		 alert("Please enter your credentials to login");
		  //e.preventDefault();
                  return false;
	  }        
        
   var data = $("#login-form").serialize();
     
   $.ajax({    
   type : 'POST',
   url  : 'database/login_process.php',
   data : data,
   beforeSend: function()
   { 
    $("#error").fadeOut();
    $("#btn-login").html('<span class="glyphicon glyphicon-transfer"></span> &nbsp; sending ...');
   },
   success :  function(response)
      {      
     if($.trim(response) === "ok"){          
       $("#btn-login").html('<img src="build/images/btn-ajax-loader.gif" /> &nbsp; Signing In ...');
      setTimeout(' window.location.href = "admin/index.php"; ',5);
     }    
     else{       
      $("#error").fadeIn(500, function(e){   
          
    $("#error").html('<div class="alert alert-danger"> <span class="glyphicon glyphicon-info-sign"></span> &nbsp; '+response+' !</div>');
           $("#btn-login").html('<span class="glyphicon glyphicon-log-in"></span> &nbsp; Sign In');
           //e.preventDefault();
         });
     }
     }
   });
    return false;
     //alert("");
  } 
  
 
            
 /*function reveal_password(){ 
    var $pwd = $(".pwd");
    if ($pwd.attr('type') === 'password') {
        $pwd.attr('type', 'text');
    } else {
        $pwd.attr('type', 'password');
    }
 } */
  
</script>
<script>
$(function() {
    $(".toggle-password").hide();
    $("#password").on("keyup",function(){
    if($(this).val())
        $(".toggle-password").show();
    else
        $(".toggle-password").hide();
    });
$(".toggle-password").click(function() {

  $("#password").attr('type','text');
});
$(".toggle-password").mousedown(function(){ 
                $("#password").attr('type','text');
            }).mouseup(function(){
            	$("#password").attr('type','password');
            }).mouseout(function(){
            	$("#password").attr('type','password');
            });
                                
			});
		</script>     
  </head> 
  <style>
     .field-icon {
  float: right;
  margin-left: -25px;
  margin-top: -25px;
  position: relative;
  z-index: 2;
}
      
  </style>
<body>
<div class="container-fluid">
 <?php include("home/include/header.php"); ?>
 <br><br><br><br>
  <div class="row"> 
    <div class="col-md-1"></div>
	
    <div class="col-md-10"> 
            <div class=""> 				
                <center><h2><strong>STOCK MANAGEMENT SOLUTION</strong></h2></center> 
            </div>
	<div>
    <center>
        <br><br>
        <div class="col-md-4"></div>
         <div class="col-md-4">
        <h3>Enter your credentials</h3> (username: admin / password: admin)<br>       
        
        <form class="form-signin" method="post" id="login-form">
            
        <div id="error">
        <!-- error will be shown here ! -->
        </div> 
            
        <div class="form-group">
        <input type="text" class="form-control" placeholder="Username" name="username" id="username" />
        <span id="check-e"></span>
        </div>        
        <div class="form-group ">        
        <input type="password" class="form-control" placeholder="Password" name="password" id="password" data-toggle="password" />
           <span toggle="#password-field" class="glyphicon glyphicon-eye-open field-icon toggle-password"></span> 
        </div>        
            
        <div class="form-group ">
            <button type="button" class="btn btn-default" name="btn-login" id="btn-login" onclick="submitForm()">
      <span class="glyphicon glyphicon-log-in"></span> &nbsp; Sign In
   </button> 
        </div>             
        </form>
    </center> <br>
     </div>
     <div class="col-md-4"></div>
     </div>
    </div>	
<div class="col-md-1"></div>	
  </div>
 <?php include("home/include/footer.php");?>
 </div> 
                    
</body></html>
